/**
 * ============================================================================
 * SUPERMISTO VENDEDOR — assets/js/vendedor-data.js  (MÓDULO 6)
 * ============================================================================
 * Camada de dados do portal do vendedor. Toda função aqui só consegue ler
 * ou escrever os PRÓPRIOS produtos/vendas do vendedor logado — não porque
 * o código filtra isso (embora também filtre, por clareza), mas porque as
 * políticas RLS de supabase/migrations/004_modulo6.sql impedem qualquer
 * leitura/escrita fora disso, mesmo que este código tivesse um bug. Um
 * vendedor não tem como ver produtos ou vendas de outro vendedor.
 * ============================================================================
 */

async function smVendorClient() {
  return window.smSupabaseReady ? await window.smSupabaseReady : null;
}

function formatPrice(value) {
  const n = Number(value);
  return isNaN(n) ? "—" : n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function smSlugify(text) {
  return (text || "")
    .toString()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function smEscapeHTML(str) {
  return (str ?? "").toString()
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function smToast(message, type) {
  let el = document.getElementById("smToast");
  if (!el) {
    el = document.createElement("div");
    el.id = "smToast";
    el.className = "admin-toast";
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.className = "admin-toast is-visible" + (type ? " " + type : "");
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.remove("is-visible"), 3200);
}

function smRowToProduct(row) {
  return {
    id: row.id, name: row.name, category: row.category, price: Number(row.price),
    salePrice: row.sale_price != null ? Number(row.sale_price) : undefined,
    weight: row.weight || "", shortDesc: row.short_desc || "", description: row.description || "",
    emoji: row.emoji || "🌶️", image: row.image || undefined, images: row.images || [],
    available: row.available !== false, trackStock: !!row.track_stock, stockQuantity: row.stock_quantity || 0,
  };
}

async function smVendorGetCategories() {
  const client = await smVendorClient();
  if (!client) return [];
  const { data, error } = await client.from("categories").select("*").eq("active", true).order("sort_order");
  if (error) { console.error(error); return []; }
  return data || [];
}

async function smVendorGetMyProducts() {
  const client = await smVendorClient();
  const user = await smVendorCurrentUser();
  if (!client || !user) return [];
  const { data, error } = await client.from("products").select("*").eq("seller_id", user.id).order("created_at", { ascending: false });
  if (error) { console.error(error); smToast("Erro ao carregar seus produtos: " + error.message, "error"); return []; }
  return (data || []).map(smRowToProduct);
}

async function smVendorGetProduct(id) {
  const client = await smVendorClient();
  const user = await smVendorCurrentUser();
  if (!client || !user) return null;
  const { data, error } = await client.from("products").select("*").eq("id", id).eq("seller_id", user.id).maybeSingle();
  if (error) { console.error(error); return null; }
  return data ? smRowToProduct(data) : null;
}

async function smVendorAddProduct(product) {
  try {
    const client = await smVendorClient();
    const user = await smVendorCurrentUser();
    if (!client || !user) throw new Error("Sessão inválida.");
    const row = {
      id: product.id, name: product.name, category: product.category, price: product.price,
      sale_price: product.salePrice || null, weight: product.weight || "", short_desc: product.shortDesc || "",
      description: product.description || "", emoji: product.emoji || "🌶️", image: product.image || null,
      available: product.available !== false, track_stock: !!product.trackStock, stock_quantity: product.stockQuantity || 0,
      seller_id: user.id, // sempre o próprio vendedor — RLS também barraria qualquer outro valor
    };
    const { error } = await client.from("products").insert(row);
    if (error) throw error;
    return true;
  } catch (error) {
    smToast("Erro ao adicionar produto: " + error.message, "error");
    return false;
  }
}

async function smVendorUpdateProduct(id, product) {
  try {
    const client = await smVendorClient();
    const user = await smVendorCurrentUser();
    if (!client || !user) throw new Error("Sessão inválida.");
    const row = {
      name: product.name, category: product.category, price: product.price,
      sale_price: product.salePrice || null, weight: product.weight || "", short_desc: product.shortDesc || "",
      description: product.description || "", emoji: product.emoji || "🌶️", image: product.image || null,
      available: product.available !== false, track_stock: !!product.trackStock, stock_quantity: product.stockQuantity || 0,
    };
    // .eq("seller_id", user.id) é redundante com a RLS, mas deixa explícito
    // no próprio código que este update nunca deveria alcançar outro vendedor.
    const { error } = await client.from("products").update(row).eq("id", id).eq("seller_id", user.id);
    if (error) throw error;
    return true;
  } catch (error) {
    smToast("Erro ao salvar produto: " + error.message, "error");
    return false;
  }
}

async function smVendorDeleteProduct(id) {
  try {
    const client = await smVendorClient();
    const user = await smVendorCurrentUser();
    if (!client || !user) throw new Error("Sessão inválida.");
    const { error } = await client.from("products").delete().eq("id", id).eq("seller_id", user.id);
    if (error) throw error;
    return true;
  } catch (error) {
    smToast("Erro ao excluir produto: " + error.message, "error");
    return false;
  }
}

async function smVendorUniqueProductId(baseName) {
  const client = await smVendorClient();
  const base = smSlugify(baseName) || "produto";
  let id = base, n = 2;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const { data } = await client.from("products").select("id").eq("id", id).maybeSingle();
    if (!data) break;
    id = `${base}-${n}`;
    n++;
  }
  return id;
}

async function smVendorUploadImage(file) {
  try {
    const client = await smVendorClient();
    const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
    const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const { error } = await client.storage.from("products").upload(path, file, { cacheControl: "3600", upsert: false });
    if (error) throw error;
    const { data: pub } = client.storage.from("products").getPublicUrl(path);
    return pub.publicUrl;
  } catch (error) {
    smToast("Erro ao enviar imagem: " + error.message, "error");
    return null;
  }
}

// Vendas do vendedor logado (itens de pedidos que incluem produtos dele —
// a RLS de order_items garante que só vejamos linhas com seller_id = auth.uid()).
async function smVendorGetMySales() {
  const client = await smVendorClient();
  const user = await smVendorCurrentUser();
  if (!client || !user) return [];
  const { data, error } = await client.from("order_items").select("*, orders(order_number, status, payment_status, created_at)").eq("seller_id", user.id).order("id", { ascending: false });
  if (error) { console.error(error); return []; }
  return data || [];
}
