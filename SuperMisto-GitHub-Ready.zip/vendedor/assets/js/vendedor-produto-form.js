document.addEventListener("DOMContentLoaded", async () => {
  const params = new URLSearchParams(window.location.search);
  const editId = params.get("id");

  renderVendorShell("produtos.html", editId ? "Editar produto" : "Novo produto");
  const content = document.getElementById("vendorContent");
  content.innerHTML = `<div class="admin-empty">Carregando...</div>`;

  const [categories, existing] = await Promise.all([
    smVendorGetCategories(),
    editId ? smVendorGetProduct(editId) : Promise.resolve(null),
  ]);

  if (editId && !existing) {
    content.innerHTML = `<div class="admin-empty">Produto não encontrado (ou não é seu). <a href="produtos.html">Voltar</a>.</div>`;
    return;
  }

  const isEdit = !!existing;
  const p = existing || {};
  let uploadedImage = p.image || "";

  content.innerHTML = `
    <a href="produtos.html" class="admin-back-link">← Voltar para meus produtos</a>

    <form id="vendorProductForm" class="admin-panel">
      <h2>${isEdit ? "Editar produto" : "Novo produto"}</h2>

      <div class="admin-form-grid cols-2">
        <div class="admin-field span-2">
          <label for="f_name">Nome *</label>
          <input type="text" id="f_name" required value="${smEscapeHTML(p.name || "")}">
        </div>
        <div class="admin-field">
          <label for="f_category">Categoria *</label>
          <select id="f_category" required>
            ${categories.map((c) => `<option value="${c.slug}" ${p.category === c.slug ? "selected" : ""}>${smEscapeHTML(c.name)}</option>`).join("")}
          </select>
        </div>
        <div class="admin-field">
          <label for="f_weight">Peso / volume</label>
          <input type="text" id="f_weight" placeholder="ex: 100g" value="${smEscapeHTML(p.weight || "")}">
        </div>
        <div class="admin-field">
          <label for="f_price">Preço (R$) *</label>
          <input type="number" id="f_price" step="0.01" min="0" required value="${p.price ?? ""}">
        </div>
        <div class="admin-field">
          <label for="f_salePrice">Preço promocional (R$)</label>
          <input type="number" id="f_salePrice" step="0.01" min="0" value="${p.salePrice ?? ""}">
        </div>
        <div class="admin-field span-2">
          <label for="f_shortDesc">Descrição curta</label>
          <textarea id="f_shortDesc" rows="2">${smEscapeHTML(p.shortDesc || "")}</textarea>
        </div>
        <div class="admin-field span-2">
          <label for="f_description">Descrição completa</label>
          <textarea id="f_description" rows="4">${smEscapeHTML(p.description || "")}</textarea>
        </div>
        <div class="admin-field">
          <label for="f_emoji">Emoji ilustrativo</label>
          <input type="text" id="f_emoji" maxlength="4" placeholder="🌶️" value="${smEscapeHTML(p.emoji || "")}">
        </div>
        <div class="admin-field">
          <label>Imagem principal</label>
          <input type="file" id="f_imageFile" accept="image/*">
          <div class="admin-form-hint" id="f_imageStatus">${uploadedImage ? "Imagem atual definida." : "Nenhuma imagem enviada."}</div>
        </div>
      </div>

      <div class="admin-checkbox-row">
        <input type="checkbox" id="f_available" ${p.available === false ? "" : "checked"}>
        <label for="f_available">Disponível para venda</label>
      </div>
      <div class="admin-checkbox-row">
        <input type="checkbox" id="f_trackStock" ${p.trackStock ? "checked" : ""}>
        <label for="f_trackStock">Controlar estoque</label>
      </div>
      <div class="admin-field" style="max-width:220px">
        <label for="f_stockQuantity">Estoque (unidades)</label>
        <input type="number" id="f_stockQuantity" min="0" value="${p.stockQuantity ?? 0}">
      </div>

      <div class="admin-form-actions">
        <a href="produtos.html" class="btn btn-outline">Cancelar</a>
        <button type="submit" class="btn btn-primary" id="vendorProductSubmitBtn">${isEdit ? "Salvar alterações" : "Adicionar produto"}</button>
      </div>
    </form>
  `;

  document.getElementById("f_imageFile").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById("f_imageStatus");
    statusEl.textContent = "Enviando imagem...";
    const url = await smVendorUploadImage(file);
    if (url) {
      uploadedImage = url;
      statusEl.textContent = "Imagem enviada ✓";
    } else {
      statusEl.textContent = "Falha ao enviar. Tente novamente.";
    }
  });

  document.getElementById("vendorProductForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("f_name").value.trim();
    if (!name) return;

    const btn = document.getElementById("vendorProductSubmitBtn");
    btn.disabled = true;
    btn.textContent = "Salvando...";

    const data = {
      name,
      category: document.getElementById("f_category").value,
      weight: document.getElementById("f_weight").value.trim(),
      price: parseFloat(document.getElementById("f_price").value) || 0,
      salePrice: document.getElementById("f_salePrice").value ? parseFloat(document.getElementById("f_salePrice").value) : undefined,
      shortDesc: document.getElementById("f_shortDesc").value.trim(),
      description: document.getElementById("f_description").value.trim(),
      emoji: document.getElementById("f_emoji").value.trim(),
      image: uploadedImage || undefined,
      available: document.getElementById("f_available").checked,
      trackStock: document.getElementById("f_trackStock").checked,
      stockQuantity: parseInt(document.getElementById("f_stockQuantity").value, 10) || 0,
    };

    let ok;
    if (isEdit) {
      ok = await smVendorUpdateProduct(existing.id, data);
      if (ok) smToast("Produto atualizado.", "success");
    } else {
      const id = await smVendorUniqueProductId(name);
      ok = await smVendorAddProduct(Object.assign({ id }, data));
      if (ok) smToast("Produto adicionado.", "success");
    }

    if (ok) {
      window.location.href = "produtos.html";
    } else {
      btn.disabled = false;
      btn.textContent = isEdit ? "Salvar alterações" : "Adicionar produto";
    }
  });
});
