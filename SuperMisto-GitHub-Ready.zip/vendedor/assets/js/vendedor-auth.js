/**
 * ============================================================================
 * SUPERMISTO VENDEDOR — assets/js/vendedor-auth.js  (MÓDULO 6)
 * ============================================================================
 * Login de VENDEDOR do marketplace — completamente separado do login de
 * administrador (admin/assets/js/admin-auth.js) e do login de cliente
 * (assets/js/customer-auth.js). Usa o mesmo Supabase Auth, mas um vendedor
 * nunca aparece em admin_profiles nem em customers, então sm_is_admin() e
 * sm_is_owner() continuam sempre false para ele — um vendedor jamais
 * acessa funções administrativas nem dados de clientes.
 *
 * Não existe cadastro público de vendedor: a conta é criada por um
 * administrador "owner" (admin/vendedores.html), sempre começando com
 * status "pending" até ser aprovada.
 * ============================================================================
 */

async function smVendorGetClient() {
  return window.smSupabaseReady ? await window.smSupabaseReady : null;
}

async function smVendorIsLoggedIn() {
  const client = await smVendorGetClient();
  if (!client) return false;
  const { data } = await client.auth.getSession();
  return !!(data && data.session);
}

async function smVendorCurrentUser() {
  const client = await smVendorGetClient();
  if (!client) return null;
  const { data } = await client.auth.getUser();
  return data ? data.user : null;
}

async function smVendorGetProfile() {
  const client = await smVendorGetClient();
  const user = await smVendorCurrentUser();
  if (!client || !user) return null;
  const { data } = await client.from("seller_profiles").select("*").eq("id", user.id).maybeSingle();
  return data;
}

async function smVendorLogin(email, password) {
  const client = await smVendorGetClient();
  if (!client) return { ok: false, error: "Loja ainda não está com o backend configurado. Tente novamente mais tarde." };

  const { data, error } = await client.auth.signInWithPassword({ email, password });
  if (error) return { ok: false, error: smVendorFriendlyAuthError(error) };

  // Confere que quem logou é mesmo um vendedor cadastrado (não um cliente
  // ou qualquer outro usuário do Supabase Auth tentando entrar aqui).
  const { data: profile } = await client.from("seller_profiles").select("status").eq("id", data.user.id).maybeSingle();
  if (!profile) {
    await client.auth.signOut();
    return { ok: false, error: "Esta conta não é uma conta de vendedor." };
  }
  if (profile.status === "suspended") {
    await client.auth.signOut();
    return { ok: false, error: "Esta conta de vendedor está suspensa. Fale com a administração da loja." };
  }

  return { ok: true, session: data.session, status: profile.status };
}

async function smVendorRequestPasswordReset(email) {
  const client = await smVendorGetClient();
  if (!client) return { ok: false, error: "Loja ainda não está com o backend configurado." };

  const redirectTo = `${window.location.origin}/reset-password.html`;
  const { error } = await client.auth.resetPasswordForEmail(email, { redirectTo });
  if (error) return { ok: false, error: error.message || "Não foi possível enviar o e-mail de redefinição." };
  return { ok: true };
}

async function smVendorLogout() {
  const client = await smVendorGetClient();
  if (client) await client.auth.signOut();
  window.location.href = "index.html";
}

function smVendorFriendlyAuthError(error) {
  const msg = (error && error.message) || "";
  if (msg.includes("Invalid login credentials")) return "E-mail ou senha incorretos.";
  return "Não foi possível entrar: " + msg;
}

// ---------------------------------------------------------------------------
// Guarda de rota — chamada no <head> de toda página protegida do portal.
// ---------------------------------------------------------------------------
function smVendorGuard() {
  const overlay = document.createElement("div");
  overlay.id = "smVendorAuthOverlay";
  overlay.style.cssText =
    "position:fixed;inset:0;background:#F5F1F8;z-index:9999;display:flex;align-items:center;justify-content:center;font-family:sans-serif;color:#3A1150;font-size:.95rem";
  overlay.textContent = "Verificando acesso...";
  document.addEventListener("DOMContentLoaded", () => document.body.prepend(overlay));

  (async () => {
    const client = await smVendorGetClient();
    if (!client) {
      window.location.href = "index.html?erro=supabase-nao-configurado";
      return;
    }
    const loggedIn = await smVendorIsLoggedIn();
    if (!loggedIn) {
      window.location.href = "index.html";
      return;
    }
    const profile = await smVendorGetProfile();
    if (!profile) {
      window.location.href = "index.html";
      return;
    }
    overlay.remove();
  })();
}
