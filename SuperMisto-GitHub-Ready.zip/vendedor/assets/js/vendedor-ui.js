/**
 * ============================================================================
 * SUPERMISTO VENDEDOR — assets/js/vendedor-ui.js  (MÓDULO 6)
 * ============================================================================
 * Esqueleto compartilhado das páginas do portal do vendedor — mesmo
 * padrão de admin/assets/js/admin-ui.js, mas com navegação própria
 * (só Dashboard e Produtos, sem nada administrativo).
 * ============================================================================
 */

const SM_VENDOR_NAV = [
  { href: "dashboard.html", label: "Dashboard", icon: "📊" },
  { href: "produtos.html", label: "Meus produtos", icon: "🧂" },
];

function renderVendorShell(activeHref, pageTitle) {
  const shell = document.getElementById("vendor-shell");
  if (!shell) return;

  shell.innerHTML = `
    <div class="admin-sidebar-backdrop" id="vendorSidebarBackdrop"></div>
    <div class="admin-layout">
      <aside class="admin-sidebar" id="vendorSidebar">
        <div class="admin-sidebar-brand">
          <img src="../assets/img/logo-white.png" alt="SuperMisto">
          <span>Vendedor</span>
        </div>
        <nav class="admin-sidebar-nav">
          ${SM_VENDOR_NAV.map(
            (item) => `
            <a href="${item.href}" class="${item.href === activeHref ? "active" : ""}">
              <span class="ic">${item.icon}</span> ${item.label}
            </a>`
          ).join("")}
        </nav>
        <div class="admin-sidebar-foot">
          Módulo 6 — marketplace SuperMisto.<br>
          <a href="../index.html" target="_blank" rel="noopener">Ver site público ↗</a>
        </div>
      </aside>

      <div class="admin-main">
        <header class="admin-topbar">
          <button class="admin-menu-btn" id="vendorMenuBtn" aria-label="Abrir menu">☰</button>
          <h1>${pageTitle}</h1>
          <button class="btn btn-outline btn-sm" id="vendorLogoutBtn">Sair</button>
        </header>
        <main class="admin-content" id="vendorContent"></main>
      </div>
    </div>
  `;

  const menuBtn = document.getElementById("vendorMenuBtn");
  const backdrop = document.getElementById("vendorSidebarBackdrop");
  menuBtn?.addEventListener("click", () => document.body.classList.add("admin-sidebar-open"));
  backdrop?.addEventListener("click", () => document.body.classList.remove("admin-sidebar-open"));

  document.getElementById("vendorLogoutBtn")?.addEventListener("click", () => {
    if (confirm("Sair do portal do vendedor?")) smVendorLogout();
  });
}

function smConfirm(title, message, onConfirm, confirmLabel) {
  const existing = document.getElementById("smConfirmModal");
  if (existing) existing.remove();

  const backdrop = document.createElement("div");
  backdrop.className = "admin-modal-backdrop";
  backdrop.id = "smConfirmModal";
  backdrop.innerHTML = `
    <div class="admin-modal" role="dialog" aria-modal="true">
      <h3>${title}</h3>
      <p>${message}</p>
      <div class="admin-modal-actions">
        <button class="btn btn-outline btn-sm" id="smConfirmCancel">Cancelar</button>
        <button class="btn btn-danger btn-sm" id="smConfirmOk">${confirmLabel || "Confirmar"}</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);

  const close = () => backdrop.remove();
  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) close(); });
  document.getElementById("smConfirmCancel").addEventListener("click", close);
  document.getElementById("smConfirmOk").addEventListener("click", () => { close(); onConfirm(); });
}
