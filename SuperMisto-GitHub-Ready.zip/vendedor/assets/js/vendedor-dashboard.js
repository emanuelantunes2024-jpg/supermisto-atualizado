document.addEventListener("DOMContentLoaded", async () => {
  renderVendorShell("dashboard.html", "Dashboard");
  const content = document.getElementById("vendorContent");
  content.innerHTML = `<div class="admin-empty">Carregando...</div>`;

  const [profile, products, sales] = await Promise.all([
    smVendorGetProfile(),
    smVendorGetMyProducts(),
    smVendorGetMySales(),
  ]);

  const approvedSales = sales.filter((s) => s.orders && s.orders.payment_status === "approved");
  const totalSold = approvedSales.reduce((sum, s) => sum + Number(s.subtotal || 0), 0);
  const commission = totalSold * (Number(profile?.commission_rate || 0) / 100);
  const payout = totalSold - commission;

  const statusLabel = { pending: "Pendente de aprovação", active: "Ativo", suspended: "Suspenso" };

  content.innerHTML = `
    <p class="admin-page-intro">
      Bem-vindo(a), ${smEscapeHTML(profile?.store_name || "")}.
      Status da conta: <span class="pill ${profile?.status === "active" ? "pill-on" : "pill-muted"}">${statusLabel[profile?.status] || profile?.status}</span>
      ${profile?.status !== "active" ? "— seus produtos só aparecem no site público depois que a loja aprovar sua conta." : ""}
    </p>

    <div class="admin-cards">
      <div class="admin-stat-card"><div class="num">${products.length}</div><div class="label">Meus produtos</div></div>
      <div class="admin-stat-card"><div class="num">${approvedSales.length}</div><div class="label">Vendas pagas</div></div>
      <div class="admin-stat-card"><div class="num">${formatPrice(totalSold)}</div><div class="label">Total vendido</div></div>
      <div class="admin-stat-card"><div class="num">${formatPrice(payout)}</div><div class="label">A receber (após comissão de ${profile?.commission_rate}%)</div></div>
    </div>

    <div class="admin-panel">
      <h2>Ações rápidas</h2>
      <a href="produto-form.html" class="btn btn-primary btn-sm">+ Novo produto</a>
      <a href="produtos.html" class="btn btn-outline btn-sm">Ver meus produtos</a>
    </div>

    <div class="admin-panel">
      <h2>Split de pagamento (Módulo 7)</h2>
      <p style="font-size:.9rem;color:var(--ink-soft);margin:0 0 12px">
        ${profile?.mp_connected_at
          ? `Sua conta Mercado Pago está conectada desde ${new Date(profile.mp_connected_at).toLocaleDateString("pt-BR")}. Vendas de pedidos só com produtos seus caem direto na sua conta, com a comissão da loja retida automaticamente.`
          : `Conecte sua conta Mercado Pago para receber o pagamento das suas vendas diretamente (com a comissão da loja retida automaticamente), sem depender de repasse manual.`}
      </p>
      <button class="btn ${profile?.mp_connected_at ? "btn-outline" : "btn-primary"} btn-sm" id="connectMpBtn">
        ${profile?.mp_connected_at ? "Reconectar conta Mercado Pago" : "Conectar Mercado Pago"}
      </button>
    </div>

    <div class="admin-panel">
      <h2>Notificações</h2>
      <p style="font-size:.9rem;color:var(--ink-soft);margin:0 0 12px" id="pushStatusText">Verificando disponibilidade...</p>
      <button class="btn btn-outline btn-sm" id="pushToggleBtn" style="display:none">Ativar notificações de nova venda</button>
    </div>

    <div class="admin-panel">
      <h2>Como funciona</h2>
      <p style="font-size:.9rem;color:var(--ink-soft);line-height:1.6;margin:0">
        Você gerencia seus próprios produtos aqui — eles aparecem no catálogo público
        da SuperMisto junto com os produtos da loja. A comissão da plataforma
        (${profile?.commission_rate}%) é descontada do valor de cada venda; o restante é
        repassado pela loja conforme a política de pagamento combinada (ou automaticamente,
        se você conectar sua conta Mercado Pago acima).
      </p>
    </div>
  `;

  // Split de pagamento — inicia o fluxo OAuth com o Mercado Pago
  document.getElementById("connectMpBtn").addEventListener("click", async () => {
    const btn = document.getElementById("connectMpBtn");
    btn.disabled = true;
    btn.textContent = "Abrindo Mercado Pago...";
    try {
      const client = await smVendorGetClient();
      const { data } = await client.auth.getSession();
      const token = data && data.session ? data.session.access_token : null;
      const res = await fetch("/.netlify/functions/seller-connect-mercadopago", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      });
      const body = await res.json();
      if (!res.ok || !body.authUrl) throw new Error(body.error || "Não foi possível iniciar a conexão.");
      window.location.href = body.authUrl;
    } catch (err) {
      smToast(err.message, "error");
      btn.disabled = false;
      btn.textContent = profile?.mp_connected_at ? "Reconectar conta Mercado Pago" : "Conectar Mercado Pago";
    }
  });

  // Notificações push — só oferece o botão se VAPID estiver configurado
  const pushText = document.getElementById("pushStatusText");
  const pushBtn = document.getElementById("pushToggleBtn");
  if (typeof smPushIsAvailable === "function" && smPushIsAvailable()) {
    const user = await smVendorCurrentUser();
    const permission = smPushPermission();
    pushText.textContent = permission === "granted"
      ? "Notificações ativadas neste navegador."
      : "Ative para ser avisado assim que um produto seu for vendido.";
    pushBtn.style.display = permission === "granted" ? "none" : "";
    pushBtn.addEventListener("click", async () => {
      pushBtn.disabled = true;
      const client = await smVendorGetClient();
      const result = await smPushSubscribe("service-worker.js", client, user.id);
      if (result.ok) {
        smToast("Notificações ativadas!", "success");
        pushText.textContent = "Notificações ativadas neste navegador.";
        pushBtn.style.display = "none";
      } else {
        smToast(result.error, "error");
        pushBtn.disabled = false;
      }
    });
  } else {
    pushText.textContent = "Notificações push ainda não estão configuradas nesta loja.";
  }
});
