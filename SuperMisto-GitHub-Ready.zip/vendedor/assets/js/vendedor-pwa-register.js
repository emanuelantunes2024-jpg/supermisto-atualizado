/**
 * ============================================================================
 * SUPERMISTO VENDEDOR — assets/js/vendedor-pwa-register.js  (MÓDULO 7)
 * ============================================================================
 * Registra o Service Worker do portal do vendedor (service-worker.js, na
 * raiz de /vendedor/). Falha silenciosamente em navegadores sem suporte.
 * ============================================================================
 */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/vendedor/service-worker.js", { scope: "/vendedor/" }).catch((err) => {
      console.warn("SuperMisto Vendedor: não foi possível registrar o Service Worker.", err);
    });
  });
}
