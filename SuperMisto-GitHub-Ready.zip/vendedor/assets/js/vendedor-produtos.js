let smVendorProductsCache = [];

document.addEventListener("DOMContentLoaded", async () => {
  renderVendorShell("produtos.html", "Meus Produtos");
  const content = document.getElementById("vendorContent");
  content.innerHTML = `<div class="admin-empty">Carregando...</div>`;

  smVendorProductsCache = await smVendorGetMyProducts();

  content.innerHTML = `
    <p class="admin-page-intro">${smVendorProductsCache.length} produto(s) seus cadastrados.</p>
    <div class="admin-toolbar">
      <div class="left"></div>
      <a href="produto-form.html" class="btn btn-primary btn-sm">+ Adicionar produto</a>
    </div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Produto</th><th>Preço</th><th>Disponível</th><th style="text-align:right">Ações</th></tr></thead>
        <tbody id="vendorProdTableBody"></tbody>
      </table>
    </div>
  `;

  smRenderVendorProdTable();
});

function smRenderVendorProdTable() {
  const tbody = document.getElementById("vendorProdTableBody");
  if (!smVendorProductsCache.length) {
    tbody.innerHTML = `<tr><td colspan="4"><div class="admin-empty">Você ainda não cadastrou nenhum produto. <a href="produto-form.html">Adicionar o primeiro</a>.</div></td></tr>`;
    return;
  }

  tbody.innerHTML = smVendorProductsCache
    .map((p) => `
      <tr>
        <td><strong>${smEscapeHTML(p.name)}</strong></td>
        <td>${formatPrice(p.price)}</td>
        <td>${p.available !== false ? `<span class="pill pill-on">Disponível</span>` : `<span class="pill pill-off">Indisponível</span>`}</td>
        <td>
          <div class="admin-table-actions" style="justify-content:flex-end">
            <a class="btn-icon" title="Editar" href="produto-form.html?id=${encodeURIComponent(p.id)}">✏️</a>
            <button class="btn-icon danger" title="Excluir" data-del="${p.id}">🗑️</button>
          </div>
        </td>
      </tr>
    `)
    .join("");

  tbody.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-del");
      const product = smVendorProductsCache.find((p) => p.id === id);
      smConfirm("Excluir produto", `Tem certeza que deseja excluir "${smEscapeHTML(product?.name || id)}"?`, async () => {
        const ok = await smVendorDeleteProduct(id);
        if (ok) {
          smToast("Produto excluído.", "success");
          smVendorProductsCache = await smVendorGetMyProducts();
          smRenderVendorProdTable();
        }
      }, "Excluir");
    })
  );
}
