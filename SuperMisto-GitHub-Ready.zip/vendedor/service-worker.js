/**
 * ============================================================================
 * SUPERMISTO VENDEDOR — service-worker.js  (MÓDULO 7 — PWA)
 * ============================================================================
 * Service Worker do portal do vendedor, com escopo próprio (/vendedor/) —
 * separado do Service Worker do site público. Mesma filosofia: cacheia o
 * shell da interface (CSS/JS), nunca cacheia chamadas ao Supabase, e
 * recebe/mostra notificações push (ex.: "nova venda!").
 * ============================================================================
 */

const SM_VENDOR_CACHE_NAME = "supermisto-vendedor-v2";
const SM_VENDOR_APP_SHELL = [
  "/vendedor/index.html",
  "/vendedor/dashboard.html",
  "/vendedor/produtos.html",
  "/vendedor/assets/css/vendedor.css",
  "/vendedor/assets/js/vendedor-auth.js",
  "/vendedor/assets/js/vendedor-data.js",
  "/vendedor/assets/js/vendedor-ui.js",
  "/vendedor/manifest.json",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(SM_VENDOR_CACHE_NAME).then((cache) => cache.addAll(SM_VENDOR_APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== SM_VENDOR_CACHE_NAME).map((n) => caches.delete(n)))
    )
  );
  self.clients.claim();
});

function smIsDataRequest(url) {
  return (
    url.pathname.startsWith("/.netlify/functions/") ||
    url.hostname.endsWith(".supabase.co") ||
    url.hostname.includes("mercadopago")
  );
}

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (smIsDataRequest(url) || event.request.method !== "GET") return;

  // Rede primeiro, cache só como reserva offline — ver o comentário
  // equivalente no service-worker.js da raiz do site.
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response && response.ok && url.origin === self.location.origin) {
          const clone = response.clone();
          caches.open(SM_VENDOR_CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

self.addEventListener("push", (event) => {
  let data = { title: "SuperMisto Vendedor", body: "Você tem uma novidade.", url: "/vendedor/dashboard.html" };
  try {
    if (event.data) data = Object.assign(data, event.data.json());
  } catch {
    // usa os valores padrão acima
  }
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "/vendedor/assets/img/icons/icon-192.png",
      badge: "/vendedor/assets/img/icons/icon-192.png",
      data: { url: data.url || "/vendedor/dashboard.html" },
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || "/vendedor/dashboard.html";
  event.waitUntil(clients.openWindow(url));
});
