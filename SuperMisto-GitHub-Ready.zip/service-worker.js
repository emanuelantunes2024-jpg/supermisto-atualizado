/**
 * ============================================================================
 * SUPERMISTO — service-worker.js  (MÓDULO 7 — PWA)
 * ============================================================================
 * Service Worker do site público. Faz três coisas:
 *   1. Cacheia o "app shell" (CSS, JS, ícones, páginas visitadas) para o
 *      site abrir rápido e funcionar offline na segunda visita.
 *   2. Nunca cacheia chamadas ao Supabase nem às Netlify Functions — dados
 *      de produtos/pedidos/preços precisam SEMPRE vir da rede quando
 *      disponível (cache aqui seria perigoso: mostraria preço/estoque
 *      desatualizado). Só cai para o cache se a rede falhar mesmo.
 *   3. Recebe e mostra notificações push (Módulo 7 — ver
 *      assets/js/push-notifications.js para o lado de assinatura).
 *
 * Precisa ficar na RAIZ do site (não dentro de assets/) para o "scope"
 * padrão do navegador cobrir o site inteiro — é por isso que este arquivo
 * está em /service-worker.js e não em /assets/js/.
 * ============================================================================
 */

const SM_CACHE_NAME = "supermisto-v2";
const SM_APP_SHELL = [
  "/",
  "/index.html",
  "/produtos.html",
  "/categorias.html",
  "/assets/css/style.css",
  "/assets/js/products.js",
  "/assets/js/supabase-config.js",
  "/assets/js/supabase-client.js",
  "/assets/js/store.js",
  "/assets/js/main.js",
  "/assets/js/cart.js",
  "/assets/img/logo-purple.png",
  "/assets/img/logo-white.png",
  "/assets/manifest.json",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(SM_CACHE_NAME).then((cache) => cache.addAll(SM_APP_SHELL)).catch(() => {
      // Se algum arquivo do shell não existir/carregar, não trava a
      // instalação do Service Worker — o site simplesmente cacheia menos.
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== SM_CACHE_NAME).map((n) => caches.delete(n)))
    )
  );
  self.clients.claim();
});

function smIsDataRequest(url) {
  return (
    url.pathname.startsWith("/.netlify/functions/") ||
    url.hostname.endsWith(".supabase.co") ||
    url.hostname.includes("mercadopago")
  );
}

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Nunca intercepta chamadas de dados (Supabase/Netlify Functions/
  // Mercado Pago) — sempre rede, nunca cache, para não mostrar
  // preço/estoque/status de pedido desatualizado.
  if (smIsDataRequest(url)) return;

  if (event.request.method !== "GET") return;

  // Estratégia: REDE PRIMEIRO, cache só como reserva para quando estiver
  // offline. Isso é o oposto de "cache primeiro" — importante para que,
  // toda vez que o site for atualizado (novo deploy no Netlify), o
  // visitante sempre veja a versão mais nova assim que tiver conexão,
  // sem depender de um número de versão do cache mudar nem de limpar o
  // Service Worker manualmente. O cache só entra em ação se a rede
  // falhar de verdade (sem internet no momento).
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response && response.ok && url.origin === self.location.origin) {
          const clone = response.clone();
          caches.open(SM_CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

// ---------------------------------------------------------------------------
// Notificações push (Módulo 7)
// ---------------------------------------------------------------------------
self.addEventListener("push", (event) => {
  let data = { title: "SuperMisto", body: "Você tem uma novidade.", url: "/" };
  try {
    if (event.data) data = Object.assign(data, event.data.json());
  } catch {
    // payload não era JSON — usa os valores padrão acima
  }

  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "/assets/img/icons/icon-192.png",
      badge: "/assets/img/icons/icon-192.png",
      data: { url: data.url || "/" },
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || "/";
  event.waitUntil(clients.openWindow(url));
});
