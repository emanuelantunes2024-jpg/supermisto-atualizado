# PROJETO.md — SuperMisto

> Leia este arquivo antes de mexer em qualquer coisa. Ele existe para que
> qualquer pessoa (ou IA) consiga continuar o projeto exatamente de onde ele
> parou, sem precisar adivinhar decisões.

---

## 1. Sobre o projeto

**Nome:** SuperMisto
**Segmento:** Temperos, conservas, molhos, ervas, especiarias, pimentas, chás e kits.
**Objetivo:** Site oficial da marca SuperMisto — catálogo completo, com carrinho, checkout e pedidos nativos do site (além do WhatsApp e link direto para a Shopee) — evoluído em módulos, cada um construído em cima do anterior.

**Etapa atual entregue:** MÓDULO 7 — PWA instalável (site público + portal do vendedor), notificações push reais, e split de pagamento automático entre loja e vendedores via Mercado Pago Marketplace — construído sobre o marketplace e a nota fiscal real do Módulo 6. Site público, painel administrativo e catálogo preservados integralmente — ver seção 19.

---

## 2. Tecnologia utilizada

**Front-end: HTML + CSS + JavaScript puro (vanilla), sem build step, sem framework de UI.**
**Back-end (Etapa 3): Supabase (Postgres + Auth + Storage) + Netlify Functions** (só para a única operação que precisa de credencial secreta — criar administradores).

Por quê essa escolha:
- Zero instalação (`npm install`) necessária para rodar ou publicar o site em si — o Supabase é acessado direto do navegador via `supabase-js`, carregado por CDN (sem passo de build).
- Qualquer pessoa (ou IA futura) consegue entender o código sem aprender uma stack específica.
- Publica no Netlify sem nenhuma configuração de build (as Netlify Functions são detectadas automaticamente a partir de `netlify/functions/`).
- Supabase foi escolhido entre as alternativas (ver seção 14.1) por resolver banco de dados relacional + autenticação + armazenamento de imagens em um único serviço, com plano gratuito suficiente para este projeto, e por se integrar bem com sites estáticos hospedados no Netlify.

Não há dependência de:
- servidor Node próprio rodando 24/7 (as Netlify Functions são serverless, só rodam quando chamadas);
- frameworks de build (Webpack, Vite, etc) para o site em si.

---

## 3. Como executar localmente

Não é necessário instalar nada. Basta servir a pasta como arquivos estáticos. Duas opções:

**Opção A — abrir direto no navegador**
Abra `index.html` no navegador. A navegação entre páginas funciona normalmente
(são páginas HTML separadas, não uma SPA).

**Opção B — servidor local (recomendado, evita eventuais bloqueios de `file://`)**
```bash
cd supermisto
python3 -m http.server 8000
# depois acesse http://localhost:8000
```
ou, com Node instalado:
```bash
npx serve .
```

---

## 4. Como publicar no Netlify

1. Suba a pasta `supermisto/` inteira para um repositório Git (GitHub, GitLab etc.) **ou** arraste a pasta direto no painel do Netlify ("Deploy manually").
2. Configurações de build no Netlify:
   - **Build command:** deixar em branco (não há build).
   - **Publish directory:** `.` (raiz do projeto).
3. O arquivo `netlify.toml` já está na raiz do projeto com essa configuração pronta, incluindo `functions = "netlify/functions"` — o Netlify deve detectar tudo automaticamente (site estático + a Netlify Function).
4. A página `404.html` já está preparada e o Netlify a usa automaticamente para rotas não encontradas.

**A partir da Etapa 3**, para o backend funcionar de verdade, também é
necessário (ver passo a passo completo em `supabase/README.md`):
- Preencher `assets/js/supabase-config.js` com a URL e a chave pública
  (anon key) do seu projeto Supabase.
- Configurar duas variáveis de ambiente no painel do Netlify (Site
  configuration → Environment variables): `SUPABASE_URL` e
  `SUPABASE_SERVICE_ROLE_KEY` (usadas só pelas Netlify Functions, nunca
  expostas ao navegador).

Sem esses dois passos, o site público continua funcionando normalmente com
os dados de fábrica de `products.js` (nunca quebra), mas o painel `/admin`
não libera login enquanto o Supabase não estiver configurado.

**A partir do Módulo 5**, mais três variáveis são opcionais (o projeto
funciona sem elas, só com menos recursos ativos — ver seção 17):

| Variável | Ativa | Obrigatória? |
|---|---|---|
| `MERCADOPAGO_ACCESS_TOKEN` | Pagamento real via Mercado Pago | Não — sem ela, o checkout usa o modo de teste do Módulo 4 |
| `SITE_URL` | URLs de retorno e webhook do Mercado Pago | Só necessária junto com `MERCADOPAGO_ACCESS_TOKEN` |
| `RESEND_API_KEY` + `CONTACT_NOTIFY_EMAIL` | Notificação por e-mail do formulário de contato | Não — a mensagem é salva de verdade de qualquer forma |

**A partir do Módulo 6**, mais duas variáveis são opcionais (sem elas, a
emissão de nota fiscal fica indisponível, mas o resto do projeto — vendas,
marketplace, painel — funciona normalmente; ver seção 18):

| Variável | Ativa | Obrigatória? |
|---|---|---|
| `FOCUS_NFE_API_TOKEN` | Emissão real de nota fiscal (Focus NFe) | Não — sem ela, o botão "Emitir nota fiscal" recusa com aviso claro |
| `FOCUS_NFE_ENVIRONMENT` | `homologacao` (padrão) ou `producao` | Só necessária junto com `FOCUS_NFE_API_TOKEN` |

**A partir do Módulo 7**, mais cinco variáveis são opcionais (sem elas, a
PWA continua instalável normalmente, só sem push nem split de pagamento;
ver seção 19):

| Variável | Ativa | Obrigatória? |
|---|---|---|
| `VAPID_PUBLIC_KEY` (também no código, ver `assets/js/push-config.js`) | Notificações push | Não — sem ela, os botões de ativar notificação não aparecem |
| `VAPID_PRIVATE_KEY` | Notificações push (assinatura) | Só necessária junto com `VAPID_PUBLIC_KEY` |
| `VAPID_CONTACT_EMAIL` | Notificações push (exigido pelo protocolo) | Só necessária junto com as duas acima |
| `MERCADOPAGO_CLIENT_ID` | Split de pagamento (OAuth do vendedor) | Não — sem ela, "Conectar Mercado Pago" recusa com aviso claro |
| `MERCADOPAGO_CLIENT_SECRET` | Split de pagamento (troca do código OAuth) | Só necessária junto com `MERCADOPAGO_CLIENT_ID` |

---

## 5. Estrutura de pastas

```
supermisto/
├── README.md                       → Ponto de entrada rápido do projeto
├── PROJETO.md                      → Este arquivo (documentação completa)
├── netlify.toml                    → Configuração de publicação no Netlify (site + functions)
├── service-worker.js               → 🆕 Módulo 7. Service Worker da PWA do site público
├── index.html                      → Página inicial (Home)
├── produtos.html                   → Catálogo completo (com filtro de categoria e busca)
├── produto.html                    → Página individual de produto (lida via ?id=)
├── categorias.html                 → Listagem de todas as categorias
├── carrinho.html                   → Carrinho de compras
├── checkout.html                   → Finalização da compra (exige login)
├── minha-conta.html                → Login/cadastro de cliente, endereços, pedidos, 🆕 notificações
├── sobre.html                      → Página institucional "Sobre a SuperMisto"
├── contato.html                    → Página de contato (formulário conectado a envio real)
├── privacidade.html                → Placeholder de Política de Privacidade
├── termos.html                     → Placeholder de Termos de Uso
├── 404.html                        → Página de erro 404
│
├── assets/
│   ├── manifest.json                → 🆕 Módulo 7. Manifesto PWA do site público
│   ├── css/
│   │   └── style.css                → TODO o design system do site
│   ├── img/
│   │   ├── logo-purple.png           → Logo oficial (fundos claros)
│   │   ├── logo-white.png             → Logo oficial (fundos roxos)
│   │   └── icons/                      → 🆕 Módulo 7. Ícones da PWA (192/512/apple-touch),
│   │                                     gerados a partir da logo da marca
│   └── js/
│       ├── products.js              → ⭐ DADOS DE FÁBRICA de produtos e categorias
│       │                               (a base original; usada na migração inicial para o
│       │                               Supabase e como FALLBACK automático do site público
│       │                               se o backend não estiver configurado/acessível)
│       ├── supabase-config.js        → Onde colar a URL e a chave pública (anon key) do
│       │                               seu projeto Supabase — ver supabase/README.md
│       ├── supabase-client.js         → Cria o cliente Supabase compartilhado
│       │                                (window.smSupabase), via CDN (sem build)
│       ├── store.js                    → Busca produtos/categorias/banners/configurações
│       │                                 direto do Supabase; se não configurado ou se a
│       │                                 rede falhar, usa os dados de fábrica de
│       │                                 products.js automaticamente (o site nunca quebra)
│       ├── pwa-register.js              → 🆕 Módulo 7. Registra o Service Worker da PWA
│       ├── push-config.js                → 🆕 Módulo 7. Chave pública VAPID (notificações)
│       ├── push-notifications.js          → 🆕 Módulo 7. Assinar/cancelar notificações push
│       ├── cart.js                         → Carrinho de compras (client-side, localStorage)
│       ├── customer-auth.js                 → Login/cadastro de CLIENTE via Supabase Auth
│       ├── main.js                           → Header (carrinho/conta), footer, menu mobile,
│       │                                       busca, funções de renderização de cartões
│       ├── produtos-page.js                   → Lógica exclusiva da página de catálogo
│       ├── product-detail.js                   → Lógica da página de produto individual
│       │                                         (quantidade, estoque, carrinho, galeria)
│       ├── carrinho-page.js                     → Lógica de carrinho.html
│       ├── checkout-page.js                      → Lógica de checkout.html (cria o pedido
│       │                                           e redireciona para pagamento real
│       │                                           quando o gateway estiver configurado)
│       ├── minha-conta-page.js                    → Lógica de minha-conta.html (🆕 + painel
│       │                                            de notificações push)
│       └── contato-page.js                         → Envia o formulário de contato de
│                                                      verdade (Supabase + e-mail best-effort)
│
├── admin/                            → Painel administrativo
│   ├── index.html                      → Login (Supabase Auth)
│   ├── dashboard.html                   → Visão geral (produtos, categorias, pedidos, faturamento)
│   ├── pedidos.html                      → Lista paginada, detalhe e gestão de pedidos,
│   │                                        emitir/consultar nota fiscal (só "owner")
│   ├── clientes.html                      → Lista de clientes cadastrados
│   ├── vendedores.html                     → Aprovar/suspender vendedores, ajustar comissão
│   ├── mensagens.html                       → Mensagens do formulário de contato
│   ├── produtos.html                         → Lista paginada de produtos, mostra estoque
│   ├── produto-form.html                      → Formulário de produto (estoque/NCM/CFOP,
│   │                                             galeria de imagens, histórico do item)
│   ├── categorias.html                         → Gerenciamento de categorias
│   ├── banners.html                             → Gerenciamento de banners da Home
│   ├── destaques.html                            → Destaque/novidade/kit/recomendado
│   ├── historico.html                             → Auditoria de produtos/categorias — só "owner"
│   ├── configuracoes.html                          → WhatsApp/e-mail/redes, administradores
│   │                                                  (papel owner/editor), dados fiscais —
│   │                                                  só "owner"
│   └── assets/
│       ├── css/
│       │   └── admin.css                          → Design system do painel
│       └── js/
│           ├── admin-data.js                        → Camada de dados: CRUD real via Supabase
│           ├── admin-auth.js                          → Autenticação real via Supabase Auth
│           ├── admin-ui.js                             → Sidebar/topbar, paginação genérica,
│           │                                             modal de confirmação genérico
│           ├── admin-dashboard.js                       → Métricas de pedidos/faturamento
│           ├── admin-pedidos.js                          → Lista/detalhe/status de pedidos
│           ├── admin-clientes.js                          → Lista de clientes
│           ├── admin-vendedores.js                         → Gestão de vendedores do marketplace
│           ├── admin-mensagens.js                           → Mensagens de contato
│           ├── admin-historico.js                            → Auditoria de produtos/categorias
│           ├── admin-produtos.js                              → Lista de produtos (paginação)
│           ├── admin-produto-form.js                           → Form de produto (galeria,
│           │                                                     histórico do item)
│           ├── admin-categorias.js                              → Categorias
│           ├── admin-banners.js                                  → Banners
│           ├── admin-destaques.js                                 → Destaques
│           └── admin-configuracoes.js                              → Dados fiscais, papel no
│                                                                     cadastro de administrador
│
├── vendedor/                          → Portal do vendedor (marketplace)
│   ├── manifest.json                    → 🆕 Módulo 7. Manifesto PWA do portal do vendedor
│   ├── service-worker.js                 → 🆕 Módulo 7. Service Worker (escopo /vendedor/)
│   ├── index.html                         → Login (Supabase Auth, separado de admin/cliente)
│   ├── dashboard.html                      → Meus produtos, vendas, comissão a receber,
│   │                                          🆕 conectar Mercado Pago (split), notificações
│   ├── produtos.html                        → Lista dos próprios produtos
│   ├── produto-form.html                     → Adicionar/editar produto (só os próprios)
│   └── assets/
│       ├── css/
│       │   └── vendedor.css                    → Design system (cópia de admin.css)
│       ├── img/icons/                            → 🆕 Módulo 7. Ícones da PWA do vendedor
│       └── js/
│           ├── vendedor-auth.js                    → Login/sessão do vendedor
│           ├── vendedor-data.js                     → CRUD dos próprios produtos/vendas
│           │                                          (escopo garantido por RLS)
│           ├── vendedor-ui.js                        → Sidebar/topbar do portal
│           ├── vendedor-pwa-register.js               → 🆕 Módulo 7. Registra o Service
│           │                                            Worker do portal
│           ├── vendedor-dashboard.js                   → Lógica de dashboard.html (🆕 +
│           │                                             split de pagamento, notificações)
│           ├── vendedor-produtos.js                     → Lógica de produtos.html
│           └── vendedor-produto-form.js                  → Lógica de produto-form.html
│
├── supabase/                         → Tudo relacionado ao backend
│   ├── README.md                        → Guia completo de configuração (passo a passo)
│   ├── schema.sql                        → Schema inicial: categories, products, banners,
│   │                                        settings, admin_profiles, RLS, Storage (Etapa 3)
│   ├── seed-data.sql                      → Migração dos 48 produtos + 8 categorias originais
│   ├── create-first-admin.sql              → Passo a passo para registrar o 1º administrador
│   └── migrations/
│       ├── 001_schema_inicial.sql            → Cópia de schema.sql, para referência histórica
│       ├── 002_modulo4_vendas.sql             → Módulo 4: estoque, campos fiscais, customers,
│       │                                        addresses, orders, order_items,
│       │                                        order_status_history, payments,
│       │                                        fiscal_documents, company_fiscal_info,
│       │                                        sm_create_order()
│       ├── 003_modulo5.sql                     → Módulo 5: papéis (owner/editor), audit_log +
│       │                                          trigger automática, contact_messages
│       ├── 004_modulo6.sql                       → Módulo 6: seller_profiles, products.seller_id,
│       │                                            order_items.seller_id, sm_create_order()
│       │                                            atualizada
│       └── 005_modulo7.sql                         → 🆕 Módulo 7. Conexão OAuth do vendedor
│                                                       com o Mercado Pago (split de pagamento),
│                                                       push_subscriptions — ver seção 19.9
│
└── netlify/
    └── functions/
        ├── package.json                  → 🆕 Módulo 7. Única dependência npm do projeto
        │                                    (web-push, usada só por push-send-notification.js)
        ├── admin-create-user.js           → Cria novos administradores (só "owner" pode)
        ├── checkout-create-order.js        → Cria pedido real (via sm_create_order),
        │                                      🆕 avisa vendedores por push (melhor esforço)
        ├── payment-mock-confirm.js          → MODO DE TESTE — simula confirmação de
        │                                      pagamento (só administradores)
        ├── payment-create-preference.js      → Cria cobrança REAL no Mercado Pago,
        │                                        🆕 com split automático quando aplicável
        ├── payment-webhook-mercadopago.js     → Recebe confirmação do Mercado Pago
        │                                        (sempre revalida na API)
        ├── contact-notify-email.js             → Notifica a loja por e-mail (melhor esforço)
        ├── seller-create.js                     → Cria conta de vendedor (só "owner")
        ├── seller-connect-mercadopago.js          → 🆕 Módulo 7. Inicia OAuth do vendedor
        │                                             com o Mercado Pago — ver seção 19.5
        ├── seller-mercadopago-callback.js          → 🆕 Módulo 7. Troca o código OAuth por
        │                                              token real do vendedor
        ├── push-send-notification.js                → 🆕 Módulo 7. Envia notificação push
        │                                                real (Web Push/VAPID)
        ├── fiscal-emit-nfe.js                         → Emite NFC-e REAL via Focus NFe
        └── fiscal-check-status.js                      → Consulta status real de uma
                                                            emissão pendente
```

---

## 6. Onde ficam os produtos (MUITO IMPORTANTE)

**Os dados de fábrica do catálogo vivem em:** `assets/js/products.js`.

Esse continua sendo o ponto de partida (a "base" usada na migração inicial
e como fallback), mas o que o site público **efetivamente exibe** vem do
banco de dados real (Supabase) quando configurado, através de
`assets/js/store.js` — ver seção 14 para entender exatamente como isso
funciona e o que acontece se o backend não estiver configurado ou ficar
fora do ar.

Esse arquivo exporta dois arrays para `window`:
- `window.SUPERMISTO_CATEGORIES` → lista de categorias (slug, nome, ícone, cores, descrição).
- `window.SUPERMISTO_PRODUCTS` → lista de produtos.

Cada produto segue este formato (campos opcionais — produtos antigos
continuam funcionando sem eles):
```js
{
  id: "alho-desidratado",        // identificador único, usado na URL produto.html?id=...
  name: "Alho Desidratado",
  category: "temperos",          // precisa bater com um "slug" de CATEGORIES
  price: 9.9,                    // número, em reais
  salePrice: 7.9,                // opcional — preço promocional
  costPrice: 6.5,                // opcional — custo interno (Etapa 3, NUNCA aparece no site público)
  weight: "100g",                // texto livre
  shortDesc: "...",              // descrição curta (cartões)
  description: "...",            // descrição longa (página do produto)
  emoji: "🧄",                    // usado como ilustração enquanto não há foto real
  image: "assets/img/produtos/alho.jpg", // opcional — foto real (ver seção 7)
  images: ["assets/img/produtos/alho-2.jpg"], // opcional — fotos adicionais
  available: true,                // opcional — disponibilidade (default true)
  featured: true,                 // aparece em "Produtos em destaque" na Home
  isNew: false,                   // selo "Novidade"
  isKit: false,                   // selo "Kit"
  recommended: false,             // opcional — aparece em "Recomendados" na Home
  buyLink: "#",                   // link externo de compra (Shopee, etc). "#" = placeholder
  whatsappMessage: "..."          // opcional — mensagem de WhatsApp específica deste produto
}
```

**Para adicionar um produto:** use o painel em `/admin/produto-form.html` —
a partir da Etapa 3, isso grava direto no banco de dados real (Supabase) e
o produto aparece para todo mundo, em qualquer dispositivo. Editar
`products.js` diretamente ainda funciona como "dados de fábrica" (usado na
migração inicial e como fallback), mas deixa de ser o método recomendado no
dia a dia, já que o banco é a fonte de verdade quando está configurado.

**Para adicionar uma foto real:** use o campo de upload de imagem no
formulário do painel (produto ou categoria/banner) — a imagem é enviada de
verdade para o Supabase Storage e a URL pública é salva automaticamente no
produto. O código em `main.js` (função `productMediaHTML`) já está
preparado para usar essa imagem no lugar do emoji automaticamente, sem
precisar mudar mais nada.

**Para adicionar uma categoria nova:** use `/admin/categorias.html`. Ela
aparecerá automaticamente na Home, em `categorias.html` e nos filtros de
`produtos.html` (a menos que esteja marcada como inativa — ver seção 14).

---

## 7. Onde ficam as imagens

- Logos oficiais: `assets/img/logo-purple.png` e `assets/img/logo-white.png` (fornecidas pelo cliente, não recriar).
- Fotos de produtos reais: ainda não existem. Quando forem adicionadas, devem ir em `assets/img/produtos/` e ser referenciadas pelo campo `image` de cada produto em `products.js` (ver seção 6).
- Enquanto não há fotos reais, os produtos usam um emoji ilustrativo sobre um fundo colorido (definido por categoria), o que mantém o layout consistente e nunca "quebrado".

---

## 8. Cores utilizadas (design tokens)

Definidas em `:root` no topo de `assets/css/style.css`. A cor roxa principal
(`--purple-700: #3A1150`) foi extraída diretamente da logo oficial fornecida,
garantindo consistência com a identidade visual real da marca.

| Token | Valor | Uso |
|---|---|---|
| `--purple-900` a `--purple-50` | de `#1E0B2E` a `#FAF5FC` | Escala de roxo — fundo do header roxo, hero, footer, botões |
| `--cream` | `#FBF7F1` | Fundo geral do site |
| `--ink` | `#1E1626` | Texto principal |
| `--paprika` | `#A6402C` | Acento secundário (eyebrows, selo "Destaque") |
| `--gold` | `#B7883C` | Acento pontual (selo "Kit"), usado com moderação, conforme pedido no briefing |
| `--herb` | `#4B7A4E` | Acento verde (selo "Novidade", ícones de qualidade) |

Tipografia: **Fraunces** (serifada, para títulos — dá o tom "artesanal/premium") + **Inter** (sã-serifada, para texto). Carregadas via Google Fonts no topo do CSS.

Elemento de assinatura visual: a onda roxa na base do Hero e os ícones em
formato de folha/ramo (ecoando o "sprig" da logo) usados como identidade
recorrente nas seções de categoria e diferenciais.

---

## 9. Páginas existentes e o que fazem

| Página | Arquivo | Descrição |
|---|---|---|
| Home | `index.html` | Hero, categorias, produtos em destaque, diferenciais, novidades, kits, newsletter |
| Catálogo | `produtos.html` | Todos os produtos, com filtro por categoria (sidebar), busca e ordenação. Aceita `?categoria=slug` e `?busca=termo` na URL |
| Produto | `produto.html?id=...` | Página individual com foto, preço, descrição, seletor de quantidade, botão "Adicionar ao carrinho", botão WhatsApp e produtos relacionados |
| Categorias | `categorias.html` | Grade com todas as categorias disponíveis |
| **Carrinho** | `carrinho.html` | Itens adicionados, quantidade, subtotal — ver seção 16.1 |
| **Checkout** | `checkout.html` | Endereço de entrega, forma de pagamento, confirmação do pedido (exige login) — ver seção 16.3 |
| **Minha Conta** | `minha-conta.html` | Login/cadastro de cliente, endereços, histórico de pedidos, 🆕 ativar notificações push — ver seção 19.4 |
| Sobre | `sobre.html` | Texto institucional genérico (editável), valores da marca |
| Contato | `contato.html` | WhatsApp, e-mail, redes sociais, formulário de contato conectado a envio real (ver seção 17.5) |
| Privacidade / Termos | `privacidade.html` / `termos.html` | Placeholders identificados, prontos para receber texto jurídico real |
| 404 | `404.html` | Página de erro amigável |
| **Painel — Login** | `admin/index.html` | Login real via Supabase Auth, e-mail e senha (ver seção 14.4) |
| **Painel — Dashboard** | `admin/dashboard.html` | Contagens gerais, métricas de pedidos/faturamento, atalhos |
| **Painel — Pedidos** | `admin/pedidos.html` | Lista paginada, filtro por status, detalhe completo, mudança de status, simular pagamento, emitir/consultar nota fiscal (só "owner") |
| **Painel — Clientes** | `admin/clientes.html` | Lista de clientes cadastrados e contagem de pedidos |
| **Painel — Vendedores** | `admin/vendedores.html` | Aprovar/suspender vendedores do marketplace, ajustar comissão, criar conta — só "owner" |
| **Painel — Mensagens** | `admin/mensagens.html` | Mensagens recebidas pelo formulário de contato |
| **Painel — Produtos** | `admin/produtos.html` | Lista paginada, busca e filtra produtos; duplicar e excluir; mostra estoque |
| **Painel — Produto (form)** | `admin/produto-form.html?id=...` | Adicionar ou editar produto; campos de estoque/NCM/CFOP; galeria de imagens e histórico de auditoria |
| **Painel — Categorias** | `admin/categorias.html` | Adicionar, editar, ativar/desativar e excluir categorias |
| **Painel — Banners** | `admin/banners.html` | Adicionar, editar, ativar/desativar, ordenar e excluir banners da Home |
| **Painel — Destaques** | `admin/destaques.html` | Marcar em massa quais produtos são destaque/novidade/kit/recomendado |
| **Painel — Histórico** | `admin/historico.html` | Auditoria de alterações em produtos/categorias — só "owner" |
| **Painel — Configurações** | `admin/configuracoes.html` | WhatsApp, e-mail, redes sociais, gestão de administradores (papel owner/editor), dados fiscais da empresa — só "owner" |
| **Vendedor — Login** | `vendedor/index.html` | Login do vendedor do marketplace, separado de admin/cliente |
| **Vendedor — Dashboard** | `vendedor/dashboard.html` | Meus produtos, vendas, comissão a receber, 🆕 conectar Mercado Pago (split de pagamento) e ativar notificações — ver seção 19.4/19.5 |
| **Vendedor — Produtos** | `vendedor/produtos.html` | Lista dos próprios produtos |
| **Vendedor — Produto (form)** | `vendedor/produto-form.html?id=...` | Adicionar/editar produto (só os próprios, com upload de imagem) |

**PWA (Módulo 7):** `assets/manifest.json` + `service-worker.js` (site
público) e `vendedor/manifest.json` + `vendedor/service-worker.js`
(portal do vendedor) tornam ambas as áreas instaláveis na tela inicial do
celular — ver seção 19.

---

## 10. O que já foi implementado (Etapa 1)

- [x] Header responsivo com busca, menu mobile (drawer) e ícone de WhatsApp
- [x] Hero de marca (não é só texto — tem elemento visual, badges flutuantes, estatísticas)
- [x] Seção de categorias com cartões (8 categorias iniciais)
- [x] Catálogo completo com filtro por categoria, busca e ordenação (relevância / menor preço / maior preço / nome)
- [x] +45 produtos de demonstração distribuídos entre todas as categorias do briefing
- [x] Página individual de produto com produtos relacionados
- [x] Busca funcional (campo no header redireciona para `produtos.html?busca=...`)
- [x] Página Sobre com texto institucional genérico e editável
- [x] Página de Contato com WhatsApp, e-mail, formulário (sem back-end) e placeholders claramente identificados (sem inventar telefone/endereço reais)
- [x] Rodapé completo (logo, links, categorias, contato, redes sociais, política de privacidade, termos, copyright dinâmico)
- [x] Design 100% responsivo, mobile-first
- [x] Dados de produtos 100% centralizados em `products.js` (nenhum dado espalhado pelo código)
- [x] Botão flutuante de WhatsApp em todas as páginas
- [x] Animações leves de entrada (reveal on scroll) e transições suaves
- [x] `netlify.toml` pronto para publicação
- [x] `404.html` pronta

## 11. O que ainda NÃO foi implementado (de propósito, é o esperado nesta etapa)

Banco de dados real, autenticação real, sincronização entre dispositivos e
upload de imagens (Etapa 3); carrinho, checkout, pedidos, clientes,
estoque e preparação fiscal (Módulo 4); pagamento online real, galeria de
imagens, histórico/auditoria, papéis de administrador e contato conectado
a envio real (Módulo 5); emissão real de nota fiscal e marketplace de
múltiplos vendedores (Módulo 6); PWA instalável, notificações push reais
e split de pagamento automático (Módulo 7) **já foram implementados** —
ver seções 14, 16, 17, 18 e 19. O que ainda falta, por decisão explícita
de escopo:

- Integração com Shopee / links de compra externos continuam funcionando como estavam (`buyLink`), agora em paralelo ao "Adicionar ao carrinho" nativo do site e ao pagamento real via Mercado Pago.
- Avaliações de clientes, informações nutricionais, ingredientes, validade, vídeos do produto.
- Checkout como convidado (sem conta) — hoje o checkout exige login de cliente, por decisão de escopo (ver seção 16.3).
- Split de pagamento com mais de um vendedor no mesmo carrinho — hoje o split só se aplica quando todos os itens do pedido são de um único vendedor conectado; limitação real da API do Mercado Pago, documentada na seção 19.5.
- Bloqueio automático de produtos de vendedor suspenso no site público (hoje é uma ação manual do administrador — ver seção 18.3).
- Aplicativo nativo compilado (Google Play/App Store) — a PWA (Módulo 7) já é instalável e funcional hoje; o caminho para um app nativo de verdade está documentado na seção 19.6.

Ver seções 16 (Módulo 4), 17 (Módulo 5), 18 (Módulo 6) e 19 (Módulo 7), e
"PRÓXIMAS ETAPAS" no final deste documento, para o planejamento de cada
um desses itens.

**Locais exatos onde ficam os valores de fábrica (fallback), usados apenas
se o Supabase nunca for configurado ou ficar fora do ar:**
- Número de WhatsApp → `assets/js/main.js`, constante `WHATSAPP_NUMBER`
- E-mail de contato → aparece em `main.js` (footer) e `contato.html`
- Links de redes sociais → `main.js` (`renderHeader`/`renderFooter`) e `contato.html`

Quando o Supabase está configurado, os valores reais vêm de
`admin/configuracoes.html` (tabela `settings` do banco) em vez desses
placeholders.

---

## 12. Regras importantes para quem for continuar

1. **Nunca** espalhe dados de produtos direto em HTML. A fonte de verdade agora é o banco de dados (Supabase) quando configurado, gerenciado por `admin/assets/js/admin-data.js` e lido no site público por `assets/js/store.js` — `assets/js/products.js` continua existindo como dados de fábrica/fallback (ver seção 14).
2. O painel administrativo trabalha com o mesmo "formato de produto" (camelCase) de sempre — a conversão para as colunas do banco (snake_case) é feita dentro de `admin-data.js` e `store.js`, então o front-end público e as telas do painel não precisaram ser redesenhadas.
3. O CSS já tem um sistema de tokens (`:root` em `style.css`, reaproveitado por `admin.css` via `@import`) — use as variáveis existentes em vez de criar cores soltas novas.
4. Mantenha o site funcionando sem build step enquanto for viável. As Netlify Functions (`netlify/functions/`) são a única parte que roda em um servidor (serverless) — mesmo assim, sem passo de build, sem dependências npm.
5. Teste sempre em mobile primeiro.
6. **Nunca coloque a `service_role` key do Supabase em nenhum arquivo servido ao navegador** (nada dentro de `assets/`, `admin/assets/`, ou qualquer `.html`). Ela só pode existir como variável de ambiente no Netlify, usada exclusivamente dentro de `netlify/functions/`. A `anon key` (pública) é a única chave que pode aparecer no código do site — ver seção 14.4.
7. Ao adicionar uma nova tabela ou coluna no banco, sempre habilite RLS e escreva as políticas de acesso (seguindo o padrão de `supabase/schema.sql`) antes de usar a tabela em produção — uma tabela sem RLS fica com os dados totalmente expostos.

---

## 13. ETAPA 2 (histórico) — SISTEMA ADMINISTRATIVO COM LOCALSTORAGE

A Etapa 2 criou o painel `/admin` inteiro (dashboard, produtos, categorias,
banners, destaques, configurações) com um login de demonstração e
persistência via `localStorage` do navegador — sem backend real. A Etapa 3
(seção 14) substituiu completamente esse mecanismo por um banco de dados
real, mantendo as mesmas telas e o mesmo visual. Os detalhes técnicos de
como o localStorage funcionava não se aplicam mais ao projeto atual e foram
removidos desta versão do documento para evitar confusão — se precisar
consultar como era a Etapa 2, veja o arquivo `SuperMisto-Admin-Etapa2.zip`
entregue anteriormente.


## 14. ETAPA 3 — BACKEND REAL (SUPABASE)

### 14.1 Tecnologia escolhida e por quê

Antes de implementar, avaliamos três caminhos:

| Opção | Prós | Contras para este projeto |
|---|---|---|
| **Supabase** (Postgres + Auth + Storage) | Banco relacional (bate com o formato produto→categoria já existente), Auth e Storage no mesmo serviço, SDK JS que funciona direto do navegador sem build, plano gratuito generoso | — |
| Firebase (Firestore) | Também gratuito e popular | Banco NoSQL — modelar categorias/produtos relacionados exigiria mais trabalho e ficaria menos natural que o Postgres do Supabase |
| Servidor Node próprio + banco próprio | Controle total | Precisaria de hospedagem separada (o Netlify não roda servidor Node persistente), mais caro e mais complexo de manter para um catálogo pequeno |

**Escolhemos Supabase** por resolver banco + autenticação + armazenamento
de imagens em um único lugar, com uma chave pública (anon key) desenhada
para ser usada com segurança direto do navegador (protegida por RLS —
Row Level Security), o que combina perfeitamente com um site estático
hospedado no Netlify, sem exigir nenhum passo de build.

### 14.2 O que foi implementado

- **Banco de dados real** (Postgres, via Supabase): tabelas `products`,
  `categories`, `banners`, `settings`, `admin_profiles` — ver
  `supabase/schema.sql`.
- **Migração dos dados originais**: os 48 produtos e 8 categorias da Etapa
  1/2 foram migrados para o banco via `supabase/seed-data.sql`, gerado
  automaticamente a partir de `assets/js/products.js`. O script é
  idempotente (`ON CONFLICT ... DO UPDATE`) — rodar de novo nunca duplica
  nada.
- **API seguindo os dados**: não escrevemos uma API HTTP própria — o
  próprio Supabase expõe uma API REST automática sobre as tabelas
  (PostgREST), protegida por RLS. `admin-data.js` (painel) e `store.js`
  (site público) conversam com essa API através do SDK oficial
  `@supabase/supabase-js`, carregado via CDN.
- **Autenticação real**: Supabase Auth (e-mail + senha), substituindo o
  portão de demonstração da Etapa 2 — ver seção 14.4.
- **Sincronização real entre dispositivos**: qualquer alteração salva no
  painel grava direto no banco; qualquer visitante do site público, em
  qualquer dispositivo, busca os dados atualizados do mesmo banco a cada
  carregamento de página — ver seção 14.3.
- **Upload de imagens real**: Supabase Storage, com dois buckets públicos
  de leitura (`products`, `banners`) e upload restrito a administradores
  autenticados — usado nos formulários de produto, categoria e banner.
- **CRUD completo** de produtos (adicionar/editar/excluir/duplicar),
  categorias (adicionar/editar/excluir/ativar/desativar), banners e
  destaques — tudo migrado de `localStorage` para chamadas reais ao banco.
- **Custo/preço interno**: novo campo opcional `costPrice` no formulário de
  produto, guardado no banco (`cost_price`) mas **nunca enviado ao site
  público** — fica só visível no painel, para cálculo de margem.
- **Gestão de administradores**: tela em Configurações → Administradores,
  que usa uma Netlify Function (`netlify/functions/admin-create-user.js`)
  para criar novos logins com segurança — ver seção 14.5.
- **Site público inalterado visualmente**: design, navegação, identidade
  visual e conteúdo continuam os mesmos da Etapa 1. A única diferença
  visível para o usuário final é que os dados agora vêm do banco em vez do
  arquivo estático (e ele nem percebe isso).
- **Painel com o mesmo visual da Etapa 2**: sidebar, cores, tabelas,
  formulários — nada mudou visualmente. Só a "cor da fonte de dados" por
  trás mudou. O badge do topo, que antes dizia "Modo demonstração", agora
  diz "Conectado ao banco".

### 14.3 Como a sincronização funciona agora

`assets/js/store.js` substituiu o `assets/js/store-sync.js` da Etapa 2.
Toda página pública, ao carregar, chama `await smStoreInit()` antes de
desenhar qualquer produto/categoria/banner na tela. Essa função:

1. Verifica se `assets/js/supabase-config.js` foi preenchido com credenciais
   reais.
2. Se sim, busca `categories`, `products`, `banners` (só os ativos) e
   `settings` direto do banco, em paralelo, e substitui
   `window.SUPERMISTO_PRODUCTS` / `CATEGORIES` / `BANNERS` / `SETTINGS`
   pelos dados reais.
3. Se o Supabase não estiver configurado, **ou** se qualquer chamada
   falhar (sem internet, projeto Supabase fora do ar, chave errada etc.),
   cai automaticamente para os dados de fábrica de `products.js` — o site
   nunca quebra, nunca mostra tela em branco.

Do lado do painel, `admin-data.js` faz o caminho inverso: toda leitura e
escrita (`smGetProducts`, `smAddProduct`, `smUpdateProduct`,
`smDeleteProduct`, `smDuplicateProduct`, e os equivalentes de categorias/
banners/configurações) chama a API do Supabase diretamente — não existe
mais nenhuma camada de `localStorage` no meio.

**Teste que prova a sincronização real:** edite um produto no painel em um
navegador, depois abra o site público em outro navegador/dispositivo — a
alteração aparece lá, porque os dois estão lendo do mesmo banco. Isso é
a diferença fundamental em relação à Etapa 2 (onde cada navegador tinha
sua própria cópia isolada em `localStorage`).

### 14.4 Autenticação — o que mudou

A tela de login (`admin/index.html`) agora pede e-mail e senha reais,
validados pelo Supabase Auth (`admin/assets/js/admin-auth.js`):

- **Senha nunca em texto puro**: o Supabase guarda só o hash da senha, em
  um banco que este projeto não tem acesso direto — bem diferente da senha
  fixa (`supermisto2026`) que ficava visível no código-fonte na Etapa 2.
- **Sessão real**: a sessão é um token JWT assinado pelo Supabase, renovado
  automaticamente pelo SDK — não é mais uma flag simples em
  `sessionStorage` que qualquer um podia forjar no console do navegador.
- **Proteção reforçada no banco, não só na interface**: mesmo que alguém
  conseguisse burlar a tela de login, toda escrita no banco (INSERT/UPDATE/
  DELETE) é bloqueada pelas políticas de RLS de `supabase/schema.sql` a
  menos que o pedido carregue um token válido de sessão autenticada. Ou
  seja, a segurança não depende só do JavaScript do painel se comportar
  bem.
- **Sem cadastro público**: não existe tela de "criar conta" em lugar
  nenhum do site. O primeiro administrador é criado manualmente pelo painel
  do Supabase (`supabase/create-first-admin.sql`); administradores
  seguintes são criados de dentro do próprio painel `/admin` (ver seção
  14.5).
- **Todas as páginas do painel protegidas**: `admin-auth.js` expõe
  `smAdminGuard()`, chamada no `<head>` de toda página interna do painel,
  que verifica a sessão antes mesmo do conteúdo ser desenhado na tela
  (mostrando um overlay "Verificando acesso..." nesse meio tempo) e
  redireciona para o login se não houver sessão válida.

### 14.5 Criando mais administradores (e por que precisa de uma Netlify Function)

Criar um novo usuário no Supabase Auth por código exige um poder que a
chave pública (anon key) não tem — só a chave `service_role` (secreta) pode
fazer isso. Como essa chave nunca pode aparecer no navegador, essa única
operação roda do lado do servidor, em
`netlify/functions/admin-create-user.js`:

1. O painel (`admin-configuracoes.js`) manda um pedido para
   `/.netlify/functions/admin-create-user`, incluindo o token da sessão
   atual (prova de que quem está pedindo já é um administrador logado).
2. A função valida esse token contra o Supabase antes de fazer qualquer
   coisa — se o token for inválido ou tiver expirado, recusa com erro 401.
3. Só então usa a `service_role` key (lida de uma variável de ambiente do
   Netlify, nunca do código) para criar o novo usuário no Supabase Auth e
   o perfil correspondente na tabela `admin_profiles`.

Essa função não usa nenhuma biblioteca externa (só `fetch`, nativo do
runtime Node do Netlify), então não precisa de nenhum passo de instalação
de dependências — o Netlify já detecta e publica a função junto com o
resto do site.

### 14.6 O que NÃO foi implementado nesta etapa (por decisão explícita do escopo)

- Pagamentos online, checkout ou carrinho de compras.
- Emissão fiscal / nota fiscal eletrônica.
- Aplicativo nativo (isso é a Etapa 6, ver "PRÓXIMAS ETAPAS" no final deste documento).
- Controle de estoque numérico (continua sendo só "disponível"/"indisponível" — um número de estoque real entraria numa etapa futura de gestão de vendas).
- Histórico de alterações (quem mudou o quê e quando) — o banco tem `created_at`/`updated_at`, mas não um log de auditoria completo.
- Paginação na lista de produtos do painel (com 48-100 produtos ainda é confortável rolar a página; vale revisitar se o catálogo crescer muito).
- Múltiplas fotos por produto com galeria visual na página do produto (o campo `images[]` existe no banco e no formulário, mas a página pública ainda mostra só a imagem principal).

### 14.7 Testes realizados

Como o ambiente onde este projeto foi desenvolvido não tem acesso à
internet para criar um projeto Supabase de verdade e testar contra a API
real, os testes abaixo foram feitos executando o **código real do
projeto** (`admin-data.js`, `admin-auth.js`, `store.js`, a Netlify
Function) contra um cliente Supabase simulado (mock) que reproduz o
comportamento da API do Supabase (consultas, filtros, inserção, updates,
exclusão, autenticação, upload). Isso comprova que a lógica do código está
correta; o passo que só você pode fazer é criar o projeto Supabase real e
colar as credenciais (`supabase/README.md`), depois do que os mesmos
fluxos passam a valer contra o banco de verdade.

**63 testes automatizados, todos passando:**

- **Produtos (13 testes):** listar, buscar por ID, atualizar (nome e
  preço), gerar ID único a partir do nome, adicionar, duplicar, excluir —
  com verificação de contagem em cada passo, confirmando que a integridade
  dos 48 produtos originais se mantém depois de qualquer sequência de
  operações.
- **Categorias (8 testes):** listar (8 categorias), contar produtos por
  categoria, adicionar, ativar/desativar, excluir — confirmando volta a 8
  categorias no final.
- **Banners (5 testes):** adicionar, listar, ativar/desativar, excluir.
- **Configurações (3 testes):** salvar e reler WhatsApp/e-mail/redes
  sociais.
- **Upload de imagem (1 teste):** confirma que `smUploadImage` retorna uma
  URL pública válida.
- **Administradores (1 teste):** lista o administrador semeado.
- **Autenticação (5 testes):** não está logado antes do login; login com
  senha errada falha com mensagem amigável; login com senha certa
  funciona; sessão fica válida depois do login; usuário atual é
  identificado corretamente.
- **Sincronização do site público / `store.js` (14 testes):** com Supabase
  disponível (produtos, categorias filtrando inativas, preço promocional,
  banners ativos, configurações — todos refletindo o banco); sem Supabase
  configurado (fallback total para `products.js`, nunca quebra); com
  Supabase configurado mas a rede falhando no meio da consulta (mesmo
  fallback, comprovando que uma queda do backend não tira o site do ar).
- **Netlify Function `admin-create-user` (11 testes):** rejeita sem
  variáveis de ambiente configuradas; rejeita sem token; rejeita token
  inválido; rejeita senha curta; fluxo de sucesso completo (cria usuário
  com e-mail confirmado, cria o perfil, retorna 200); responde certo ao
  preflight CORS (OPTIONS).

Além disso, antes de fechar a etapa, foram verificados: sintaxe de 100% dos
arquivos `.js` do projeto (`node --check`), todos os links `src`/`href`
apontando para arquivos que realmente existem, balanceamento de tags HTML
em todas as páginas, e que `assets/js/products.js` permanece byte a byte
idêntico ao da Etapa 2 (nunca foi tocado — continua sendo o fallback
confiável).

**O que não pôde ser testado neste ambiente** (e por quê): a chamada real
à internet contra um projeto Supabase de verdade, incluindo latência real,
comportamento exato do RLS do Postgres em produção, e o comportamento do
upload de imagem contra o Storage real. Isso só pode ser validado depois
que você seguir `supabase/README.md` e configurar seu próprio projeto — o
passo 8 desse guia é exatamente esse teste final.

### 14.8 Arquivos criados/modificados nesta etapa

**Novos:**
`supabase/schema.sql`, `supabase/seed-data.sql`,
`supabase/create-first-admin.sql`, `supabase/README.md`,
`assets/js/supabase-config.js`, `assets/js/supabase-client.js`,
`assets/js/store.js`, `netlify/functions/admin-create-user.js`.

**Reescritos por completo:** `admin/assets/js/admin-data.js`,
`admin/assets/js/admin-auth.js`, `admin/index.html`, e todos os scripts de
página do painel (`admin-dashboard.js`, `admin-produtos.js`,
`admin-produto-form.js`, `admin-categorias.js`, `admin-banners.js`,
`admin-destaques.js`, `admin-configuracoes.js`) para o padrão assíncrono
com chamadas reais ao Supabase.

**Editados (ajustes pontuais):** `assets/js/main.js` e
`assets/js/product-detail.js` (aguardam `smStoreInit()` antes de
renderizar; fallback de "Sem categoria"), `admin/assets/js/admin-ui.js`
(texto do rodapé/badge do topo), `netlify.toml` (registra
`netlify/functions/`), e as 9 páginas públicas (trocaram o include de
`store-sync.js` pela nova cadeia `supabase-config.js` → `supabase-
client.js` → `store.js`).

**Removidos** (substituídos pelos itens acima): `assets/js/store-sync.js`.

**Não tocados:** `assets/js/products.js` (fonte de fábrica/fallback,
permanece idêntico), todo o HTML/CSS do site público (design, navegação,
conteúdo institucional), `admin/assets/css/admin.css`.

---

## 15. ETAPA 4 — PRÓXIMO PASSO (histórico — plano escrito antes do Módulo 4)

> Esta seção foi escrita como planejamento, antes do Módulo 4 existir. O
> Módulo 4 (seção 16) acabou tendo um escopo maior do que o esboçado aqui
> — pedidos, checkout, pagamentos e clientes completos, não só estoque.
> Os itens abaixo que **não** entraram no Módulo 4 continuam pendentes
> para uma etapa futura (ver seção 17).

Com backend, banco, autenticação e sincronização real resolvidos, o próximo
passo deveria focar no que ainda faltava para uma operação de e-commerce
mais madura:

- ~~**Controle de estoque numérico**~~ → ✅ implementado no Módulo 4.
- **Galeria de imagens** na página do produto público, usando o campo
  `images[]` que já existe no banco e no formulário. → ainda pendente.
- **Histórico/auditoria** de alterações em produtos/categorias → ainda
  pendente (o Módulo 4 trouxe histórico só para pedidos, em
  `order_status_history`).
- **Papéis de administrador** diferenciados → ainda pendente (a coluna
  `role` existe em `admin_profiles`, mas todo admin tem o mesmo acesso).
- **Conectar o formulário de contato** (`contato.html`) a um envio real →
  ainda pendente.
- **Paginação e busca mais avançada** no painel → ainda pendente.

---

## 16. MÓDULO 4 — PLATAFORMA DE VENDAS

### 16.1 O que foi implementado

Construído inteiramente sobre a Etapa 3, sem remover ou quebrar nada: os
48 produtos, 8 categorias, o painel administrativo, a autenticação de
administrador e o site público continuam funcionando exatamente como
antes. O Módulo 4 adiciona uma camada de vendas completa por cima:

- **Carrinho de compras** (`assets/js/cart.js`) — client-side
  (localStorage), com adicionar/remover/alterar quantidade, cálculo de
  subtotal, e resolução automática contra os dados reais do catálogo
  (remove sozinho qualquer item que tenha ficado indisponível).
- **Conta de cliente** (`assets/js/customer-auth.js`,
  `minha-conta.html`) — cadastro e login via Supabase Auth, separado do
  login de administrador; histórico de pedidos; endereços salvos.
- **Checkout** (`checkout.html`, `assets/js/checkout-page.js`) — exige
  login, monta o endereço de entrega, e envia o pedido para a Netlify
  Function `checkout-create-order.js`.
- **Pedidos** — criados de forma atômica no banco pela função SQL
  `sm_create_order()` (ver seção 16.3), com status estruturados
  (`aguardando_pagamento` → `pagamento_aprovado` → `em_preparacao` →
  `pronto_envio` → `enviado` → `entregue`, além de `cancelado` e
  `reembolsado`), histórico de alterações, endereço e dados do cliente
  "congelados" no momento da compra (snapshot).
- **Estoque** — cada produto ganhou `trackStock` (liga/desliga o controle)
  e `stockQuantity`. Quando ligado, o checkout valida e dá baixa
  automaticamente, de forma atômica (sem condição de corrida — ver 16.3).
  Produtos sem controle de estoque continuam funcionando exatamente como
  na Etapa 2/3 (só "disponível"/"indisponível").
- **Pagamentos** — arquitetura pronta (tabela `payments`, status
  `pending`/`approved`/`refused`/`cancelled`/`refunded`), mas **sem
  nenhum gateway real conectado nesta etapa** (ver 16.2, obrigatório ler).
- **Painel administrativo ampliado** — `admin/pedidos.html` (lista,
  filtro por status, detalhe completo, mudança de status, botão de
  simular pagamento) e `admin/clientes.html` (lista de clientes com
  contagem de pedidos), sem quebrar nenhuma tela existente.
- **Preparação fiscal** — tabela `fiscal_documents` (estado de uma futura
  nota fiscal) e `company_fiscal_info` (dados da empresa), editável em
  Configurações → Dados fiscais da empresa. **Nenhuma nota fiscal é
  emitida de verdade** (ver 16.4).
- **Correção de segurança:** políticas de RLS que assumiam "todo usuário
  autenticado é administrador" (só era verdade até aqui) foram corrigidas
  para uma função `sm_is_admin()` que checa `admin_profiles` de verdade —
  necessário porque agora clientes também se autenticam.

### 16.2 Pagamentos — o que é real e o que é modo de teste

**MODO DE TESTE, não é pagamento real.** Não existe, nesta etapa, nenhuma
integração com Mercado Pago, Stripe, PagSeguro ou qualquer outro gateway.
O que existe:

- Toda a estrutura de dados para representar um pagamento (`payments`):
  valor, status, método, ID de transação, data — pronta para receber dados
  de um gateway real sem precisar mudar o formato.
- Uma Netlify Function, `netlify/functions/payment-mock-confirm.js`, que
  **simula** a confirmação de pagamento — só o administrador pode acioná-la
  (botão "Simular pagamento aprovado/recusado" em `admin/pedidos.html`),
  para permitir testar o fluxo completo do pedido sem depender de um
  gateway configurado.
- Todo pedido criado pelo checkout começa com `payment_status: "pending"`
  e status `"aguardando_pagamento"` — nenhuma cobrança é feita em lugar
  nenhum.

**O que uma integração real exigiria** (ex.: Mercado Pago, escolha comum
no Brasil):
1. Criar conta no gateway escolhido e obter as credenciais de API.
2. Guardar essas credenciais como variáveis de ambiente no Netlify (nunca
   no código) — ex.: `MERCADOPAGO_ACCESS_TOKEN`.
3. Criar uma nova Netlify Function (ex.: `payment-create-preference.js`)
   que, a partir de um pedido já criado por `sm_create_order()`, chama a
   API do gateway para gerar o link/QR code de pagamento.
4. Criar um webhook (outra Netlify Function, ex.: `payment-webhook.js`)
   que recebe a notificação assinada do gateway quando o pagamento muda
   de status, valida a assinatura, e atualiza `payments`/`orders` do
   mesmo jeito que `payment-mock-confirm.js` já faz — ou seja, a função
   mock já serve de modelo de como a atualização de status deve
   acontecer, só troca quem a aciona (o gateway, não o painel).
5. Trocar o botão "Simular pagamento" do painel pelo link/QR code real
   gerado no passo 3.

### 16.3 Carrinho, checkout e estoque — como a integridade é garantida

O carrinho em si é só uma lista de `{produto, quantidade}` guardada no
navegador — rápido, funciona sem login, mas **não é fonte de verdade**
para preço nem estoque. A fonte de verdade é sempre o banco, verificada
no momento exato do checkout:

1. O navegador manda para `checkout-create-order.js` só os
   `productId`/`quantity` de cada item — nunca um preço.
2. A função valida a sessão do cliente e chama `sm_create_order()`
   (função SQL, ver `supabase/migrations/002_modulo4_vendas.sql`) via RPC.
3. `sm_create_order()` roda **dentro de uma única transação** no Postgres:
   para cada item, confere se o produto existe, está disponível, e (se
   `track_stock = true`) se há estoque suficiente; calcula o preço a
   partir do banco (respeitando `sale_price` quando existir); só depois
   de validar tudo, cria o pedido, os itens, o pagamento inicial, e dá
   baixa no estoque.
4. Se qualquer validação falhar, a transação inteira é desfeita
   automaticamente pelo Postgres — não sobra nenhum pedido "pela metade",
   nem estoque decrementado sem um pedido correspondente.

Isso significa que, mesmo que o JavaScript do navegador fosse totalmente
adulterado por alguém mal-intencionado, o pedido criado no banco sempre
reflete os preços e o estoque reais no momento da compra.

**Limitação conhecida:** o checkout exige login (não há "checkout como
convidado" nesta etapa) — decisão de escopo para manter a identidade do
cliente simples e seguramente ligada a uma conta Supabase Auth desde o
início. Adicionar checkout de convidado é possível depois, mas exigiria
uma forma seguros de depois vincular esse pedido "avulso" a uma conta, o
que preferimos não fazer às pressas.

### 16.4 Nota fiscal — só estrutura, nenhuma integração real

As tabelas `fiscal_documents` (estado de uma nota por pedido: número,
série, chave de acesso, status) e `company_fiscal_info` (dados fiscais da
empresa: razão social, CNPJ, inscrição estadual, regime tributário) foram
criadas e estão editáveis pelo painel — mas **nenhuma nota fiscal é
emitida de verdade**. Não existe integração com SEFAZ, NFE.io, Focus NFe,
ou qualquer serviço fiscal.

Uma integração real precisaria, no mínimo:
1. Contratar um serviço de emissão (ex.: Focus NFe, NFE.io, ou emissão
   direta via certificado digital A1 + biblioteca de NFC-e/NFe).
2. Guardar as credenciais desse serviço como variável de ambiente no
   Netlify (nunca no frontend).
3. Uma Netlify Function que, a partir de um pedido com
   `payment_status = 'approved'`, monta o XML/payload fiscal (usando os
   campos `ncm`/`cfop` do produto e os dados de `company_fiscal_info`),
   chama a API do serviço fiscal, e atualiza `fiscal_documents` com o
   número/série/chave retornados.
4. Certificado digital da empresa (A1 ou A3) — fora do escopo de qualquer
   código, é um processo administrativo/jurídico da empresa.

### 16.5 Netlify Functions do Módulo 4

| Função | Finalidade | Quem pode chamar | Variáveis de ambiente |
|---|---|---|---|
| `checkout-create-order.js` | Cria um pedido real (via `sm_create_order()`), validando estoque e recalculando preços no servidor. | Qualquer cliente autenticado (token de sessão obrigatório) | `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` |
| `payment-mock-confirm.js` | **Modo de teste.** Simula a aprovação/recusa de um pagamento. | Só administradores (verificado contra `admin_profiles`) | `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` |

(A função `admin-create-user.js`, da Etapa 3, continua existindo e
funcionando sem alterações.)

### 16.6 Banco de dados — o que foi criado (migration aditiva)

Tudo em `supabase/migrations/002_modulo4_vendas.sql`, seguro rodar mais de
uma vez, **não apaga nem recria** nada da Etapa 3:

| Tabela/função | Finalidade |
|---|---|
| `sm_is_admin()` | Função de segurança — substitui `auth.role() = 'authenticated'` em todas as políticas de escrita administrativa (ver 16.1). |
| `products` (colunas novas) | `track_stock`, `stock_quantity`, `ncm`, `cfop`, `fiscal_origin` — todas com valor padrão, não afetam os 48 produtos existentes. |
| `customers` | Um cliente por usuário do Supabase Auth (`id` = `auth.users.id`). |
| `addresses` | Endereços de entrega de cada cliente. |
| `orders` | Pedidos — número gerado automaticamente (`sm_next_order_number()`), status e status de pagamento estruturados. |
| `order_items` | Itens de cada pedido, com nome e preço "congelados" no momento da compra. |
| `order_status_history` | Histórico de mudanças de status. |
| `payments` | Registro de pagamento por pedido (modo teste nesta etapa). |
| `fiscal_documents` | Estado de uma futura nota fiscal por pedido (sem integração real). |
| `company_fiscal_info` | Dados fiscais da empresa (linha única). |
| `sm_create_order()` | Cria pedido + itens + pagamento + baixa de estoque, tudo em uma transação atômica. |

Todas as tabelas novas têm RLS habilitado desde a criação — nenhuma fica
exposta sem política de acesso.

### 16.7 Segurança — o que foi verificado

- Cliente só vê os próprios pedidos/endereços/dados (`customer_id = auth.uid()` em toda política relevante).
- Cliente **não consegue** ler nem escrever em `admin_profiles`, `fiscal_documents`, `company_fiscal_info`, nem alterar produtos/categorias/banners — todas essas políticas usam `sm_is_admin()`.
- Criação de pedido **não tem** política de INSERT direto para clientes — só acontece via `sm_create_order()`, chamada pela Netlify Function com a service_role key, depois de validar o token do cliente.
- Confirmação de pagamento (mesmo em modo de teste) exige que quem chama esteja em `admin_profiles` — testado explicitamente (ver 16.8).
- Nenhuma chave secreta (`service_role`, credenciais de pagamento/fiscais) aparece em nenhum arquivo servido ao navegador — confirmado por revisão manual de todo `assets/` e `admin/assets/`.

### 16.8 Testes realizados

Mesma metodologia da Etapa 3: execução do **código real do projeto**
contra um Supabase simulado (mock), já que este ambiente de
desenvolvimento não tem acesso à internet para testar contra um projeto
Supabase de verdade.

**64 testes novos do Módulo 4, todos passando** (mais os 67 já existentes
da Etapa 3, também revalidados — total acumulado de 131 testes):

- **Carrinho (12 testes):** adicionar, somar quantidade, definir
  quantidade, remover, esvaziar, resolução contra catálogo real (usa
  `salePrice` quando existe, remove item cujo produto sumiu/ficou
  indisponível, calcula subtotal corretamente).
- **`checkout-create-order.js` (13 testes):** fluxo de sucesso completo
  (cria cliente automaticamente, cria pedido, cria itens, calcula total
  certo, dá baixa em produto com `track_stock`, não mexe em produto sem
  `track_stock`, cria pagamento pendente); rejeita estoque insuficiente
  **sem criar nada** (nem pedido, nem baixa de estoque); rejeita produto
  indisponível; rejeita quantidade inválida antes mesmo de chamar o
  banco; rejeita chamada sem autenticação.
- **`payment-mock-confirm.js` (5 testes):** administrador consegue
  simular aprovação (pedido e pagamento atualizados, histórico
  registrado); **cliente comum recebe 403** ao tentar simular pagamento
  (teste crítico de segurança).
- **`admin-data.js` — pedidos/clientes/fiscal (14 testes):** listar
  pedidos com itens (join), buscar pedido específico, atualizar status
  com histórico, listar clientes, salvar/ler dados fiscais da empresa,
  mapeamento correto dos novos campos de produto (`trackStock`,
  `stockQuantity`), 48 produtos preservados.
- **`customer-auth.js` (3 testes):** cliente consegue logar, usuário
  correto após login, cliente vê exclusivamente os próprios pedidos.

Além disso, antes de fechar o módulo: sintaxe de 100% dos `.js` do
projeto, todos os `src`/`href` resolvendo para arquivos existentes,
tags HTML balanceadas em todas as páginas (incluindo as 3 novas —
`carrinho.html`, `checkout.html`, `minha-conta.html`), chaves `{}` do CSS
balanceadas, e confirmação de que `assets/js/products.js` continua byte a
byte idêntico ao estado da Etapa 3 (48 produtos, 8 categorias, nenhum
tocado).

**O que não pôde ser testado neste ambiente** (mesma limitação da Etapa
3): a chamada real contra um projeto Supabase de verdade — latência real,
comportamento exato do Postgres em produção rodando `sm_create_order()`
sob concorrência real, e o comportamento do Storage real. Isso só pode
ser validado depois que você rodar as migrations no seu próprio projeto
Supabase (`supabase/README.md`).

### 16.9 Arquivos criados/modificados neste módulo

**Novos (banco/backend):** `supabase/migrations/002_modulo4_vendas.sql`,
`netlify/functions/checkout-create-order.js`,
`netlify/functions/payment-mock-confirm.js`.

**Novos (site público):** `assets/js/cart.js`,
`assets/js/customer-auth.js`, `assets/js/carrinho-page.js`,
`assets/js/checkout-page.js`, `assets/js/minha-conta-page.js`,
`carrinho.html`, `checkout.html`, `minha-conta.html`.

**Novos (painel):** `admin/pedidos.html`, `admin/clientes.html`,
`admin/assets/js/admin-pedidos.js`, `admin/assets/js/admin-clientes.js`.

**Novo (raiz):** `README.md`.

**Editados:** `assets/js/main.js` (ícone de carrinho com contador no
header, botão "Adicionar ao carrinho" nos cartões de produto),
`assets/js/product-detail.js` (seletor de quantidade, botão de compra,
aviso de estoque), `assets/js/store.js` e `admin/assets/js/admin-data.js`
(mapeiam os novos campos `trackStock`/`stockQuantity`/`ncm`/`cfop`),
`admin/assets/js/admin-produto-form.js` (campos de estoque e fiscais),
`admin/assets/js/admin-ui.js` (itens "Pedidos" e "Clientes" no menu),
`admin/assets/js/admin-dashboard.js` (métricas de pedidos/faturamento),
`admin/assets/js/admin-configuracoes.js` (dados fiscais da empresa),
`assets/css/style.css` (estilos de carrinho/checkout/conta,
responsivos), `netlify.toml` (sem mudança — já registrava
`netlify/functions/`).

**Não tocados:** todos os 48 produtos e 8 categorias, todas as telas e
fluxos da Etapa 2/3 (login de admin, CRUD de produtos/categorias/banners/
destaques, `assets/js/products.js`), design e navegação do site público.

---

## 17. MÓDULO 5 — PAGAMENTO REAL, GALERIA, AUDITORIA, PAPÉIS E CONTATO

### 17.1 O que foi implementado

Construído sobre o Módulo 4, sem remover ou quebrar nada: os 48 produtos,
8 categorias, carrinho, checkout, pedidos, clientes e todo o painel
administrativo continuam funcionando exatamente como antes.

- **Pagamento online real (Mercado Pago)** — `netlify/functions/payment-create-preference.js`
  (cria uma cobrança real) e `netlify/functions/payment-webhook-mercadopago.js`
  (recebe a confirmação e atualiza o pedido). Só funciona de verdade com
  `MERCADOPAGO_ACCESS_TOKEN` configurado — sem essa variável, o checkout
  continua funcionando no modo de teste do Módulo 4 (confirmação manual
  pelo administrador), sem fingir nenhum pagamento.
- **Galeria de imagens** — o formulário de produto no painel permite
  enviar várias fotos adicionais (além da principal); a página pública do
  produto mostra miniaturas clicáveis que trocam a foto em destaque.
- **Histórico/auditoria de produtos e categorias** — toda alteração
  (criar, editar, excluir) é registrada automaticamente por uma trigger no
  banco de dados (`audit_log`), com quem alterou e quando. Visível no
  formulário de cada produto e em uma tela dedicada (`admin/historico.html`,
  só para administradores "owner").
- **Papéis de administrador (owner / editor)** — `owner` tem acesso total;
  `editor` gerencia catálogo, pedidos e clientes, mas não vê Configurações
  nem Histórico, e não consegue criar outros administradores (bloqueado
  tanto na interface quanto no banco).
- **Formulário de contato conectado a envio real** — toda mensagem enviada
  pelo site é salva de verdade (`contact_messages`) e aparece em
  `admin/mensagens.html`; o aviso por e-mail para a loja é melhor esforço,
  só funciona se um provedor de e-mail estiver configurado.
- **Paginação no painel** — listas de Produtos e Pedidos agora navegam em
  páginas de 15 itens, preparadas para catálogos maiores.

### 17.2 Pagamento real — como funciona e o que configurar

Diferente do Módulo 4 (só modo de teste), agora existe uma integração real
com o Mercado Pago — mas ela **só liga** se você configurar as credenciais.
Sem configuração, o checkout se comporta exatamente como no Módulo 4.

**Fluxo com o gateway configurado:**
1. `checkout-create-order.js` cria o pedido normalmente (como já fazia).
2. O site chama `payment-create-preference.js`, que monta os itens a
   partir do banco (nunca do navegador) e pede ao Mercado Pago uma
   "preferência de pagamento".
3. O cliente é redirecionado para a página de pagamento do Mercado Pago
   (Pix, cartão ou boleto).
4. Quando o pagamento muda de status, o Mercado Pago notifica
   `payment-webhook-mercadopago.js`. **Essa função nunca confia no
   conteúdo da notificação em si** — ela sempre busca o pagamento de
   verdade na API do Mercado Pago antes de atualizar qualquer coisa,
   exatamente como `sm_create_order()` nunca confia em preços vindos do
   navegador. Isso impede que alguém forje uma notificação falsa de
   "pagamento aprovado".
5. O pedido e o pagamento são atualizados automaticamente — o cliente vê
   isso em "Meus pedidos", o administrador vê em `admin/pedidos.html`.

**Variáveis de ambiente necessárias (Netlify → Environment variables):**

| Variável | Para quê |
|---|---|
| `MERCADOPAGO_ACCESS_TOKEN` | Token da sua conta Mercado Pago (teste ou produção) |
| `SITE_URL` | URL pública do site (ex.: `https://supermisto.netlify.app`), usada para montar as URLs de retorno e o webhook |

**Como obter o token:** crie uma conta em
[mercadopago.com.br/developers](https://www.mercadopago.com.br/developers),
crie uma aplicação, e copie o "Access Token" (use o de teste primeiro,
antes de trocar para produção).

**Trocar de gateway no futuro:** só `payment-create-preference.js` e
`payment-webhook-mercadopago.js` conhecem detalhes específicos do Mercado
Pago — o resto do sistema (checkout, pedidos, painel) só entende os
status genéricos (`pending`/`approved`/`refused`/`cancelled`/`refunded`).
Trocar de gateway significa reescrever essas duas funções, sem tocar em
mais nada.

### 17.3 Papéis de administrador — owner vs. editor

| | Owner | Editor |
|---|---|---|
| Dashboard, Pedidos, Clientes, Produtos, Categorias, Banners, Destaques, Mensagens | ✅ | ✅ |
| Histórico de alterações | ✅ | ❌ (escondido do menu e bloqueado por redirect se acessar a URL direto) |
| Configurações (WhatsApp/e-mail/redes, dados fiscais) | ✅ | ❌ |
| Criar outros administradores | ✅ | ❌ (bloqueado também na Netlify Function — não é só uma questão visual) |

Administradores criados **antes** desta migration (ex.: durante a Etapa 3)
viram `owner` automaticamente, para ninguém perder acesso ao que já usava.
Novos administradores criados a partir de agora podem ser `owner` ou
`editor`, escolhido no momento da criação (`admin/configuracoes.html`).

A garantia de segurança real está nas políticas RLS do banco
(`sm_is_owner()`, ver `supabase/migrations/003_modulo5.sql`) e na Netlify
Function — esconder itens de menu na interface é só para não confundir um
editor com opções que ele não pode usar, não é a proteção em si.

### 17.4 Histórico/auditoria — como funciona

Uma trigger no Postgres (`sm_audit_trigger()`) grava uma linha em
`audit_log` toda vez que um produto ou categoria é criado, editado ou
excluído — capturando o estado anterior e o novo (`before_data`/
`after_data`, em JSON) e quem fez a alteração. Como é uma trigger (roda
dentro do próprio banco), **não pode ser contornada** por nenhum bug ou
alteração no código do painel — mesmo que alguém editasse um produto
direto pela API REST do Supabase (sem passar pelo painel), o registro
ainda seria criado.

Visível em dois lugares: dentro do formulário de cada produto (histórico
só daquele item) e em `admin/historico.html` (visão geral, só para
`owner`).

### 17.5 Formulário de contato — o que é real e o que é opcional

- ✅ **Real:** toda mensagem enviada pelo formulário em `contato.html` é
  gravada de verdade na tabela `contact_messages` assim que o Supabase
  estiver configurado — sem depender de mais nada. Visível em
  `admin/mensagens.html`.
- 🧪 **Opcional (melhor esforço):** notificação por e-mail para a loja via
  `netlify/functions/contact-notify-email.js`, usando a API da
  [Resend](https://resend.com). Se `RESEND_API_KEY` e
  `CONTACT_NOTIFY_EMAIL` não estiverem configuradas, a função não faz nada
  (não é um erro) — a mensagem já foi salva de qualquer forma, então o
  formulário nunca falha por causa disso.

**Variáveis de ambiente para o e-mail funcionar:**

| Variável | Para quê |
|---|---|
| `RESEND_API_KEY` | Chave de API da sua conta Resend |
| `CONTACT_NOTIFY_EMAIL` | E-mail da loja que deve receber o aviso |

### 17.6 Banco de dados — o que foi criado (migration aditiva)

Tudo em `supabase/migrations/003_modulo5.sql`, seguro rodar mais de uma
vez, **não apaga nem recria** nada dos módulos anteriores:

| Item | Finalidade |
|---|---|
| `admin_profiles.role` (restrição) | Só aceita `'owner'` ou `'editor'`; administradores existentes viram `owner` automaticamente. |
| `sm_is_owner()` | Função de segurança usada nas políticas de Configurações/dados fiscais. |
| `audit_log` + `sm_audit_trigger()` | Histórico automático de produtos/categorias, gravado por trigger. |
| `contact_messages` | Mensagens do formulário de contato (inserção pública, leitura só admin). |

### 17.7 Netlify Functions do Módulo 5

| Função | Finalidade | Quem pode chamar | Variáveis de ambiente |
|---|---|---|---|
| `payment-create-preference.js` | Cria uma cobrança real no Mercado Pago para um pedido já existente. | Cliente autenticado, dono do pedido | `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `MERCADOPAGO_ACCESS_TOKEN`, `SITE_URL` |
| `payment-webhook-mercadopago.js` | Recebe a notificação do Mercado Pago e atualiza pedido/pagamento (sempre reconsultando a API, nunca confiando na notificação em si). | O próprio Mercado Pago (sem autenticação de usuário — validado por reconsulta) | `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `MERCADOPAGO_ACCESS_TOKEN` |
| `contact-notify-email.js` | Notifica a loja por e-mail sobre uma nova mensagem de contato (melhor esforço). | Qualquer visitante do site (chamada após salvar a mensagem) | `RESEND_API_KEY`, `CONTACT_NOTIFY_EMAIL` |

(`admin-create-user.js` do Módulo 3 foi atualizada para checar o papel
"owner" antes de criar outro administrador — ver 17.3. `checkout-create-
order.js` e `payment-mock-confirm.js` do Módulo 4 continuam sem
alterações.)

### 17.8 Segurança — o que foi verificado

- Um `editor` não consegue criar outro administrador — nem pela interface
  (escondida) nem chamando a Netlify Function diretamente (ela mesma
  confere o papel no banco antes de agir).
- Um `editor` que tentar acessar `/admin/configuracoes.html` ou
  `/admin/historico.html` direto pela URL é redirecionado para o
  dashboard antes de qualquer dado sensível ser carregado.
- `payment-create-preference.js` confere que o pedido pertence a quem está
  chamando antes de criar qualquer cobrança — um cliente não consegue
  pagar (ou gerar um link de pagamento para) o pedido de outra pessoa.
- `payment-webhook-mercadopago.js` nunca atualiza um pedido com base no
  que vem no corpo da notificação recebida — sempre busca o pagamento de
  verdade na API do Mercado Pago primeiro.
- `contact_messages` aceita inserção pública (é um formulário de contato
  de verdade, sem login), mas só administradores conseguem ler as
  mensagens — testado que a política de leitura exige `sm_is_admin()`.
- Nenhuma chave secreta (`MERCADOPAGO_ACCESS_TOKEN`, `RESEND_API_KEY`,
  `SUPABASE_SERVICE_ROLE_KEY`) aparece em nenhum arquivo servido ao
  navegador — confirmado por revisão manual de todo `assets/` e
  `admin/assets/`.

### 17.9 Testes realizados

Mesma metodologia dos módulos anteriores: execução do **código real do
projeto** contra um Supabase simulado (mock), já que este ambiente não
tem acesso à internet para testar contra Supabase/Mercado Pago reais.

**22 testes novos do Módulo 5, todos passando** (mais os 114 já
existentes dos módulos anteriores, também revalidados sem nenhuma
regressão — total acumulado de 136 testes):

- **Controle de papel em `admin-create-user.js` (3 testes):** owner
  consegue criar administrador; editor recebe 403 ao tentar; mensagem de
  erro explica o motivo.
- **`admin-data.js` — mensagens e auditoria (6 testes):** listar
  mensagens, atualizar status, listar histórico sem filtro e filtrado por
  produto específico, confirmando que cada entrada guarda o estado antes/
  depois da alteração.
- **`payment-create-preference.js` (6 testes):** sem
  `MERCADOPAGO_ACCESS_TOKEN` retorna 501 e `gatewayConfigured:false` (nunca
  finge sucesso); com o token configurado, cria a preferência de verdade e
  devolve o link de pagamento; **cliente não consegue gerar cobrança para
  pedido de outra pessoa** (teste crítico de segurança).
- **`payment-webhook-mercadopago.js` (7 testes):** processa notificação de
  pagamento aprovado e recusado corretamente, sempre revalidando contra a
  API (não confiando no corpo recebido); atualiza pedido e histórico;
  ignora com segurança (200, sem quebrar) quando o gateway não está
  configurado.

Além disso, antes de fechar o módulo: sintaxe de 100% dos `.js`, todos os
`src`/`href` resolvendo, tags HTML e chaves CSS balanceadas em todas as
páginas (incluindo as 2 novas do painel — `mensagens.html`,
`historico.html`), as 3 migrations SQL estruturalmente balanceadas, e
confirmação de que `assets/js/products.js` permanece idêntico ao estado
do Módulo 4 (48 produtos, 8 categorias, nenhum tocado).

**O que não pôde ser testado neste ambiente** (mesma limitação dos módulos
anteriores): a chamada real contra Supabase e Mercado Pago de verdade —
isso só pode ser validado depois que você configurar suas próprias
credenciais (seções 17.2 e 17.5).

### 17.10 Arquivos criados/modificados neste módulo

**Novos (banco):** `supabase/migrations/003_modulo5.sql`.

**Novos (backend):** `netlify/functions/payment-create-preference.js`,
`netlify/functions/payment-webhook-mercadopago.js`,
`netlify/functions/contact-notify-email.js`.

**Novos (painel):** `admin/mensagens.html`, `admin/historico.html`,
`admin/assets/js/admin-mensagens.js`, `admin/assets/js/admin-historico.js`.

**Novo (site público):** `assets/js/contato-page.js`.

**Editados:** `netlify/functions/admin-create-user.js` (checagem de papel
owner), `admin/assets/js/admin-auth.js` (`smAdminGetRole()`),
`admin/assets/js/admin-ui.js` (itens de menu restritos a owner,
paginação genérica), `admin/assets/js/admin-data.js` (mensagens,
auditoria, papel na criação de admin), `admin/assets/js/admin-configuracoes.js`
(tabela de administradores com papel, seletor de papel no cadastro),
`admin/assets/js/admin-produto-form.js` (galeria de imagens, histórico de
auditoria do produto), `admin/assets/js/admin-produtos.js` e
`admin/assets/js/admin-pedidos.js` (paginação),
`assets/js/product-detail.js` (galeria de imagens),
`assets/js/checkout-page.js` (redirecionamento para pagamento real quando
configurado), `contato.html` (formulário conectado a envio real),
`assets/css/style.css` e `admin/assets/css/admin.css` (estilos de
galeria/paginação).

**Não tocados:** todos os 48 produtos e 8 categorias, `assets/js/products.js`,
todas as telas e fluxos dos módulos anteriores (carrinho, checkout base,
CRUD de produtos/categorias/banners/destaques, login de admin e cliente).

---

## 18. MÓDULO 6 — NOTA FISCAL REAL E MARKETPLACE

### 18.1 O que foi implementado

Construído sobre o Módulo 5, sem remover ou quebrar nada: os 48 produtos,
8 categorias, carrinho, checkout, pedidos, clientes, papéis de
administrador e tudo mais continuam funcionando exatamente como antes.

- **Emissão real de nota fiscal (Focus NFe)** — `netlify/functions/fiscal-emit-nfe.js`
  monta o payload fiscal a partir de dados reais (produto, pedido, dados
  fiscais da empresa) e chama a API da Focus NFe. Só funciona de verdade
  com `FOCUS_NFE_API_TOKEN` configurado — sem essa variável, a função
  recusa com uma mensagem clara, nunca finge ter emitido uma nota.
  `netlify/functions/fiscal-check-status.js` consulta o resultado (a
  emissão é assíncrona).
- **Marketplace / múltiplos vendedores** — vendedores agora podem ter
  conta própria (`seller_profiles`), gerenciar os próprios produtos pelo
  portal `/vendedor` (login separado do admin e do cliente), e o
  administrador `owner` aprova/suspende vendedores e ajusta a comissão da
  plataforma em `admin/vendedores.html`. Produtos sem vendedor continuam
  sendo da própria loja SuperMisto — nada mudou para os 48 produtos
  originais.
- **"Vendido por X"** — produtos de vendedores do marketplace mostram essa
  etiqueta no cartão e na página do produto, no site público.

### 18.2 Nota fiscal — o que é real e o que configurar

**Real, não é modo de teste** — mas só liga com as credenciais certas.
Diferente do pagamento (Módulo 5), que tinha um modo de teste completo
como alternativa, a nota fiscal não tem um "modo simulado" — ou está
configurada e emite de verdade (mesmo que em ambiente de homologação da
Focus NFe, que também é uma emissão real, só que sem valer fiscalmente),
ou a função recusa claramente.

**Fluxo:**
1. Um administrador (só `owner` vê essa opção) clica em "Emitir nota
   fiscal" no detalhe de um pedido pago (`admin/pedidos.html`).
2. `fiscal-emit-nfe.js` confere que o pagamento está `approved`, que todos
   os produtos do pedido têm NCM cadastrado, e que os dados fiscais da
   empresa (CNPJ etc.) estão preenchidos em Configurações — se algo faltar,
   recusa com uma mensagem específica dizendo o que falta, em vez de
   tentar emitir com dados incompletos.
3. Monta o payload da NFC-e e envia para a Focus NFe. A resposta inicial
   só confirma que entrou na fila de processamento (`status: pendente`).
4. O administrador clica em "Verificar status" — `fiscal-check-status.js`
   consulta a Focus NFe de novo (nunca confia em nada armazenado
   localmente) e atualiza para `emitida` (com número/série/chave de
   acesso reais) ou `erro`.

**Variáveis de ambiente necessárias:**

| Variável | Para quê |
|---|---|
| `FOCUS_NFE_API_TOKEN` | Token da sua conta Focus NFe |
| `FOCUS_NFE_ENVIRONMENT` | `homologacao` (padrão, recomendado para testar) ou `producao` |

**Antes de emitir a primeira nota de verdade:** preencha o NCM de cada
produto (formulário de produto → aba fiscal) e os dados fiscais da
empresa (Configurações → Dados fiscais). O regime tributário e a
tributação de ICMS usados no payload (`icms_situacao_tributaria: "102"`,
Simples Nacional) são um ponto de partida comum, mas **precisam ser
conferidos com seu contador** antes de emitir notas reais — tributação
incorreta é responsabilidade fiscal da empresa, não algo que este código
consegue validar sozinho.

### 18.3 Marketplace — como funciona

Um vendedor é uma conta do Supabase Auth (mesma tecnologia de admin e
cliente), mas em uma tabela própria (`seller_profiles`) — nunca aparece em
`admin_profiles` nem em `customers`, então `sm_is_admin()`/`sm_is_owner()`
continuam sempre `false` para ele (não ganha nenhum acesso administrativo
por engano), e o portal do vendedor não expõe nada de clientes ou de
outros vendedores.

- **Onboarding:** só um administrador `owner` cria a conta de um vendedor
  (`admin/vendedores.html` → "+ Adicionar vendedor"), sempre começando
  como `pending`. O `owner` ativa (`active`) depois de conferir os dados —
  produtos de um vendedor `pending` ou `suspended` continuam existindo no
  banco, mas isso é uma decisão de política da loja, não uma trava técnica
  automática (ver limitação abaixo).
- **Produtos:** `products.seller_id` é opcional — `null` significa "produto
  da própria loja" (todos os 48 originais). Um vendedor só consegue
  inserir/editar/excluir produtos com `seller_id` igual ao próprio
  `auth.uid()` — garantido por RLS, não só pela interface.
- **Vendas:** quando um pedido é criado (`sm_create_order()`), cada item
  guarda um snapshot de qual vendedor forneceu aquele produto
  (`order_items.seller_id`). O vendedor consegue ver as próprias vendas
  (RLS libera leitura de `order_items` onde `seller_id = auth.uid()`), sem
  enxergar nada de outros vendedores nem dados do cliente além do que já
  está no item vendido.
- **Comissão:** cada vendedor tem uma `commission_rate` (%) definida pelo
  `owner`. O painel (`admin/vendedores.html`) e o portal do vendedor
  (`vendedor/dashboard.html`) calculam "total vendido" e "a repassar"
  (total vendido menos a comissão) a partir das vendas com pagamento
  aprovado — é um cálculo de exibição, não uma transferência financeira
  automática (ver limitação abaixo).

**Limitação conhecida:** este módulo não movimenta dinheiro entre a loja e
os vendedores automaticamente — os valores de "a repassar" são
informativos, para a loja usar como base ao fazer o repasse manualmente
(ex.: Pix, transferência). Um split de pagamento automático (o gateway já
dividir o valor no momento da compra) exigiria uma funcionalidade
específica do gateway (o Mercado Pago tem "Marketplace" com split de
pagamentos) e ficou fora do escopo deste módulo — ver "PRÓXIMAS ETAPAS".
Além disso, o status `pending`/`suspended` de um vendedor não bloqueia
automaticamente a visibilidade dos produtos dele no site público nesta
etapa (RLS de leitura de produtos continua pública para qualquer produto,
independente do status do vendedor) — recomenda-se que o `owner` desative
(`available: false`) os produtos de um vendedor suspenso manualmente até
uma versão futura automatizar isso.

### 18.4 Banco de dados — o que foi criado (migration aditiva)

Tudo em `supabase/migrations/004_modulo6.sql`, seguro rodar mais de uma
vez, **não apaga nem recria** nada dos módulos anteriores:

| Item | Finalidade |
|---|---|
| `seller_profiles` | Vendedores do marketplace (login próprio, status, comissão). |
| `sm_is_seller()` | Função de segurança — só `true` para vendedor com status `active`. |
| `products.seller_id` | Vínculo opcional produto → vendedor (`null` = loja própria). |
| `order_items.seller_id` | Snapshot de qual vendedor forneceu cada item vendido. |
| `sm_create_order()` (atualizada) | Mesma lógica atômica do Módulo 4, agora também grava `seller_id` em cada item. |
| Política de Storage para vendedores | Corrige uma lacuna: sem ela, um vendedor conseguiria cadastrar produto mas nunca subir uma foto (o bucket `products` só aceitava upload de administradores). |

### 18.5 Netlify Functions do Módulo 6

| Função | Finalidade | Quem pode chamar | Variáveis de ambiente |
|---|---|---|---|
| `seller-create.js` | Cria uma conta de vendedor (Auth + `seller_profiles`). | Só administradores "owner" | `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` |
| `fiscal-emit-nfe.js` | Emite NFC-e real via Focus NFe a partir de um pedido pago. | Qualquer administrador | `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `FOCUS_NFE_API_TOKEN`, `FOCUS_NFE_ENVIRONMENT` |
| `fiscal-check-status.js` | Consulta o status real de uma emissão pendente. | Qualquer administrador | Mesmas da função acima |

### 18.6 Segurança — o que foi verificado

- Um vendedor não consegue ler nem escrever produtos de outro vendedor —
  testado tanto a leitura (`smVendorGetMyProducts` só retorna os próprios)
  quanto a tentativa de editar um produto alheio (o filtro `seller_id`
  impede a alteração, e a RLS real reforça isso de qualquer forma).
- Um administrador "editor" não consegue criar vendedores — só "owner"
  (mesmo padrão de `admin-create-user.js`, testado explicitamente).
- `fiscal-emit-nfe.js` nunca emite nota de um pedido com pagamento não
  aprovado — testado que a tentativa é rejeitada com 409.
- Nenhuma chave secreta (`FOCUS_NFE_API_TOKEN`, `SUPABASE_SERVICE_ROLE_KEY`)
  aparece em nenhum arquivo servido ao navegador — confirmado por revisão
  manual de `assets/`, `admin/assets/` e `vendedor/assets/`.

### 18.7 Testes realizados

Mesma metodologia dos módulos anteriores: execução do **código real do
projeto** contra um Supabase simulado, já que este ambiente não tem
acesso à internet para testar contra Supabase/Focus NFe reais.

**23 testes novos do Módulo 6, todos passando** (mais os 136 já existentes
dos módulos anteriores, também revalidados sem nenhuma regressão — total
acumulado de 159 testes):

- **`seller-create.js` (4 testes):** owner consegue criar vendedor
  (status inicial "pending", comissão salva corretamente); editor recebe
  403 ao tentar.
- **`admin-data.js` — vendedores e nota fiscal (5 testes):** listar
  vendedores, ativar, ajustar comissão, ler documento fiscal de um pedido.
- **`vendedor-auth.js` (5 testes):** vendedor ativo consegue logar e ver o
  próprio perfil; **vendedor suspenso é bloqueado no login**, mesmo com
  senha certa.
- **`vendedor-data.js` (4 testes):** vendedor vê só os próprios produtos
  (não os de outro vendedor); consegue adicionar produto (com `seller_id`
  automaticamente igual ao próprio); **tentativa de editar produto de
  outro vendedor não altera nada**.
- **`fiscal-emit-nfe.js` (5 testes):** sem `FOCUS_NFE_API_TOKEN` nunca
  finge sucesso (501); com o token configurado, emite de verdade e grava
  o status pendente; pedido sem pagamento aprovado é rejeitado (409).

Além disso: sintaxe de 100% dos `.js`, todos os `src`/`href` resolvendo,
tags HTML e chaves CSS balanceadas (incluindo as novas páginas —
`admin/vendedores.html` e as 4 páginas de `/vendedor`), as 4 migrations
SQL estruturalmente balanceadas, e confirmação de que
`assets/js/products.js` permanece idêntico ao estado do Módulo 5 (48
produtos, 8 categorias, nenhum tocado). Durante o desenvolvimento também
foi corrigido um bug real encontrado por análise: a política de Storage
que faltava para vendedores conseguirem subir fotos de produto.

**O que não pôde ser testado neste ambiente:** a chamada real contra
Supabase e Focus NFe — isso só pode ser validado depois que você
configurar suas próprias credenciais (seção 18.2), idealmente primeiro no
ambiente de homologação da Focus NFe antes de emitir qualquer nota real.

### 18.8 Arquivos criados/modificados neste módulo

**Novos (banco):** `supabase/migrations/004_modulo6.sql`.

**Novos (backend):** `netlify/functions/seller-create.js`,
`netlify/functions/fiscal-emit-nfe.js`,
`netlify/functions/fiscal-check-status.js`.

**Novos (painel):** `admin/vendedores.html`,
`admin/assets/js/admin-vendedores.js`.

**Novo (portal do vendedor, pasta inteira):** `vendedor/index.html`,
`vendedor/dashboard.html`, `vendedor/produtos.html`,
`vendedor/produto-form.html`, `vendedor/assets/css/vendedor.css`,
`vendedor/assets/js/vendedor-auth.js`,
`vendedor/assets/js/vendedor-data.js`,
`vendedor/assets/js/vendedor-ui.js`,
`vendedor/assets/js/vendedor-dashboard.js`,
`vendedor/assets/js/vendedor-produtos.js`,
`vendedor/assets/js/vendedor-produto-form.js`.

**Editados:** `admin/assets/js/admin-data.js` (funções de vendedores e
nota fiscal), `admin/assets/js/admin-ui.js` (item "Vendedores" no menu,
owner-only), `admin/assets/js/admin-pedidos.js` (painel de nota fiscal no
detalhe do pedido), `assets/js/store.js` e `assets/js/main.js` /
`assets/js/product-detail.js` (mapeamento de `seller_id` e etiqueta
"Vendido por"), `assets/css/style.css` (estilo da etiqueta de vendedor).

**Não tocados:** todos os 48 produtos e 8 categorias, `assets/js/products.js`,
todas as telas e fluxos dos módulos anteriores (carrinho, checkout,
pagamento, CRUD de produtos/categorias/banners/destaques, login de admin
e cliente, papéis owner/editor, auditoria, mensagens de contato).

---

## 19. MÓDULO 7 — PWA (APLICATIVO), SPLIT DE PAGAMENTO E NOTIFICAÇÕES PUSH

### 19.1 Sobre "aplicativo nativo" — uma decisão técnica que precisa ficar clara

O `PROJETO.md` (seção "PRÓXIMAS ETAPAS", escrita durante o Módulo 6) apontava
"aplicativo nativo (Android/iOS)" como o item natural do Módulo 7. É
importante documentar a decisão tomada aqui: **este projeto foi construído
inteiramente em um ambiente de texto/código sem Xcode, Android Studio, ou
qualquer forma de compilar, assinar e publicar um app nativo em loja de
aplicativos.** Fingir ter entregado um `.apk` ou um projeto Xcode
funcional seria exatamente o tipo de coisa que este projeto se recusou a
fazer em todos os módulos anteriores (nunca inventar uma integração que
não existe de verdade).

A entrega real e honesta possível aqui é uma **PWA (Progressive Web App)**
— instalável na tela inicial do Android e do iOS, funciona offline,
recebe notificações push, abre em tela cheia sem barra de navegador — e
que **reaproveita 100% do backend já existente** (mesmo Supabase, mesma
autenticação, mesmas Netlify Functions), exatamente como a seção de
roadmap pedia. Não é um app "de mentirinha": é instalável de verdade,
hoje, sem esperar aprovação de loja de aplicativos.

O caminho para um app nativo compilado (React Native ou Flutter, usando
`supabase-js`/`supabase-flutter`) continua documentado como próximo passo
real — ver seção 19.6.

### 19.2 O que foi implementado

- **PWA do site público** — instalável, com ícones reais (gerados a partir
  da logo da marca), cache do "app shell" (nunca cacheia dados do
  Supabase/pagamento — preço e estoque sempre vêm da rede quando
  disponível), atalhos para carrinho e pedidos.
- **PWA do portal do vendedor** (`/vendedor`) — instalável separadamente,
  com o próprio manifesto e Service Worker (escopo `/vendedor/`).
- **Notificações push reais** (Web Push / VAPID) — cliente é avisado
  quando o pagamento do pedido é aprovado/recusado; vendedor é avisado
  quando um produto dele é vendido. Só funciona de verdade com as chaves
  VAPID configuradas — sem elas, os botões de "ativar notificações"
  simplesmente não aparecem.
- **Split de pagamento automático (Mercado Pago Marketplace)** — um
  vendedor pode conectar a própria conta Mercado Pago (fluxo OAuth real);
  a partir daí, pedidos com produtos só daquele vendedor pagam direto na
  conta dele, com a comissão da loja retida automaticamente
  (`marketplace_fee`). Resolve a limitação documentada na seção 18.3
  (repasse antes era só informativo/manual).

### 19.3 PWA — como testar a instalação

1. Configure o backend (Supabase) normalmente — a PWA funciona com ou sem
   backend configurado (site público sempre tem o fallback de
   `products.js`; só carrinho/checkout/push exigem backend).
2. Publique no Netlify (HTTPS é obrigatório para Service Worker e Push —
   não funciona em `http://`, funciona em `http://localhost` para testes).
3. No celular (Android/Chrome ou iOS/Safari), abra o site e use "Adicionar
   à tela inicial" (o navegador também pode sugerir isso automaticamente).
4. O ícone instalado abre o site em tela cheia, sem barra de endereço.
5. Repita o processo em `/vendedor` para instalar o portal do vendedor
   separadamente (ele tem o próprio ícone/nome na tela inicial).

### 19.4 Notificações push — o que configurar

**Variáveis de ambiente necessárias (Netlify):**

| Variável | Para quê |
|---|---|
| `VAPID_PUBLIC_KEY` | Chave pública — vai também no código do site (não é secreta) |
| `VAPID_PRIVATE_KEY` | Chave privada — só no Netlify, nunca no navegador |
| `VAPID_CONTACT_EMAIL` | E-mail de contato exigido pelo protocolo Web Push |

**Como gerar as chaves** (uma vez, na sua máquina, com Node instalado):
```bash
npx web-push generate-vapid-keys
```
Cole a chave pública em `assets/js/push-config.js` (`window.VAPID_PUBLIC_KEY`)
e configure as duas variáveis de ambiente no Netlify com a chave privada e
seu e-mail.

**Onde ativar:** o cliente ativa em "Minha Conta" → "Notificações"; o
vendedor ativa em `/vendedor/dashboard.html` → "Notificações". Ambos os
botões só aparecem se `VAPID_PUBLIC_KEY` estiver configurada — sem isso,
a seção mostra "Notificações push ainda não estão configuradas nesta
loja" e não tenta nada.

**Única exceção de dependência do projeto:** `netlify/functions/push-send-notification.js`
é a única Netlify Function com uma dependência de pacote npm
(`web-push`, ver `netlify/functions/package.json`) — assinar
notificações push corretamente exige criptografia ECDH (protocolo VAPID)
que não vale a pena reimplementar à mão sem uma biblioteca revisada por
segurança. Todas as outras 12 Netlify Functions do projeto continuam
usando só `fetch` nativo, sem instalar nada.

### 19.5 Split de pagamento — como configurar e como funciona

**Variáveis de ambiente necessárias (Netlify), além de `SITE_URL` já usada
pelo Módulo 5:**

| Variável | Para quê |
|---|---|
| `MERCADOPAGO_CLIENT_ID` | ID da aplicação SuperMisto cadastrada no Mercado Pago |
| `MERCADOPAGO_CLIENT_SECRET` | Segredo da aplicação — só no Netlify, nunca no navegador |

**Como obter:** crie uma aplicação em
[mercadopago.com.br/developers](https://www.mercadopago.com.br/developers)
→ "Suas integrações" → "Criar aplicação", habilite "Marketplace" e copie o
Client ID/Secret.

**Fluxo (real, testado com o código do projeto contra um Mercado Pago
simulado):**
1. O vendedor clica em "Conectar Mercado Pago" no próprio dashboard.
2. `seller-connect-mercadopago.js` monta a URL de autorização do Mercado
   Pago (com um `state` assinado que expira em 10 minutos) e o navegador
   redireciona para lá.
3. O vendedor autoriza no site do Mercado Pago (login na conta dele).
4. O Mercado Pago redireciona para `seller-mercadopago-callback.js`, que
   troca o código por um token de acesso de verdade (chamada
   servidor-a-servidor, nunca exposta ao navegador) e salva em
   `seller_profiles`.
5. Da próxima vez que um pedido tiver produtos só daquele vendedor,
   `payment-create-preference.js` detecta a conexão e cria a preferência
   de pagamento usando o token DELE (não o da plataforma), com
   `marketplace_fee` retendo a comissão automaticamente.

**Limitação real e documentada:** o Checkout Pro do Mercado Pago só
divide um pagamento com UM vendedor por vez. Um carrinho com produtos de
mais de um vendedor (ou de um vendedor + da própria loja) continua usando
o fluxo sem split (cai tudo na conta da loja, repasse manual, como no
Módulo 6) — isso é uma limitação real da API do gateway, não do código
deste projeto, e está testado explicitamente (ver 19.7).

### 19.6 Caminho real para um aplicativo nativo compilado

Quando fizer sentido investir em um app de loja de verdade (Google Play/
App Store), o caminho recomendado, que reaproveita 100% do que já existe:

1. **Framework:** React Native (Expo) ou Flutter — ambos têm SDK oficial
   do Supabase (`supabase-js` funciona em React Native; `supabase_flutter`
   para Flutter) com a mesma `anon key` já usada no site.
2. **Autenticação:** reaproveita exatamente o Supabase Auth já configurado
   — um cliente que já tem conta no site consegue logar no app com o
   mesmo e-mail/senha, sem nenhuma migração de dados.
3. **Dados:** as mesmas tabelas, as mesmas políticas RLS — o app conversa
   direto com a API REST do Supabase, do mesmo jeito que `store.js` e
   `admin-data.js` já fazem.
4. **Checkout/pagamento/nota fiscal:** o app chama as MESMAS Netlify
   Functions já existentes (`checkout-create-order.js`,
   `payment-create-preference.js`, etc.) — nenhuma delas precisa ser
   reescrita; elas já são endpoints HTTP genéricos, não amarrados ao site.
5. **Notificações:** trocar Web Push por notificações nativas (Firebase
   Cloud Messaging / Apple Push Notification service) — a tabela
   `push_subscriptions` já criada neste módulo pode ganhar uma coluna
   `platform` (`web`/`ios`/`android`) para conviver com os dois tipos.
6. **Vendedor:** o mesmo app (ou um segundo app dedicado) reaproveitaria
   as regras de `/vendedor` — mesma autenticação, mesmas tabelas, mesmo
   RLS de isolamento entre vendedores.

Nenhuma parte do backend construído até aqui (Etapa 3 até Módulo 7)
precisaria ser refeita para isso — é trabalho de front-end nativo puro,
consumindo a API que já existe.

### 19.7 Segurança — o que foi verificado

- O split de pagamento só usa o token OAuth do vendedor quando TODOS os
  itens do pedido são daquele vendedor — testado que um carrinho
  multi-vendedor ou com produtos da própria loja nunca usa
  acidentalmente o token de um vendedor para itens que não são dele.
- `push-send-notification.js` só aceita chamadas autenticadas com a
  própria `service_role` key (chamada servidor-a-servidor pelas outras
  Netlify Functions) — não é um endpoint público que qualquer um poderia
  usar para mandar notificação para qualquer usuário.
- O token OAuth do vendedor (`mp_access_token`) nunca é lido pelo
  navegador — só a Netlify Function `payment-create-preference.js`, com a
  `service_role` key, consegue lê-lo do banco.
- `push_subscriptions` tem RLS: cada usuário só gerencia as próprias
  inscrições — confirmado que a tabela segue o mesmo padrão de
  `customers`/`addresses` já testado em módulos anteriores.
- Nenhuma chave secreta (`MERCADOPAGO_CLIENT_SECRET`, `VAPID_PRIVATE_KEY`)
  aparece em nenhum arquivo servido ao navegador — confirmado por revisão
  manual de `assets/`, `admin/assets/` e `vendedor/assets/`.

### 19.8 Testes realizados

Mesma metodologia dos módulos anteriores: execução do **código real do
projeto** contra chamadas simuladas, já que este ambiente não tem acesso
à internet para testar contra Mercado Pago/Web Push reais.

**19 testes novos do Módulo 7, todos passando** (mais os 159 já existentes
dos módulos anteriores, revalidados sem nenhuma regressão — total
acumulado de 178 testes formais, mais 3 testes adicionais de
`push-notifications.js` do lado do cliente — 181 no total):

- **`seller-connect-mercadopago.js` (6 testes):** sem
  `MERCADOPAGO_CLIENT_ID` nunca finge sucesso (501); com credenciais,
  gera a URL de autorização real do Mercado Pago com o `client_id`
  correto; recusa token de sessão inválido.
- **`payment-create-preference.js` — split (10 testes):** aplica split
  corretamente quando o pedido tem um único vendedor conectado (usa o
  token dele, calcula `marketplace_fee` certo, salva
  `provider: mercadopago_split`); **não aplica split** quando o vendedor
  não conectou conta, quando o carrinho tem múltiplos vendedores, ou
  quando os produtos são só da própria loja — em todos esses casos,
  confirma que o token usado continua sendo o da plataforma.
- **`push-send-notification.js` (3 testes):** sem VAPID configurado
  nunca envia nada mas sempre responde 200 (nunca quebra quem chamou);
  exige autenticação de serviço para funcionar.
- **`push-notifications.js` (cliente, 3 testes):** `smPushIsAvailable()`
  retorna `false` corretamente sem VAPID configurado e sem suporte do
  navegador; `true` só quando ambos existem.

Além disso: sintaxe de 100% dos `.js` do projeto (18 Netlify Functions,
incluindo as 5 novas deste módulo), todos os `src`/`href`/`manifest`
resolvendo, tags HTML e chaves CSS balanceadas (incluindo as tags de PWA
adicionadas a 15 páginas), `manifest.json` (site e vendedor) validados
como JSON, a migration SQL estruturalmente balanceada, e confirmação de
que `assets/js/products.js` permanece idêntico ao estado do Módulo 6 (48
produtos, 8 categorias, nenhum tocado).

**O que não pôde ser testado neste ambiente:** a instalação real da PWA em
um celular, o recebimento real de uma notificação push, e o fluxo OAuth
completo contra o Mercado Pago de verdade — tudo isso só pode ser
validado depois que você configurar as credenciais reais e publicar o
site (seções 19.3, 19.4 e 19.5).

### 19.9 Arquivos criados/modificados neste módulo

**Novos (banco):** `supabase/migrations/005_modulo7.sql`.

**Novos (backend):** `netlify/functions/seller-connect-mercadopago.js`,
`netlify/functions/seller-mercadopago-callback.js`,
`netlify/functions/push-send-notification.js`,
`netlify/functions/package.json` (única dependência npm do projeto).

**Novos (PWA — site público):** `assets/manifest.json`,
`service-worker.js` (raiz do site), `assets/js/pwa-register.js`,
`assets/js/push-config.js`, `assets/js/push-notifications.js`,
`assets/img/icons/icon-192.png`, `assets/img/icons/icon-512.png`,
`assets/img/icons/icon-apple-touch.png`.

**Novos (PWA — portal do vendedor):** `vendedor/manifest.json`,
`vendedor/service-worker.js`, `vendedor/assets/js/vendedor-pwa-register.js`,
`vendedor/assets/img/icons/` (ícones reaproveitados).

**Editados:** `netlify/functions/payment-create-preference.js` (lógica de
split), `netlify/functions/checkout-create-order.js` e
`netlify/functions/payment-mock-confirm.js` e
`netlify/functions/payment-webhook-mercadopago.js` (chamadas de push
best-effort), `assets/js/minha-conta-page.js` (painel de notificações,
toast público), `vendedor/assets/js/vendedor-dashboard.js` (painel de
split de pagamento e notificações), as 11 páginas públicas + 4 páginas do
portal do vendedor (tags de manifest/PWA e scripts de registro).

**Não tocados:** todos os 48 produtos e 8 categorias, `assets/js/products.js`,
todas as telas e fluxos dos módulos anteriores (carrinho, checkout,
pagamento em modo de teste, nota fiscal, CRUD de produtos/categorias/
banners/destaques, login de admin/cliente/vendedor, papéis owner/editor,
auditoria, mensagens de contato).

---

## 20. CORREÇÃO — RESPONSIVIDADE MOBILE E RECUPERAÇÃO DE SENHA

Esta seção documenta uma rodada de correções feita sobre o Módulo 7, sem
avançar para nenhum módulo novo. Duas frentes: (1) responsividade real do
site em celulares, corrigindo bugs de CSS que causavam sobreposição e
corte de conteúdo; (2) recuperação de senha por e-mail para administrador,
vendedor e cliente, que não existia até aqui.

### 20.1 Bugs de responsividade encontrados e corrigidos

Todos os problemas relatados vinham de **3 bugs reais de CSS**, não de uma
falta de design mobile — o site já era "mobile-first" na estrutura, mas
tinha defeitos pontuais que quebravam isso:

1. **Sobreposição categorias/produtos (e também carrinho/checkout).**
   `.filter-box`, `.cart-summary` e `.checkout-summary` tinham
   `position:sticky` **incondicional**, mesmo nas telas em que o layout já
   é uma única coluna (categorias empilhadas acima dos produtos, resumo do
   carrinho abaixo dos itens). Um elemento `sticky` nessa situação "gruda"
   na tela ao rolar e passa a cobrir o conteúdo abaixo dele — exatamente o
   sintoma relatado. Corrigido: o `sticky` agora só é aplicado a partir de
   900px (onde o layout vira duas colunas de verdade, ao lado do
   conteúdo).
2. **Botões cortados nos cards de produto.** `.product-actions .btn` usava
   `flex:1` dentro de um card com `overflow:hidden`, mas herdava
   `white-space:nowrap` do estilo base de botão sem `min-width:0`. Isso é
   um comportamento conhecido do CSS flexbox: um item flexível não encolhe
   abaixo do tamanho do próprio conteúdo a menos que `min-width:0` seja
   definido explicitamente — o texto "Ver produto"/"Adicionar" forçava o
   botão a ficar mais largo que o espaço disponível, e a borda do card
   (com `overflow:hidden`) cortava visualmente a sobra. Corrigido com
   `min-width:0`, permitindo o texto quebrar em duas linhas se
   necessário, e reduzindo padding/fonte nas telas mais estreitas.
3. **Grade de produtos sem opção de 1 coluna.** Antes, o grid pulava
   direto de 2 para 3 colunas a partir de 640px, sem nunca usar 1 coluna
   — em telas muito estreitas (320-360px), 2 colunas deixavam cada card
   com menos de 150px de largura, insuficiente para nome + descrição +
   preço + 2 botões caberem confortavelmente. Corrigido: 1 coluna abaixo
   de 400px, 2 colunas de 400-639px, e **as regras de 640px (3 colunas) e
   1100px (4 colunas) do desktop foram mantidas exatamente como estavam**
   — nenhuma mudança na experiência de computador.

### 20.2 Outros ajustes de responsividade

- Nome e descrição do produto agora têm `overflow-wrap` e a descrição usa
  `line-clamp` (3 linhas) — nunca mais vazam do card, não importa o
  tamanho do texto.
- Cabeçalho mobile: ícones e logo reduzidos em telas <480px; o ícone
  avulso do WhatsApp da barra superior fica escondido abaixo de 380px
  (continua acessível pelo menu ☰ e pelo botão flutuante) para sobrar
  espaço confortável — conferido manualmente que a barra cabe em 320px de
  largura com folga.
- Campo de busca com padding/altura/fonte reduzidos no mobile.
- Título "Nossos produtos" e subtítulo com tamanho de fonte responsivo
  (`clamp()` mais permissivo) e menos espaçamento vertical em telas
  pequenas.
- Botão flutuante do WhatsApp reduzido no mobile (58px → 50px), respeita
  `env(safe-area-inset)` (evita ficar embaixo da barra de gestos do
  iPhone), e a grade de produtos ganhou um respiro extra na parte de
  baixo para o botão nunca ficar em cima do último card.
- Verificação geral: nenhum outro `white-space:nowrap` problemático nem
  `position:sticky` incondicional restante em nenhuma folha de estilo do
  projeto (site público, painel, portal do vendedor).

**O que NÃO foi alterado, conforme pedido:** produtos, preços, categorias,
imagens, logo, cores, tokens de design, conteúdo de texto. Todas as
mudanças foram exclusivamente de CSS de layout responsivo (media queries,
`min-width`, `overflow-wrap`, `position`), sem tocar em HTML de conteúdo
nem em dados.

### 20.3 Recuperação de senha (novo)

Este recurso **não existia** em nenhuma etapa anterior do projeto —
implementado agora, do zero, real (Supabase Auth), para os três tipos de
conta:

- **Administrador** (`admin/index.html`) — link "Esqueci minha senha".
- **Vendedor** (`vendedor/index.html`) — link "Esqueci minha senha".
- **Cliente** (`minha-conta.html`) — link "Esqueci minha senha" na aba de login.

**Como funciona:** a pessoa informa o e-mail e clica em "Esqueci minha
senha". `client.auth.resetPasswordForEmail(email, { redirectTo })` (uma
função nativa do Supabase Auth) envia um e-mail de verdade com um link de
recuperação, apontando para `/reset-password.html` — uma página única na
raiz do site, compartilhada pelos três tipos de conta.

Ao clicar no link do e-mail, o `supabase-js` detecta automaticamente o
token de recuperação na URL e cria uma sessão temporária só para trocar a
senha (sem precisar saber a senha antiga). A pessoa digita a nova senha
duas vezes, confirma, e o sistema:
1. Chama `client.auth.updateUser({ password })` — troca de verdade, com
   hash seguro (a senha nunca é vista nem guardada em texto puro por este
   projeto, isso é feito inteiramente pelo Supabase).
2. Verifica em qual tabela (`admin_profiles`, `seller_profiles` ou
   `customers`) o ID da pessoa aparece.
3. Redireciona automaticamente para a área certa
   (`admin/dashboard.html`, `vendedor/dashboard.html` ou
   `minha-conta.html`) — sem precisar logar de novo, já que a sessão da
   recuperação já é uma sessão válida.

Se alguém abrir `/reset-password.html` sem um link de recuperação válido
(ex.: token expirado, ou acesso direto à URL), a página mostra um aviso
claro pedindo para solicitar um novo link, em vez de mostrar um
formulário quebrado.

**Nenhuma configuração adicional é necessária** — usa a mesma
infraestrutura do Supabase Auth já configurada desde a Etapa 3. O único
cuidado ao publicar: confirme que o "Site URL" nas configurações de
Authentication do seu projeto Supabase está com a URL real do site em
produção (isso já era necessário para outros fluxos de e-mail do
Supabase, como confirmação de cadastro).

### 20.4 Testes realizados

**16 testes novos** (10 formais em `test-password-recovery.js`, mais 6
comprovações manuais antes de formalizar o arquivo), todos passando,
executando o **código real do projeto**:
- As três funções de solicitação de redefinição (`smAdminRequestPasswordReset`,
  `smVendorRequestPasswordReset`, `smCustomerRequestPasswordReset`) —
  confirmando que cada uma monta a URL de retorno corretamente
  (`/reset-password.html` na raiz) e retorna sucesso.
- `smResolveAccountDestination` — confirmando que administrador, vendedor
  e cliente são redirecionados cada um para a área certa depois de trocar
  a senha, e que um ID desconhecido cai em um destino seguro (`index.html`)
  em vez de quebrar.

**Suíte completa revalidada sem nenhuma regressão:** os 176 testes
formais acumulados dos módulos anteriores continuam passando, mais os 12
testes de carrinho e 3 de notificação push testados inline. Também
confirmado: sintaxe de 100% dos `.js`, todas as referências de arquivo
resolvendo, tags HTML e chaves CSS balanceadas em todo o projeto (site,
painel, portal do vendedor), nenhuma referência a `localhost` em nenhum
lugar do código, e `assets/js/products.js` permanece idêntico ao estado
do Módulo 6 (48 produtos, 8 categorias, nenhum tocado).

**O que não pôde ser testado neste ambiente:** a renderização visual real
em um navegador de celular (este ambiente não tem acesso a um navegador
gráfico) — a correção foi validada por auditoria estrutural do CSS
(cálculo manual de larguras disponíveis em 320/360/390/430px, revisão de
cada regra de media query) e pela identificação e correção dos bugs
concretos de CSS por trás de cada sintoma relatado, não por captura de
tela. Recomenda-se um teste visual final no celular real ou no modo de
dispositivo do navegador antes do lançamento. O envio real do e-mail de
recuperação de senha também não pôde ser testado (depende de rede/SMTP do
Supabase) — a lógica do código está testada; o envio de verdade só pode
ser confirmado após a publicação.

### 20.5 Arquivos alterados nesta correção

**Novos:** `reset-password.html`, `assets/js/reset-password-page.js`.

**Editados:** `assets/css/style.css` (grid de produtos, botões dos cards,
cabeçalho, busca, categorias/carrinho/checkout sem sobreposição, título da
página, botão flutuante do WhatsApp, estilo do link "esqueci minha
senha"), `admin/assets/css/admin.css` e `vendedor/assets/css/vendedor.css`
(estilo do link "esqueci minha senha"), `admin/assets/js/admin-auth.js`,
`vendedor/assets/js/vendedor-auth.js`, `assets/js/customer-auth.js`
(funções de solicitar redefinição de senha), `admin/index.html`,
`vendedor/index.html`, `assets/js/minha-conta-page.js` (link/fluxo
"esqueci minha senha" nas três telas de login).

**Não tocados:** produtos, categorias, preços, imagens, logo, cores,
`assets/js/products.js`, e todas as funcionalidades dos módulos 4-7
(carrinho, checkout, pagamento, nota fiscal, marketplace, PWA,
notificações push, split de pagamento).

### 20.6 Correção — link de recuperação de senha "abria o site normal"

**Sintoma relatado:** o e-mail de recuperação chegava certinho, mas ao
clicar em "Redefinir senha" o link abria o site normalmente (a Home),
sem nunca mostrar a tela de "criar nova senha".

**Causa raiz:** o Supabase Auth só honra o `redirectTo` passado por
`resetPasswordForEmail()` se essa URL estiver cadastrada na lista de
permissões do projeto (Authentication → URL Configuration → Redirect
URLs). Quando não está — ou quando a "Site URL" do projeto está
desatualizada —, o Supabase ignora o destino pedido e volta para a Site
URL padrão do projeto, geralmente a raiz do site. Como `index.html` não
tinha nenhum código para reconhecer um token de recuperação, o token era
perdido e a pessoa só via a Home normal.

**Duas correções, para o problema nunca mais acontecer mesmo se a
configuração do Supabase estiver errada ou for esquecida:**

1. **`assets/js/recovery-redirect-guard.js`** (novo) — um script minúsculo,
   carregado bem no início de **todas** as páginas públicas (site, painel,
   portal do vendedor). Ele verifica se a URL atual carrega um token de
   recuperação — nos dois formatos possíveis do Supabase
   (`#access_token=...&type=recovery` ou `?code=...`) — e, se a página
   atual não for `/reset-password.html`, redireciona na hora para lá,
   preservando o token. Ou seja: não importa mais para onde o Supabase
   decida mandar a pessoa, ela sempre acaba na tela certa.
2. **`assets/js/reset-password-page.js`** (reforçado) — a função
   `smDetectRecoverySession()` agora trata explicitamente os dois fluxos
   de autenticação que o Supabase pode usar (`implicit`, mais antigo, e
   `PKCE`, o padrão em projetos mais novos — como o seu, que usa o
   formato de chave `sb_publishable_...`), chamando
   `exchangeCodeForSession()` quando necessário, e escreve mensagens
   detalhadas no console do navegador (F12) para facilitar diagnosticar
   se algo ainda assim não funcionar em produção.

**Passo que só você pode fazer (fora do código) — provavelmente a causa
raiz de verdade do que você viu:** entre no painel do Supabase → seu
projeto → **Authentication → URL Configuration** e confira:
- **Site URL** deve ser a URL real do seu site publicado no Netlify
  (nunca `http://localhost:3000` nem qualquer coisa de desenvolvimento).
- **Redirect URLs** deve incluir `https://SEU-SITE.netlify.app/reset-password.html`
  (troque pela URL real do seu site) — sem essa linha, o Supabase recusa
  o redirecionamento correto mesmo com o código do site perfeito.

Com o `recovery-redirect-guard.js` já em vigor, o fluxo funciona mesmo que
esse passo seja esquecido — mas configurar corretamente evita um passo
extra de redirecionamento e é a forma "oficial" recomendada pelo próprio
Supabase.

**Testes:** `test-password-recovery-fix.js` — 11 testes novos, todos
passando, cobrindo o script de segurança (redireciona nos dois formatos
de token, nunca cria loop infinito, não interfere em navegação normal) e
a detecção de sessão nos dois fluxos (PKCE e implicit), incluindo o caso
de link inválido/expirado. Suíte completa revalidada: 187 testes
formais, 0 falhas, sem nenhuma regressão — login normal de administrador,
vendedor e cliente continuam funcionando exatamente como antes.

---

## PRÓXIMAS ETAPAS (resumo rápido)

**MÓDULO 8 (não iniciado):** aplicativo nativo compilado (React Native/Flutter — ver seção 19.6), split de pagamento com mais de um vendedor no mesmo carrinho (hoje limitado a um vendedor por pedido, ver seção 19.5), notificações push nativas (Firebase Cloud Messaging / Apple Push).

---

*Quando outra IA ou desenvolvedor receber este projeto, comece lendo este
arquivo do início ao fim (especialmente as seções 14, 16, 17, 18 e 19,
sobre como o backend, a plataforma de vendas e os recursos mais recentes
funcionam hoje, e `supabase/README.md` para configurar as credenciais),
depois abra `admin/assets/js/admin-data.js`, `assets/js/store.js` e
`assets/js/cart.js` para entender o fluxo de dados, e só então explore o
restante do código.*
