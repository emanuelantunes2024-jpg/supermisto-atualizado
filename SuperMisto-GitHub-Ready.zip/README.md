# SuperMisto

Site oficial + painel administrativo + plataforma de vendas da SuperMisto
(temperos, conservas, molhos, pimentas, ervas, chás e kits).

> **Este é o ponto de entrada rápido.** Para o histórico completo do
> projeto, decisões técnicas, o que funciona de verdade vs. o que depende
> de configuração externa, e o passo a passo de cada etapa, leia
> **[`PROJETO.md`](./PROJETO.md)** — este README só resume o essencial para
> começar.

---

## O que é este projeto

Um catálogo de e-commerce completo, construído em 5 módulos, cada um em
cima do anterior, sem quebrar nada do que já funcionava:

| Módulo | O que entrega |
|---|---|
| **1 — Site institucional** | Site público completo: catálogo, categorias, busca, páginas institucionais. 100% estático (HTML/CSS/JS puro). |
| **2 — Painel administrativo** | Área `/admin` para gerenciar produtos, categorias, banners e destaques. |
| **3 — Backend real** | Banco de dados real (Supabase/Postgres), autenticação real, upload de imagens, sincronização entre dispositivos. |
| **4 — Plataforma de vendas** | Carrinho, checkout, pedidos, clientes, estoque, pagamentos (modo de teste), preparação para nota fiscal. |
| **5 — Pagamento real e refinamentos** | Pagamento online real (Mercado Pago), galeria de imagens, histórico/auditoria, papéis de administrador (owner/editor), contato conectado a envio real, paginação no painel. |
| **6 — Nota fiscal e marketplace** | Emissão real de nota fiscal (Focus NFe), marketplace de múltiplos vendedores com portal próprio (`/vendedor`), comissão e aprovação pelo admin. |
| **7 — PWA, split e notificações** | App instalável (PWA) do site e do vendedor, notificações push reais, split de pagamento automático entre loja e vendedor via Mercado Pago Marketplace. |

## Tecnologia

- **Front-end:** HTML + CSS + JavaScript puro — sem framework, sem build step.
- **Backend:** [Supabase](https://supabase.com) (Postgres + Auth + Storage) — acessado direto do navegador via `supabase-js` (CDN).
- **Funções de servidor:** Netlify Functions (Node), só para as poucas operações que exigem uma credencial secreta (criar administrador, criar pedido, confirmar pagamento).
- **Hospedagem:** Netlify (estático + functions), configuração pronta em `netlify.toml`.

## Como rodar localmente

```bash
cd supermisto
python3 -m http.server 8000
# ou: npx serve .
```

Abra `http://localhost:8000`. Sem backend configurado, o site funciona
normalmente com os dados de fábrica de `assets/js/products.js` (nunca
quebra) — só o carrinho/checkout/painel exigem o Supabase configurado.

## Configurar o backend (obrigatório para usar o painel, o carrinho e o checkout)

Siga o passo a passo completo em **[`supabase/README.md`](./supabase/README.md)**:
1. Criar um projeto gratuito no Supabase.
2. Rodar, nesta ordem, no SQL Editor do Supabase:
   - `supabase/schema.sql`
   - `supabase/seed-data.sql`
   - `supabase/migrations/002_modulo4_vendas.sql`
   - `supabase/migrations/003_modulo5.sql`
   - `supabase/migrations/004_modulo6.sql`
   - `supabase/migrations/005_modulo7.sql`
   - `supabase/create-first-admin.sql`
3. Preencher `assets/js/supabase-config.js` com a URL e a chave pública do projeto.
4. Configurar `SUPABASE_URL` e `SUPABASE_SERVICE_ROLE_KEY` como variáveis de ambiente no Netlify (usadas só pelas Netlify Functions).
5. **Opcional:** `MERCADOPAGO_ACCESS_TOKEN` + `SITE_URL` para pagamento real, `RESEND_API_KEY` + `CONTACT_NOTIFY_EMAIL` para notificação de contato por e-mail, `FOCUS_NFE_API_TOKEN` + `FOCUS_NFE_ENVIRONMENT` para emissão real de nota fiscal, `VAPID_PUBLIC_KEY`/`VAPID_PRIVATE_KEY`/`VAPID_CONTACT_EMAIL` para notificações push, e `MERCADOPAGO_CLIENT_ID`/`MERCADOPAGO_CLIENT_SECRET` para split de pagamento — ver seções 17, 18 e 19 de `PROJETO.md`. Sem elas, o projeto continua funcionando normalmente (modo de teste / recursos opcionais desligados).

## Publicar no Netlify

Suba a pasta inteira para um repositório Git e conecte no Netlify, ou
arraste a pasta no painel ("Deploy manually"). O `netlify.toml` já está
configurado (raiz estática + `netlify/functions/`) — nada a mais é
necessário além dos passos de backend acima. A única Netlify Function com
dependência npm (`web-push`, usada pelas notificações) é instalada
automaticamente pelo Netlify a partir de `netlify/functions/package.json`
— não precisa rodar `npm install` manualmente em lugar nenhum.

## Estrutura (resumo)

```
supermisto/
├── index.html, produtos.html, ...     → Site público (agora instalável como PWA)
├── carrinho.html, checkout.html,
│   minha-conta.html                    → Compra e conta do cliente
├── admin/                              → Painel administrativo
├── vendedor/                           → Portal do vendedor (marketplace, também instalável)
├── assets/                             → CSS, JS, imagens e manifesto PWA do site público
├── service-worker.js                   → Service Worker da PWA do site público
├── supabase/                           → Schema SQL, migrations, seed de dados, guia de setup
├── netlify/functions/                  → Funções serverless (server-side, credenciais protegidas)
└── PROJETO.md                          → Documentação completa e histórico
```

Ver a árvore completa e a explicação de cada arquivo na seção 5 de `PROJETO.md`.

## Status funcional (resumo — detalhes em PROJETO.md)

- ✅ **Funcionando de verdade:** catálogo, categorias, busca, carrinho, criação de pedidos com validação real de estoque/preço no servidor, autenticação de clientes/administradores/vendedores, papéis de administrador (owner/editor), histórico/auditoria de produtos e categorias, formulário de contato (mensagem sempre salva de verdade), marketplace de vendedores (isolamento garantido por RLS), PWA instalável (site e portal do vendedor), painel completo.
- 🧪 **Funciona de verdade OU modo de teste/indisponível, dependendo da configuração:** pagamento (Mercado Pago real se `MERCADOPAGO_ACCESS_TOKEN` estiver configurado; senão confirmação manual pelo administrador), notificação por e-mail do contato (a mensagem em si é sempre salva), emissão de nota fiscal (real se `FOCUS_NFE_API_TOKEN` estiver configurado), notificações push (só aparecem se as chaves VAPID estiverem configuradas), e split de pagamento automático (só quando o vendedor conecta a própria conta Mercado Pago).
- ⚙️ **Depende de você configurar:** tudo que envolve o Supabase (ver acima) e, opcionalmente, o gateway de pagamento, o provedor de e-mail, o serviço de emissão fiscal e as chaves VAPID/Mercado Pago Marketplace.
- 🚧 **Ainda não implementado:** checkout como convidado, split de pagamento com mais de um vendedor no mesmo carrinho, aplicativo nativo compilado (a PWA já é instalável hoje; caminho para app de loja documentado na seção 19.6 do `PROJETO.md`).

---

*Dúvidas sobre qualquer decisão técnica, arquivo ou tabela do banco? Comece
por `PROJETO.md` — ele foi escrito para que qualquer pessoa (ou IA) consiga
continuar o projeto sem precisar adivinhar nada.*
