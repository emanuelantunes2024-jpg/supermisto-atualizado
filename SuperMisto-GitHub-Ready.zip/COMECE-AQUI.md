# COMECE AQUI — Guia definitivo (versão simplificada)

Recomeço do zero, do jeito mais simples possível. Esse guia foi encurtado
de propósito: em vez de vários textos de SQL separados, agora é **um
arquivo só** (`supabase/TUDO-EM-UM.sql`) que você cola **uma única vez**.

**Antes de começar, separe:**
- [ ] Um e-mail que você vai usar como administrador do site
- [ ] Uma senha simples, fácil de digitar sem errar (ex.: só letras minúsculas e números, sem símbolo)
- [ ] 15 minutos, sem pressa

---

## PARTE 1 — Criar o projeto no Supabase (do zero)

1. Entre em [supabase.com](https://supabase.com), faça login
2. Se você tiver algum projeto antigo confuso, pode deixar ele lá mesmo, sem mexer — vamos criar um **novo**, do zero
3. Clique em **"New project"**
4. Preencha:
   - **Nome:** `supermisto` (ou o que preferir)
   - **Senha do banco:** clique em "Generate a password" e depois em "Copy" — guarde num Bloco de Notas por precaução (não vamos precisar dela em nenhum outro passo)
   - **Região:** América do Sul (São Paulo)
5. Clique em **"Create new project"** e espere terminar de carregar (1-2 minutos)

---

## PARTE 2 — Rodar o banco de dados inteiro, de uma vez só

1. No projeto novo, menu esquerdo → **"SQL Editor"** → **"New query"**
2. Abra o arquivo **`supabase/TUDO-EM-UM.sql`** (dentro da pasta que você recebeu) com qualquer editor de texto
3. Selecione tudo (Ctrl+A) e copie (Ctrl+C)
4. Cole na caixa do SQL Editor
5. Clique em **"Run"**
6. Espere — é um arquivo grande, pode levar uns 10-20 segundos
7. Deve aparecer **"Success"**

✅ Pronto — banco de dados inteiro criado: produtos, categorias, carrinho, pedidos, papéis de administrador, vendedores, tudo.

**Se der algum erro:** tira um print da mensagem vermelha e me manda — mas com esse arquivo único, testado, a chance de erro é bem menor do que colando vários textos separados.

---

## PARTE 3 — Criar seu usuário administrador

Essa parte não dá pra fazer só por SQL — precisa ser feita na tela de usuários mesmo. Siga com atenção, é rápido:

1. Menu esquerdo → **"Authentication"** → **"Users"**
2. Clique em **"Add user"** → **"Create new user"** (não "Send invitation")
3. **Email:** o que você separou no início
4. **Password:** a senha simples que você separou
5. **Marque "Auto Confirm User"** — sem isso, o login não funciona
6. Clique em criar
7. Clique na linha do usuário recém-criado, copie o **"UID"** (código grande tipo `xxxxxxxx-xxxx-...`)

Agora, com esse UID em mãos, volte no **SQL Editor** → **New query**, cole isso (trocando os dois valores destacados):

```sql
insert into admin_profiles (id, email, full_name, role)
values (
  'COLE_O_UID_AQUI',
  'coleoemailaqui@exemplo.com',
  'Administrador',
  'owner'
)
on conflict (id) do update set
  email = excluded.email,
  full_name = excluded.full_name;
```

Clique em **"Run"**.

✅ Pronto — seu usuário já é administrador com acesso total.

---

## PARTE 4 — Pegar a URL e a chave do projeto

1. Menu esquerdo → **"Project Settings"** (ícone de engrenagem) → **"API"**
2. Copie o **"Project URL"**
3. Copie a chave **"anon public"** ou **"Publishable key"**
4. Me manda essas duas informações aqui no chat (a chave pública pode compartilhar sem problema, não é secreta) — eu atualizo `assets/js/supabase-config.js` com elas e te devolvo a pasta pronta

*(Alternativa, se preferir fazer você mesmo: abra `assets/js/supabase-config.js` num editor de texto e troque `SUA_URL_AQUI` e `SUA_CHAVE_AQUI` pelos valores copiados.)*

---

## PARTE 5 — Publicar no Netlify (do zero)

1. Entre em [app.netlify.com](https://app.netlify.com)
2. Clique em **"Add new site"** → **"Deploy manually"**
3. Arraste a pasta `supermisto` inteira (já com a Parte 4 feita) para dentro do quadro
4. Espere publicar, copie o link `.netlify.app`
5. Se aparecer a opção "Tornar público" / "Make public", clique nela

---

## PARTE 6 — Testar

1. Abre `seusite.netlify.app/admin`
2. Entra com o e-mail e a senha da Parte 3
3. Deve abrir o painel — Dashboard, Produtos, Pedidos, etc.

---

## Por que isso deve funcionar melhor dessa vez

- **Um projeto Supabase só**, criado do zero — sem confusão de qual projeto está com qual dado
- **Um arquivo de SQL só**, ao invés de 6 textos separados — menos chance de pular um passo ou colar errado
- **Uma senha simples**, digitada com calma, sem autopreenchimento de navegador atrapalhando

Se travar em algum passo, manda o print exato de onde parou (Parte X) que eu te aponto o próximo clique — sem mais voltas.
