-- ============================================================================
-- SUPERMISTO — supabase/schema.sql (ETAPA 3)
-- ============================================================================
-- Rode este arquivo INTEIRO uma vez no SQL Editor do seu projeto Supabase
-- (Supabase → seu projeto → SQL Editor → New query → cole tudo → Run).
--
-- Ele cria:
--   1. As tabelas do catálogo (categories, products, banners, settings)
--   2. A tabela de perfis administrativos (admin_profiles)
--   3. Triggers para manter "updated_at" sempre atualizado
--   4. RLS (Row Level Security) com as políticas de acesso público/admin
--
-- É seguro rodar mais de uma vez: todos os comandos usam
-- "IF NOT EXISTS" / "CREATE OR REPLACE" / "DROP POLICY IF EXISTS" antes de
-- criar de novo, então rodar duas vezes não quebra nada nem duplica nada.
-- ============================================================================

-- Extensão usada para gerar IDs aleatórios (uuid) em banners
create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- Função utilitária: atualiza automaticamente a coluna updated_at
-- ----------------------------------------------------------------------------
create or replace function sm_set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- ============================================================================
-- 1. CATEGORIES
-- ============================================================================
create table if not exists categories (
  slug        text primary key,
  name        text not null,
  icon        text default '⭐',
  description text default '',
  image       text,
  bg          text default '#F0E4F7',
  fg          text default '#3A1150',
  active      boolean not null default true,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

drop trigger if exists trg_categories_updated_at on categories;
create trigger trg_categories_updated_at
  before update on categories
  for each row execute function sm_set_updated_at();

-- ============================================================================
-- 2. PRODUCTS
-- ============================================================================
create table if not exists products (
  id                text primary key,
  name              text not null,
  category          text references categories(slug) on update cascade on delete set null,
  price             numeric(10,2) not null default 0,
  sale_price        numeric(10,2),
  cost_price        numeric(10,2),          -- custo interno (não aparece no site público)
  weight            text default '',
  unit              text default '',
  short_desc        text default '',
  description       text default '',
  emoji             text default '🌶️',
  image             text,
  images            text[] not null default '{}',
  available         boolean not null default true,
  featured          boolean not null default false,
  is_new            boolean not null default false,
  is_kit            boolean not null default false,
  recommended       boolean not null default false,
  buy_link          text default '#',
  whatsapp_message  text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists idx_products_category on products(category);
create index if not exists idx_products_featured on products(featured) where featured = true;

drop trigger if exists trg_products_updated_at on products;
create trigger trg_products_updated_at
  before update on products
  for each row execute function sm_set_updated_at();

-- ============================================================================
-- 3. BANNERS
-- ============================================================================
create table if not exists banners (
  id          uuid primary key default gen_random_uuid(),
  title       text default '',
  subtitle    text default '',
  button      text default '',
  link        text default '#',
  image       text,
  active      boolean not null default false,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

drop trigger if exists trg_banners_updated_at on banners;
create trigger trg_banners_updated_at
  before update on banners
  for each row execute function sm_set_updated_at();

-- ============================================================================
-- 4. SETTINGS (linha única — id sempre 1)
-- ============================================================================
create table if not exists settings (
  id                integer primary key default 1 check (id = 1),
  whatsapp          text default '5500000000000',
  whatsapp_message  text default 'Olá! Vim pelo site da SuperMisto e gostaria de saber mais sobre os produtos.',
  email             text default 'contato@supermisto.com.br',
  instagram         text default '#',
  facebook          text default '#',
  updated_at        timestamptz not null default now()
);

insert into settings (id) values (1) on conflict (id) do nothing;

drop trigger if exists trg_settings_updated_at on settings;
create trigger trg_settings_updated_at
  before update on settings
  for each row execute function sm_set_updated_at();

-- ============================================================================
-- 5. ADMIN_PROFILES
-- ============================================================================
-- Não guarda senha nenhuma aqui — a senha é gerenciada pelo Supabase Auth
-- (auth.users), com hash seguro, fora do nosso controle direto. Esta tabela
-- só guarda informações extras de cada administrador.
create table if not exists admin_profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text not null,
  full_name   text default '',
  role        text not null default 'admin',
  created_at  timestamptz not null default now()
);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================================
alter table categories     enable row level security;
alter table products       enable row level security;
alter table banners        enable row level security;
alter table settings       enable row level security;
alter table admin_profiles enable row level security;

-- ---- CATEGORIES ----
-- Leitura pública (o site público precisa ver todas para poder, por exemplo,
-- mostrar a categoria de um produto mesmo que ela esteja "inativa"; quem
-- decide o que mostrar na navegação é o próprio código do site, como já
-- acontecia na Etapa 2).
drop policy if exists categories_public_read on categories;
create policy categories_public_read on categories
  for select using (true);

-- Escrita só para quem estiver autenticado (ou seja, administradores logados
-- via Supabase Auth — não existe cadastro público de usuários neste projeto).
drop policy if exists categories_admin_write on categories;
create policy categories_admin_write on categories
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ---- PRODUCTS ----
drop policy if exists products_public_read on products;
create policy products_public_read on products
  for select using (true);

drop policy if exists products_admin_write on products;
create policy products_admin_write on products
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ---- BANNERS ----
-- O público só vê banners ativos; administradores autenticados veem todos
-- (inclusive rascunhos/inativos) para poder gerenciar.
drop policy if exists banners_public_read on banners;
create policy banners_public_read on banners
  for select using (active = true or auth.role() = 'authenticated');

drop policy if exists banners_admin_write on banners;
create policy banners_admin_write on banners
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ---- SETTINGS ----
drop policy if exists settings_public_read on settings;
create policy settings_public_read on settings
  for select using (true);

drop policy if exists settings_admin_write on settings;
create policy settings_admin_write on settings
  for update using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ---- ADMIN_PROFILES ----
-- Qualquer administrador autenticado pode ver a lista de administradores
-- (útil para uma futura tela "Usuários"). Ninguém de fora consegue ler.
drop policy if exists admin_profiles_read on admin_profiles;
create policy admin_profiles_read on admin_profiles
  for select using (auth.role() = 'authenticated');

-- A criação de novos administradores é feita só pela Netlify Function
-- (netlify/functions/admin-create-user.js), que usa a service_role key
-- (poder total, ignora RLS) — por isso não existe policy de INSERT aqui
-- para usuários comuns autenticados. Cada admin só pode editar o próprio
-- perfil (ex.: nome de exibição).
drop policy if exists admin_profiles_update_self on admin_profiles;
create policy admin_profiles_update_self on admin_profiles
  for update using (auth.uid() = id)
  with check (auth.uid() = id);

-- ============================================================================
-- 6. STORAGE (imagens de produtos e banners)
-- ============================================================================
-- Cria dois buckets públicos de leitura: "products" e "banners".
-- Upload de arquivo só é permitido para administradores autenticados.
insert into storage.buckets (id, name, public)
values ('products', 'products', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('banners', 'banners', true)
on conflict (id) do nothing;

drop policy if exists sm_storage_public_read on storage.objects;
create policy sm_storage_public_read on storage.objects
  for select using (bucket_id in ('products', 'banners'));

drop policy if exists sm_storage_admin_write on storage.objects;
create policy sm_storage_admin_write on storage.objects
  for insert with check (bucket_id in ('products', 'banners') and auth.role() = 'authenticated');

drop policy if exists sm_storage_admin_update on storage.objects;
create policy sm_storage_admin_update on storage.objects
  for update using (bucket_id in ('products', 'banners') and auth.role() = 'authenticated');

drop policy if exists sm_storage_admin_delete on storage.objects;
create policy sm_storage_admin_delete on storage.objects
  for delete using (bucket_id in ('products', 'banners') and auth.role() = 'authenticated');

-- ============================================================================
-- FIM DO SCHEMA
-- Próximo passo: rode supabase/seed-data.sql para migrar os 48 produtos e
-- 8 categorias originais da Etapa 1/2 para dentro destas tabelas.
-- ============================================================================
