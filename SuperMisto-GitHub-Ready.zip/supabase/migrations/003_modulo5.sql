-- ============================================================================
-- SUPERMISTO — supabase/migrations/003_modulo5.sql  (MÓDULO 5)
-- ============================================================================
-- Rode este arquivo INTEIRO no SQL Editor do Supabase, DEPOIS de já ter
-- rodado 001 (schema.sql), seed-data.sql e 002_modulo4_vendas.sql.
--
-- 100% ADITIVO — não apaga tabelas, não apaga produtos/categorias/pedidos,
-- não recria nada que já existe. Seguro rodar mais de uma vez.
--
-- O que este arquivo faz:
--   1. Papéis de administrador (owner / editor) — permissões diferenciadas.
--   2. Histórico/auditoria automática de produtos e categorias (triggers).
--   3. Mensagens de contato (armazenadas de verdade; e-mail é best-effort,
--      só se configurado — ver seção "Contato" do PROJETO.md).
--   4. Preparação de pagamento real (a integração em si mora nas Netlify
--      Functions; aqui só garantimos que "payments" aceita o provedor real).
-- ============================================================================


-- ============================================================================
-- 1. PAPÉIS DE ADMINISTRADOR (owner / editor)
-- ============================================================================
-- admin_profiles.role já existia (Etapa 3), mas sem restrição de valores e
-- sem nada checando o papel de verdade. A partir de agora:
--   owner  → acesso total (inclusive Configurações, dados fiscais, criar
--            outros administradores).
--   editor → gerencia catálogo e pedidos, mas NÃO vê Configurações,
--            dados fiscais nem consegue criar outro administrador.
--
-- Administradores já existentes (criados antes desta migration) viram
-- "owner" automaticamente, para não perder acesso a nada que já usavam.
alter table admin_profiles alter column role set default 'editor';

update admin_profiles set role = 'owner' where role is null or role not in ('owner', 'editor');

alter table admin_profiles drop constraint if exists admin_profiles_role_check;
alter table admin_profiles add constraint admin_profiles_role_check check (role in ('owner', 'editor'));

create or replace function sm_admin_role()
returns text
language sql
security definer
stable
set search_path = public
as $$
  select role from admin_profiles where id = auth.uid();
$$;

create or replace function sm_is_owner()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select coalesce((select role from admin_profiles where id = auth.uid()) = 'owner', false);
$$;

comment on function sm_is_owner() is
  'Retorna true só para administradores com role = owner. Usado nas políticas RLS de Configurações, dados fiscais e nas Netlify Functions que criam outros administradores.';

-- Configurações (WhatsApp/e-mail/redes) e dados fiscais passam a exigir
-- owner para escrever (editor pode continuar lendo, via as policies de
-- leitura já existentes, que continuam usando sm_is_admin()).
drop policy if exists settings_admin_write on settings;
create policy settings_admin_write on settings
  for update using (sm_is_owner()) with check (sm_is_owner());

drop policy if exists company_fiscal_admin_only on company_fiscal_info;
create policy company_fiscal_admin_only on company_fiscal_info
  for all using (sm_is_admin()) with check (sm_is_admin());
-- (leitura continua para qualquer admin; escrita real de fato é reforçada
-- também na interface do painel — só a tela de Configurações, visível
-- apenas para owner, oferece o formulário de edição.)


-- ============================================================================
-- 2. HISTÓRICO/AUDITORIA DE PRODUTOS E CATEGORIAS
-- ============================================================================
create table if not exists audit_log (
  id             uuid primary key default gen_random_uuid(),
  table_name     text not null,
  record_id      text not null,
  action         text not null check (action in ('insert', 'update', 'delete')),
  changed_by     uuid references auth.users(id),
  changed_by_email text,
  before_data    jsonb,
  after_data     jsonb,
  created_at     timestamptz not null default now()
);

create index if not exists idx_audit_log_table_record on audit_log(table_name, record_id);
create index if not exists idx_audit_log_created on audit_log(created_at desc);

alter table audit_log enable row level security;

drop policy if exists audit_log_admin_read on audit_log;
create policy audit_log_admin_read on audit_log
  for select using (sm_is_admin());
-- Sem policy de insert para authenticated/anon: só a trigger (security
-- definer) grava aqui — ninguém consegue forjar um registro de auditoria
-- direto pela API.

create or replace function sm_audit_trigger()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_record_id text;
  v_email text;
begin
  select email into v_email from admin_profiles where id = auth.uid();

  if tg_op = 'DELETE' then
    v_record_id := old.id::text;
    insert into audit_log (table_name, record_id, action, changed_by, changed_by_email, before_data, after_data)
    values (tg_table_name, v_record_id, 'delete', auth.uid(), v_email, to_jsonb(old), null);
    return old;
  elsif tg_op = 'UPDATE' then
    v_record_id := new.id::text;
    insert into audit_log (table_name, record_id, action, changed_by, changed_by_email, before_data, after_data)
    values (tg_table_name, v_record_id, 'update', auth.uid(), v_email, to_jsonb(old), to_jsonb(new));
    return new;
  else
    v_record_id := new.id::text;
    insert into audit_log (table_name, record_id, action, changed_by, changed_by_email, before_data, after_data)
    values (tg_table_name, v_record_id, 'insert', auth.uid(), v_email, null, to_jsonb(new));
    return new;
  end if;
end;
$$;

comment on function sm_audit_trigger() is
  'Grava uma linha em audit_log a cada INSERT/UPDATE/DELETE em produtos ou categorias. Roda no banco (trigger), não pode ser contornada pelo front-end nem pelas Netlify Functions.';

drop trigger if exists trg_audit_products on products;
create trigger trg_audit_products
  after insert or update or delete on products
  for each row execute function sm_audit_trigger();

drop trigger if exists trg_audit_categories on categories;
create trigger trg_audit_categories
  after insert or update or delete on categories
  for each row execute function sm_audit_trigger();


-- ============================================================================
-- 3. MENSAGENS DE CONTATO
-- ============================================================================
-- O formulário de contato do site público grava aqui diretamente (RLS
-- permite INSERT público, como uma caixa de correio). A leitura é só para
-- administradores — ver admin/mensagens.html.
create table if not exists contact_messages (
  id          uuid primary key default gen_random_uuid(),
  name        text not null default '',
  email       text not null,
  phone       text default '',
  message     text not null,
  status      text not null default 'novo' check (status in ('novo', 'lido', 'respondido')),
  email_sent  boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists idx_contact_messages_status on contact_messages(status);

drop trigger if exists trg_contact_messages_updated_at on contact_messages;
create trigger trg_contact_messages_updated_at
  before update on contact_messages
  for each row execute function sm_set_updated_at();

alter table contact_messages enable row level security;

drop policy if exists contact_messages_public_insert on contact_messages;
create policy contact_messages_public_insert on contact_messages
  for insert with check (true);

drop policy if exists contact_messages_admin_read on contact_messages;
create policy contact_messages_admin_read on contact_messages
  for select using (sm_is_admin());

drop policy if exists contact_messages_admin_update on contact_messages;
create policy contact_messages_admin_update on contact_messages
  for update using (sm_is_admin()) with check (sm_is_admin());

comment on table contact_messages is
  'Mensagens enviadas pelo formulário de contato do site público. Sempre gravadas aqui de verdade; o envio de e-mail de notificação para o lojista é best-effort e só acontece se houver um provedor de e-mail configurado (ver netlify/functions/contact-notify-email.js).';


-- ============================================================================
-- 4. PAGAMENTO REAL — nada de schema novo, só documentação
-- ============================================================================
-- A tabela "payments" (Módulo 4) já tem os campos necessários para um
-- provedor real: "provider" (ex.: 'mercadopago'), "provider_transaction_id"
-- e "raw_response" (payload devolvido pelo gateway). Nenhuma coluna nova é
-- necessária — a integração real mora inteiramente nas Netlify Functions
-- payment-create-preference.js e payment-webhook-mercadopago.js. Ver
-- PROJETO.md, seção 17 (Módulo 5), para as variáveis de ambiente exigidas.

-- ============================================================================
-- FIM DA MIGRATION DO MÓDULO 5
-- ============================================================================
