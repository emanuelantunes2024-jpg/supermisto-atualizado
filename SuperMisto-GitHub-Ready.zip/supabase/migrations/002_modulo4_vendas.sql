-- ============================================================================
-- SUPERMISTO — supabase/migrations/002_modulo4_vendas.sql  (MÓDULO 4)
-- ============================================================================
-- Rode este arquivo INTEIRO no SQL Editor do Supabase, DEPOIS de já ter
-- rodado supabase/schema.sql e supabase/seed-data.sql (Etapa 3).
--
-- Este arquivo é 100% ADITIVO: não apaga tabelas, não apaga produtos, não
-- apaga categorias, não recria nada que já existe. Todos os comandos usam
-- "IF NOT EXISTS" / "ADD COLUMN IF NOT EXISTS" / "CREATE OR REPLACE" /
-- "DROP POLICY IF EXISTS" antes de criar de novo — seguro rodar mais de
-- uma vez.
--
-- O que este arquivo faz:
--   1. CORRIGE uma brecha de segurança da Etapa 3 (ver 4.0 abaixo) — deve
--      ser a primeira coisa a rodar, antes de existir qualquer cliente
--      cadastrado.
--   2. Adiciona estoque e campos fiscais aos produtos existentes (sem
--      alterar nenhum dado existente).
--   3. Cria as tabelas de clientes, endereços, pedidos, itens do pedido,
--      histórico de status, pagamentos e documentos fiscais.
--   4. Cria a função sm_create_order(), que cria um pedido inteiro (com
--      todos os itens e a baixa de estoque) em uma única transação atômica
--      — evita duas pessoas comprarem o último item em estoque ao mesmo
--      tempo e os dois pedidos serem aceitos.
-- ============================================================================


-- ============================================================================
-- 0. CORREÇÃO DE SEGURANÇA — LEIA ANTES DE CONTINUAR
-- ============================================================================
-- Na Etapa 3, todas as políticas de escrita (produtos, categorias, banners,
-- configurações) usavam `auth.role() = 'authenticated'` como critério de
-- "é administrador". Isso era seguro na época porque só existiam contas de
-- administrador no sistema.
--
-- A partir do Módulo 4, CLIENTES também podem criar conta e fazer login
-- (Supabase Auth). Se não corrigirmos isso agora, qualquer cliente logado
-- passaria a satisfazer `auth.role() = 'authenticated'` e conseguiria, por
-- exemplo, editar preços de produtos direto pela API — uma falha grave.
--
-- A correção: uma função `sm_is_admin()` que verifica se o usuário logado
-- tem uma linha correspondente em `admin_profiles` (que só é populada pela
-- Netlify Function admin-create-user.js ou pelo SQL de
-- create-first-admin.sql — nunca por auto-cadastro). Todas as políticas
-- "_admin_write" de produtos/categorias/banners/configurações/storage são
-- recriadas para usar `sm_is_admin()` no lugar de `auth.role() = 'authenticated'`.
create or replace function sm_is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from admin_profiles where id = auth.uid()
  );
$$;

comment on function sm_is_admin() is
  'Retorna true apenas se o usuário logado tiver um perfil em admin_profiles. Usado em todas as políticas RLS que prote gem operações administrativas — NUNCA usar auth.role() = ''authenticated'' sozinho para decidir permissão de admin, pois isso também é verdadeiro para clientes logados.';

-- Recria as políticas de escrita existentes usando sm_is_admin()
drop policy if exists categories_admin_write on categories;
create policy categories_admin_write on categories
  for all using (sm_is_admin()) with check (sm_is_admin());

drop policy if exists products_admin_write on products;
create policy products_admin_write on products
  for all using (sm_is_admin()) with check (sm_is_admin());

drop policy if exists banners_public_read on banners;
create policy banners_public_read on banners
  for select using (active = true or sm_is_admin());

drop policy if exists banners_admin_write on banners;
create policy banners_admin_write on banners
  for all using (sm_is_admin()) with check (sm_is_admin());

drop policy if exists settings_admin_write on settings;
create policy settings_admin_write on settings
  for update using (sm_is_admin()) with check (sm_is_admin());

drop policy if exists admin_profiles_read on admin_profiles;
create policy admin_profiles_read on admin_profiles
  for select using (sm_is_admin());

drop policy if exists sm_storage_admin_write on storage.objects;
create policy sm_storage_admin_write on storage.objects
  for insert with check (bucket_id in ('products', 'banners') and sm_is_admin());

drop policy if exists sm_storage_admin_update on storage.objects;
create policy sm_storage_admin_update on storage.objects
  for update using (bucket_id in ('products', 'banners') and sm_is_admin());

drop policy if exists sm_storage_admin_delete on storage.objects;
create policy sm_storage_admin_delete on storage.objects
  for delete using (bucket_id in ('products', 'banners') and sm_is_admin());


-- ============================================================================
-- 1. ESTOQUE E CAMPOS FISCAIS EM PRODUCTS (aditivo — não altera dados existentes)
-- ============================================================================
alter table products add column if not exists track_stock boolean not null default false;
alter table products add column if not exists stock_quantity integer not null default 0;

-- Campos fiscais do PRODUTO (preparação para nota fiscal — ver seção 9 do
-- PROJETO.md). Ficam nulos até serem preenchidos; não afetam o site público.
alter table products add column if not exists ncm text;
alter table products add column if not exists cfop text;
alter table products add column if not exists fiscal_origin text;

comment on column products.track_stock is
  'Se false (padrão), o produto usa só o campo "available" (disponível/indisponível) como na Etapa 2/3 — sem controle numérico. Se true, o site e o checkout passam a validar stock_quantity antes de vender.';
comment on column products.stock_quantity is
  'Quantidade em estoque. Só é validada no checkout quando track_stock = true.';

create index if not exists idx_products_track_stock on products(track_stock) where track_stock = true;


-- ============================================================================
-- 2. CUSTOMERS (clientes)
-- ============================================================================
-- Um cliente é sempre um usuário do Supabase Auth (mesma tecnologia usada
-- para administradores desde a Etapa 3, mas em uma tabela separada de
-- admin_profiles — um cliente NUNCA aparece em admin_profiles, e portanto
-- sm_is_admin() é sempre false para ele).
create table if not exists customers (
  id          uuid primary key references auth.users(id) on delete cascade,
  name        text not null default '',
  email       text not null,
  phone       text default '',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

drop trigger if exists trg_customers_updated_at on customers;
create trigger trg_customers_updated_at
  before update on customers
  for each row execute function sm_set_updated_at();

alter table customers enable row level security;

drop policy if exists customers_self_or_admin_read on customers;
create policy customers_self_or_admin_read on customers
  for select using (auth.uid() = id or sm_is_admin());

drop policy if exists customers_self_insert on customers;
create policy customers_self_insert on customers
  for insert with check (auth.uid() = id);

drop policy if exists customers_self_or_admin_update on customers;
create policy customers_self_or_admin_update on customers
  for update using (auth.uid() = id or sm_is_admin())
  with check (auth.uid() = id or sm_is_admin());


-- ============================================================================
-- 3. ADDRESSES (endereços de entrega)
-- ============================================================================
create table if not exists addresses (
  id              uuid primary key default gen_random_uuid(),
  customer_id     uuid not null references customers(id) on delete cascade,
  label           text default 'Principal',
  recipient_name  text default '',
  phone           text default '',
  cep             text default '',
  street          text default '',
  number          text default '',
  complement      text default '',
  neighborhood    text default '',
  city            text default '',
  state           text default '',
  is_default      boolean not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index if not exists idx_addresses_customer on addresses(customer_id);

drop trigger if exists trg_addresses_updated_at on addresses;
create trigger trg_addresses_updated_at
  before update on addresses
  for each row execute function sm_set_updated_at();

alter table addresses enable row level security;

drop policy if exists addresses_owner_or_admin on addresses;
create policy addresses_owner_or_admin on addresses
  for all using (customer_id = auth.uid() or sm_is_admin())
  with check (customer_id = auth.uid() or sm_is_admin());


-- ============================================================================
-- 4. ORDERS (pedidos)
-- ============================================================================
-- Sequência usada para gerar um número de pedido legível (SM-000001,
-- SM-000002, ...) de forma atômica, sem depender de lógica no frontend.
create sequence if not exists sm_order_seq start 1;

create or replace function sm_next_order_number()
returns text
language sql
as $$
  select 'SM-' || lpad(nextval('sm_order_seq')::text, 6, '0');
$$;

create table if not exists orders (
  id                 uuid primary key default gen_random_uuid(),
  order_number       text not null unique default sm_next_order_number(),
  customer_id        uuid references customers(id),
  status             text not null default 'aguardando_pagamento'
                       check (status in (
                         'aguardando_pagamento','pagamento_aprovado','em_preparacao',
                         'pronto_envio','enviado','entregue','cancelado','reembolsado'
                       )),
  payment_status     text not null default 'pending'
                       check (payment_status in ('pending','approved','refused','cancelled','refunded')),
  subtotal           numeric(10,2) not null default 0,
  discount           numeric(10,2) not null default 0,
  shipping           numeric(10,2) not null default 0,
  total              numeric(10,2) not null default 0,
  shipping_address   jsonb,                    -- snapshot do endereço no momento da compra
  customer_snapshot  jsonb,                    -- snapshot de nome/e-mail/telefone no momento da compra
  notes              text default '',
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create index if not exists idx_orders_customer on orders(customer_id);
create index if not exists idx_orders_status on orders(status);
create index if not exists idx_orders_created on orders(created_at desc);

drop trigger if exists trg_orders_updated_at on orders;
create trigger trg_orders_updated_at
  before update on orders
  for each row execute function sm_set_updated_at();

alter table orders enable row level security;

-- Clientes só veem os próprios pedidos; administradores veem todos.
drop policy if exists orders_owner_or_admin_read on orders;
create policy orders_owner_or_admin_read on orders
  for select using (customer_id = auth.uid() or sm_is_admin());

-- Criação de pedido NÃO tem policy de INSERT para authenticated/anon de
-- propósito: todo pedido é criado através da função sm_create_order()
-- (chamada pela Netlify Function checkout-create-order.js com a
-- service_role key), que valida estoque e preços no servidor antes de
-- gravar qualquer coisa. Isso impede um cliente de inserir um pedido
-- diretamente pela API com preços ou totais forjados.
--
-- Só administradores podem alterar o status de um pedido diretamente pelo
-- painel (ex.: marcar como "enviado").
drop policy if exists orders_admin_update on orders;
create policy orders_admin_update on orders
  for update using (sm_is_admin()) with check (sm_is_admin());


-- ============================================================================
-- 5. ORDER_ITEMS (itens do pedido)
-- ============================================================================
create table if not exists order_items (
  id            uuid primary key default gen_random_uuid(),
  order_id      uuid not null references orders(id) on delete cascade,
  product_id    text references products(id) on delete set null,
  product_name  text not null,          -- snapshot: nome no momento da compra
  unit_price    numeric(10,2) not null, -- snapshot: preço no momento da compra
  quantity      integer not null check (quantity > 0),
  subtotal      numeric(10,2) not null
);

create index if not exists idx_order_items_order on order_items(order_id);

alter table order_items enable row level security;

drop policy if exists order_items_via_order on order_items;
create policy order_items_via_order on order_items
  for select using (
    exists (
      select 1 from orders o
      where o.id = order_items.order_id
        and (o.customer_id = auth.uid() or sm_is_admin())
    )
  );
-- Sem policy de insert/update/delete para authenticated/anon: os itens só
-- são criados dentro de sm_create_order() (executada com privilégio de
-- dono da função — ver "security definer" abaixo).


-- ============================================================================
-- 6. ORDER_STATUS_HISTORY (histórico de alterações do pedido)
-- ============================================================================
create table if not exists order_status_history (
  id          uuid primary key default gen_random_uuid(),
  order_id    uuid not null references orders(id) on delete cascade,
  status      text not null,
  changed_by  uuid references auth.users(id),
  note        text default '',
  created_at  timestamptz not null default now()
);

create index if not exists idx_status_history_order on order_status_history(order_id);

alter table order_status_history enable row level security;

drop policy if exists status_history_read on order_status_history;
create policy status_history_read on order_status_history
  for select using (
    exists (
      select 1 from orders o
      where o.id = order_status_history.order_id
        and (o.customer_id = auth.uid() or sm_is_admin())
    )
  );

drop policy if exists status_history_admin_insert on order_status_history;
create policy status_history_admin_insert on order_status_history
  for insert with check (sm_is_admin());


-- ============================================================================
-- 7. PAYMENTS (pagamentos)
-- ============================================================================
create table if not exists payments (
  id                        uuid primary key default gen_random_uuid(),
  order_id                  uuid not null references orders(id) on delete cascade,
  customer_id               uuid references customers(id),
  provider                  text not null default 'mock',   -- 'mock' | futuramente 'mercadopago', 'stripe', etc.
  provider_transaction_id   text,
  amount                    numeric(10,2) not null,
  status                    text not null default 'pending'
                              check (status in ('pending','approved','refused','cancelled','refunded')),
  method                    text,                            -- 'pix' | 'credit_card' | 'boleto' | ...
  raw_response              jsonb,
  created_at                timestamptz not null default now(),
  updated_at                timestamptz not null default now()
);

create index if not exists idx_payments_order on payments(order_id);

drop trigger if exists trg_payments_updated_at on payments;
create trigger trg_payments_updated_at
  before update on payments
  for each row execute function sm_set_updated_at();

alter table payments enable row level security;

drop policy if exists payments_owner_or_admin_read on payments;
create policy payments_owner_or_admin_read on payments
  for select using (customer_id = auth.uid() or sm_is_admin());

-- Administradores podem atualizar manualmente (ex.: confirmar um pagamento
-- via transferência bancária). Criação inicial do pagamento é feita dentro
-- de sm_create_order(); confirmações automáticas (modo de teste) vêm da
-- Netlify Function payment-mock-confirm.js, usando a service_role key.
drop policy if exists payments_admin_update on payments;
create policy payments_admin_update on payments
  for update using (sm_is_admin()) with check (sm_is_admin());


-- ============================================================================
-- 8. FISCAL_DOCUMENTS (nota fiscal — só estrutura, sem integração real)
-- ============================================================================
-- IMPORTANTE: esta tabela só guarda o ESTADO de uma futura nota fiscal.
-- Nenhuma nota fiscal é emitida de verdade por este projeto — não existe
-- integração com nenhuma API fiscal (SEFAZ, NFE.io, Focus NFe, etc.) nesta
-- etapa. Ver seção "Nota fiscal" do PROJETO.md para o que falta conectar.
create table if not exists fiscal_documents (
  id             uuid primary key default gen_random_uuid(),
  order_id       uuid not null references orders(id) on delete cascade,
  status         text not null default 'nao_emitida'
                   check (status in ('nao_emitida','pendente','emitida','erro','cancelada')),
  numero         text,
  serie          text,
  chave_acesso   text,
  provider       text,          -- nome do provedor fiscal, quando existir uma integração real
  emitted_at     timestamptz,
  raw_response   jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create index if not exists idx_fiscal_documents_order on fiscal_documents(order_id);

drop trigger if exists trg_fiscal_documents_updated_at on fiscal_documents;
create trigger trg_fiscal_documents_updated_at
  before update on fiscal_documents
  for each row execute function sm_set_updated_at();

alter table fiscal_documents enable row level security;

drop policy if exists fiscal_documents_admin_only on fiscal_documents;
create policy fiscal_documents_admin_only on fiscal_documents
  for all using (sm_is_admin()) with check (sm_is_admin());


-- ============================================================================
-- 9. COMPANY_FISCAL_INFO (dados fiscais da empresa — linha única, id=1)
-- ============================================================================
create table if not exists company_fiscal_info (
  id                    integer primary key default 1 check (id = 1),
  razao_social          text default '',
  nome_fantasia         text default '',
  cnpj                  text default '',
  inscricao_estadual    text default '',
  regime_tributario     text default '',
  endereco              jsonb default '{}',
  updated_at            timestamptz not null default now()
);

insert into company_fiscal_info (id) values (1) on conflict (id) do nothing;

drop trigger if exists trg_company_fiscal_updated_at on company_fiscal_info;
create trigger trg_company_fiscal_updated_at
  before update on company_fiscal_info
  for each row execute function sm_set_updated_at();

alter table company_fiscal_info enable row level security;

drop policy if exists company_fiscal_admin_only on company_fiscal_info;
create policy company_fiscal_admin_only on company_fiscal_info
  for all using (sm_is_admin()) with check (sm_is_admin());


-- ============================================================================
-- 10. sm_create_order() — criação atômica de pedido (valida estoque e preço)
-- ============================================================================
-- Recebe os itens do carrinho (só product_id + quantity — NUNCA confia em
-- preço vindo do cliente) e cria, em uma única transação:
--   - o pedido (orders)
--   - os itens do pedido, com preço vindo do banco no momento da compra (order_items)
--   - o registro de pagamento inicial, status "pending" (payments)
--   - a baixa de estoque dos produtos com track_stock = true (products)
--   - o primeiro registro de histórico de status (order_status_history)
--
-- Se qualquer produto não existir, estiver indisponível, ou não tiver
-- estoque suficiente, a função inteira falha (raise exception) e o
-- Postgres desfaz automaticamente tudo que já tinha sido feito — não fica
-- nenhum pedido "pela metade".
--
-- security definer: roda com o dono da função (que tem acesso total às
-- tabelas), então funciona mesmo com RLS habilitado nas tabelas envolvidas
-- — é por isso que orders/order_items não precisam de policy pública de
-- INSERT: toda escrita passa por aqui.
create or replace function sm_create_order(
  p_customer_id uuid,
  p_items jsonb,               -- [{"product_id": "alho-desidratado", "quantity": 2}, ...]
  p_shipping_address jsonb,
  p_customer_snapshot jsonb,
  p_shipping numeric default 0,
  p_discount numeric default 0,
  p_payment_method text default 'pix'
)
returns table (order_id uuid, order_number text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item jsonb;
  v_product products%rowtype;
  v_qty integer;
  v_unit_price numeric(10,2);
  v_subtotal numeric(10,2) := 0;
  v_total numeric(10,2);
  v_order_id uuid;
  v_order_number text;
begin
  if p_items is null or jsonb_array_length(p_items) = 0 then
    raise exception 'O pedido precisa ter pelo menos um item.';
  end if;

  -- 1ª passada: valida cada item (existe, disponível, estoque suficiente)
  -- e soma o subtotal usando o preço ATUAL do banco (nunca o do cliente).
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product from products where id = (v_item->>'product_id');
    if not found then
      raise exception 'Produto % não encontrado.', (v_item->>'product_id');
    end if;

    if v_product.available = false then
      raise exception 'Produto "%" está indisponível no momento.', v_product.name;
    end if;

    v_qty := (v_item->>'quantity')::integer;
    if v_qty is null or v_qty <= 0 then
      raise exception 'Quantidade inválida para o produto "%".', v_product.name;
    end if;

    if v_product.track_stock and v_product.stock_quantity < v_qty then
      raise exception 'Estoque insuficiente para "%": disponível %, solicitado %.',
        v_product.name, v_product.stock_quantity, v_qty;
    end if;

    v_unit_price := coalesce(v_product.sale_price, v_product.price);
    v_subtotal := v_subtotal + (v_unit_price * v_qty);
  end loop;

  v_total := v_subtotal - coalesce(p_discount, 0) + coalesce(p_shipping, 0);
  if v_total < 0 then
    v_total := 0;
  end if;

  -- Cria o pedido
  insert into orders (customer_id, subtotal, discount, shipping, total, shipping_address, customer_snapshot)
  values (p_customer_id, v_subtotal, coalesce(p_discount, 0), coalesce(p_shipping, 0), v_total, p_shipping_address, p_customer_snapshot)
  returning id, order_number into v_order_id, v_order_number;

  -- 2ª passada: cria os itens e dá baixa no estoque
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product from products where id = (v_item->>'product_id');
    v_qty := (v_item->>'quantity')::integer;
    v_unit_price := coalesce(v_product.sale_price, v_product.price);

    insert into order_items (order_id, product_id, product_name, unit_price, quantity, subtotal)
    values (v_order_id, v_product.id, v_product.name, v_unit_price, v_qty, v_unit_price * v_qty);

    if v_product.track_stock then
      update products set stock_quantity = stock_quantity - v_qty where id = v_product.id;
    end if;
  end loop;

  -- Cria o registro de pagamento inicial (modo mock/teste — ver
  -- netlify/functions/payment-mock-confirm.js)
  insert into payments (order_id, customer_id, provider, amount, status, method)
  values (v_order_id, p_customer_id, 'mock', v_total, 'pending', p_payment_method);

  -- Primeiro registro de histórico
  insert into order_status_history (order_id, status, note)
  values (v_order_id, 'aguardando_pagamento', 'Pedido criado.');

  return query select v_order_id, v_order_number;
end;
$$;

comment on function sm_create_order is
  'Cria um pedido completo (order + order_items + payment inicial + baixa de estoque) em uma transação atômica. Chamada exclusivamente pela Netlify Function checkout-create-order.js. Não deve ser exposta diretamente ao cliente sem validação de autenticação antes.';

-- ============================================================================
-- FIM DA MIGRATION DO MÓDULO 4
-- ============================================================================
