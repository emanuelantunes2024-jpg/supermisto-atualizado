-- ============================================================================
-- SUPERMISTO — supabase/migrations/005_modulo7.sql  (MÓDULO 7)
-- ============================================================================
-- Rode DEPOIS de 001 (schema.sql), seed-data.sql, 002, 003 e
-- 004_modulo6.sql.
--
-- 100% ADITIVO — não apaga produtos/categorias/pedidos/clientes/admins/
-- vendedores, não recria nada que já existe. Seguro rodar mais de uma vez.
--
-- O que este arquivo faz:
--   1. Split de pagamento: cada vendedor pode conectar a própria conta do
--      Mercado Pago (OAuth). Quando conectado, o checkout de um pedido com
--      produtos daquele vendedor divide o pagamento automaticamente —
--      quando não conectado, continua funcionando exatamente como no
--      Módulo 5/6 (tudo cai na conta principal da loja).
--   2. Notificações push: tabela para guardar as "inscrições" de push do
--      navegador de cada usuário (cliente, vendedor ou admin) — usada
--      pela PWA para avisar sobre mudança de status de pedido/nova venda.
-- ============================================================================


-- ============================================================================
-- 1. SPLIT DE PAGAMENTO — conexão da conta Mercado Pago do vendedor
-- ============================================================================
alter table seller_profiles add column if not exists mp_user_id text;
alter table seller_profiles add column if not exists mp_access_token text;
alter table seller_profiles add column if not exists mp_refresh_token text;
alter table seller_profiles add column if not exists mp_connected_at timestamptz;

comment on column seller_profiles.mp_user_id is
  'ID da conta Mercado Pago do vendedor, obtido via OAuth (seller-connect-mercadopago.js). NULL = vendedor não conectou conta própria; os produtos dele continuam vendendo normalmente, só sem split automático de pagamento.';
comment on column seller_profiles.mp_access_token is
  'Token de acesso OAuth do vendedor no Mercado Pago. Sensível — nunca é lido pelo navegador do vendedor nem de ninguém: só a Netlify Function payment-create-preference.js usa isso, com a service_role key, para montar o split de pagamento.';

-- Nenhuma policy nova de SELECT para estas colunas sensíveis: a policy de
-- leitura já existente (seller_profiles_self_or_admin_read, Módulo 6)
-- permite ao próprio vendedor e a administradores ler a própria linha —
-- o token fica visível para o dono da conta e para quem já é admin, o que
-- é aceitável (o vendedor já é dono desse token; um admin já tem acesso
-- total à conta Mercado Pago da própria loja de qualquer forma). Não é
-- exposto ao público nem a outros vendedores/clientes.


-- ============================================================================
-- 2. PUSH_SUBSCRIPTIONS — notificações push do navegador (PWA)
-- ============================================================================
create table if not exists push_subscriptions (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  endpoint    text not null,
  keys        jsonb not null,       -- {p256dh, auth} — chaves públicas da inscrição (não secretas)
  user_agent  text default '',
  created_at  timestamptz not null default now(),
  unique (user_id, endpoint)
);

create index if not exists idx_push_subscriptions_user on push_subscriptions(user_id);

alter table push_subscriptions enable row level security;

-- Cada usuário (cliente, vendedor ou admin — todos são "auth.users")
-- gerencia só as próprias inscrições.
drop policy if exists push_subscriptions_own on push_subscriptions;
create policy push_subscriptions_own on push_subscriptions
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

comment on table push_subscriptions is
  'Inscrições de notificação push do navegador (Web Push API), usadas pela PWA. Uma linha por combinação usuário+dispositivo/navegador. As chaves aqui são públicas por natureza (é assim que Web Push funciona) — o segredo real (VAPID private key) fica só em variável de ambiente no Netlify, nunca no banco.';

-- ============================================================================
-- FIM DA MIGRATION DO MÓDULO 7
-- ============================================================================
