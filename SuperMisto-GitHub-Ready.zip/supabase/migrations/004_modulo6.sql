-- ============================================================================
-- SUPERMISTO — supabase/migrations/004_modulo6.sql  (MÓDULO 6)
-- ============================================================================
-- Rode DEPOIS de 001 (schema.sql), seed-data.sql, 002_modulo4_vendas.sql e
-- 003_modulo5.sql.
--
-- 100% ADITIVO — não apaga produtos/categorias/pedidos/clientes/admins,
-- não recria nada que já existe. Seguro rodar mais de uma vez.
--
-- O que este arquivo faz:
--   1. Marketplace: vendedores (seller_profiles), produtos vinculados a um
--      vendedor (products.seller_id, opcional — null = produto da própria
--      loja SuperMisto, como os 48 produtos originais), e o "recorte" de
--      qual vendedor forneceu cada item vendido (order_items.seller_id).
--   2. Preparação para nota fiscal real (nenhuma coluna nova necessária —
--      fiscal_documents e company_fiscal_info já existiam desde o Módulo 4;
--      a integração real mora nas Netlify Functions fiscal-emit-nfe.js e
--      fiscal-check-status.js).
-- ============================================================================


-- ============================================================================
-- 1. SELLER_PROFILES (vendedores do marketplace)
-- ============================================================================
-- Um vendedor é um usuário do Supabase Auth (mesma tecnologia usada para
-- administradores e clientes), mas em uma tabela própria — um vendedor
-- NUNCA aparece em admin_profiles nem em customers, então sm_is_admin() e
-- sm_is_owner() continuam sempre false para ele (não ganha nenhum acesso
-- administrativo por engano).
create table if not exists seller_profiles (
  id                uuid primary key references auth.users(id) on delete cascade,
  store_name        text not null default '',
  email             text not null,
  phone             text default '',
  commission_rate   numeric(5,2) not null default 15.00 check (commission_rate >= 0 and commission_rate <= 100),
  status            text not null default 'pending' check (status in ('pending', 'active', 'suspended')),
  payout_info       jsonb default '{}',   -- dados de repasse (ex.: chave Pix) — preenchido pelo próprio vendedor
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

drop trigger if exists trg_seller_profiles_updated_at on seller_profiles;
create trigger trg_seller_profiles_updated_at
  before update on seller_profiles
  for each row execute function sm_set_updated_at();

alter table seller_profiles enable row level security;

create or replace function sm_is_seller()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from seller_profiles where id = auth.uid() and status = 'active'
  );
$$;

comment on function sm_is_seller() is
  'Retorna true só para vendedores com status = active. Usado nas políticas RLS que permitem um vendedor gerenciar os próprios produtos.';

-- O próprio vendedor vê e atualiza seu perfil; administradores veem/gerenciam todos.
drop policy if exists seller_profiles_self_or_admin_read on seller_profiles;
create policy seller_profiles_self_or_admin_read on seller_profiles
  for select using (auth.uid() = id or sm_is_admin());

drop policy if exists seller_profiles_self_update on seller_profiles;
create policy seller_profiles_self_update on seller_profiles
  for update using (auth.uid() = id or sm_is_owner())
  with check (auth.uid() = id or sm_is_owner());
-- Sem policy de INSERT para authenticated/anon: a conta de vendedor só é
-- criada pela Netlify Function seller-create.js (owner-only), do mesmo
-- jeito que administradores só são criados por admin-create-user.js.


-- ============================================================================
-- 2. PRODUTOS — vínculo opcional com um vendedor
-- ============================================================================
alter table products add column if not exists seller_id uuid references seller_profiles(id) on delete set null;

create index if not exists idx_products_seller on products(seller_id) where seller_id is not null;

comment on column products.seller_id is
  'Vendedor do marketplace dono deste produto. NULL = produto da própria loja SuperMisto (todos os 48 produtos originais continuam assim).';

-- Um vendedor ativo pode gerenciar (inserir/editar/excluir) SÓ os produtos
-- que já são dele (seller_id = auth.uid()) — nunca produtos de outro
-- vendedor nem produtos da loja (seller_id null). A política de admin
-- (products_admin_write, do Módulo 3) continua valendo em paralelo, sem
-- mudanças — administradores continuam podendo mexer em qualquer produto.
drop policy if exists products_seller_write on products;
create policy products_seller_write on products
  for all using (sm_is_seller() and seller_id = auth.uid())
  with check (sm_is_seller() and seller_id = auth.uid());

-- Vendedores ativos também precisam conseguir enviar fotos dos próprios
-- produtos para o bucket "products" do Storage — as políticas de Storage
-- da Etapa 3 só liberavam isso para sm_is_admin(). Sem esta política, um
-- vendedor conseguiria criar o produto mas nunca conseguiria subir uma
-- imagem para ele.
drop policy if exists sm_storage_seller_write on storage.objects;
create policy sm_storage_seller_write on storage.objects
  for insert with check (bucket_id = 'products' and sm_is_seller());


-- ============================================================================
-- 3. ORDER_ITEMS — snapshot de qual vendedor forneceu o item
-- ============================================================================
alter table order_items add column if not exists seller_id uuid references seller_profiles(id);

comment on column order_items.seller_id is
  'Snapshot de products.seller_id no momento da compra (preenchido por sm_create_order). NULL = item vendido pela própria loja.';

-- Um vendedor consegue ver os itens vendidos que são dele (para
-- acompanhar as próprias vendas), além do que já era permitido
-- (cliente dono do pedido e administradores).
drop policy if exists order_items_via_order on order_items;
create policy order_items_via_order on order_items
  for select using (
    (seller_id is not null and seller_id = auth.uid())
    or exists (
      select 1 from orders o
      where o.id = order_items.order_id
        and (o.customer_id = auth.uid() or sm_is_admin())
    )
  );


-- ============================================================================
-- 4. sm_create_order() — atualizada para registrar o vendedor de cada item
-- ============================================================================
-- Mesma lógica da versão do Módulo 4 (validação de estoque/preço, criação
-- atômica), só acrescentando o snapshot de seller_id em order_items.
create or replace function sm_create_order(
  p_customer_id uuid,
  p_items jsonb,
  p_shipping_address jsonb,
  p_customer_snapshot jsonb,
  p_shipping numeric default 0,
  p_discount numeric default 0,
  p_payment_method text default 'pix'
)
returns table (order_id uuid, order_number text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item jsonb;
  v_product products%rowtype;
  v_qty integer;
  v_unit_price numeric(10,2);
  v_subtotal numeric(10,2) := 0;
  v_total numeric(10,2);
  v_order_id uuid;
  v_order_number text;
begin
  if p_items is null or jsonb_array_length(p_items) = 0 then
    raise exception 'O pedido precisa ter pelo menos um item.';
  end if;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product from products where id = (v_item->>'product_id');
    if not found then
      raise exception 'Produto % não encontrado.', (v_item->>'product_id');
    end if;

    if v_product.available = false then
      raise exception 'Produto "%" está indisponível no momento.', v_product.name;
    end if;

    v_qty := (v_item->>'quantity')::integer;
    if v_qty is null or v_qty <= 0 then
      raise exception 'Quantidade inválida para o produto "%".', v_product.name;
    end if;

    if v_product.track_stock and v_product.stock_quantity < v_qty then
      raise exception 'Estoque insuficiente para "%": disponível %, solicitado %.',
        v_product.name, v_product.stock_quantity, v_qty;
    end if;

    v_unit_price := coalesce(v_product.sale_price, v_product.price);
    v_subtotal := v_subtotal + (v_unit_price * v_qty);
  end loop;

  v_total := v_subtotal - coalesce(p_discount, 0) + coalesce(p_shipping, 0);
  if v_total < 0 then
    v_total := 0;
  end if;

  insert into orders (customer_id, subtotal, discount, shipping, total, shipping_address, customer_snapshot)
  values (p_customer_id, v_subtotal, coalesce(p_discount, 0), coalesce(p_shipping, 0), v_total, p_shipping_address, p_customer_snapshot)
  returning id, order_number into v_order_id, v_order_number;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product from products where id = (v_item->>'product_id');
    v_qty := (v_item->>'quantity')::integer;
    v_unit_price := coalesce(v_product.sale_price, v_product.price);

    insert into order_items (order_id, product_id, product_name, unit_price, quantity, subtotal, seller_id)
    values (v_order_id, v_product.id, v_product.name, v_unit_price, v_qty, v_unit_price * v_qty, v_product.seller_id);

    if v_product.track_stock then
      update products set stock_quantity = stock_quantity - v_qty where id = v_product.id;
    end if;
  end loop;

  insert into payments (order_id, customer_id, provider, amount, status, method)
  values (v_order_id, p_customer_id, 'mock', v_total, 'pending', p_payment_method);

  insert into order_status_history (order_id, status, note)
  values (v_order_id, 'aguardando_pagamento', 'Pedido criado.');

  return query select v_order_id, v_order_number;
end;
$$;

comment on function sm_create_order is
  'Cria um pedido completo (order + order_items com snapshot de vendedor + payment inicial + baixa de estoque) em uma transação atômica. Chamada exclusivamente pela Netlify Function checkout-create-order.js.';

-- ============================================================================
-- FIM DA MIGRATION DO MÓDULO 6
-- ============================================================================
