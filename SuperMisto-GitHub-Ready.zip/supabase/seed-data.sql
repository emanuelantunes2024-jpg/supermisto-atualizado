-- ============================================================================
-- SUPERMISTO — supabase/seed-data.sql (ETAPA 3)
-- ============================================================================
-- GERADO AUTOMATICAMENTE a partir de assets/js/products.js (dados originais
-- da Etapa 1/2). Rode DEPOIS de supabase/schema.sql, uma única vez, no SQL
-- Editor do Supabase.
--
-- SEGURO RODAR MAIS DE UMA VEZ: usa ON CONFLICT (chave primária) DO UPDATE,
-- ou seja, nunca cria produto/categoria duplicado — se já existir, só
-- atualiza os dados para bater com este arquivo.
--
-- Total: 8 categorias, 48 produtos.
-- ============================================================================

-- ---- CATEGORIAS ----

insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('temperos', 'Temperos', '🌿', 'Sabor no dia a dia', '#F0E4F7', '#3A1150', true, 0)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('conservas', 'Conservas', '🫙', 'Tradição em conserva', '#F3ECE1', '#7E2E1F', true, 1)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('pimentas', 'Pimentas', '🌶️', 'Para quem gosta de picar', '#FBEAE6', '#A6402C', true, 2)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('molhos', 'Molhos', '🥫', 'Molhos selecionados', '#F0E4F7', '#6B2F91', true, 3)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('ervas', 'Ervas e Especiarias', '🍃', 'Direto do campo', '#E9F1E7', '#4B7A4E', true, 4)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('kits', 'Kits', '📦', 'Combinações prontas', '#FBF1DF', '#B7883C', true, 5)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('chas', 'Chás', '☕', 'Momentos de pausa', '#E9F1E7', '#4B7A4E', true, 6)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('outros', 'Outros produtos', '⭐', 'Novidades da SuperMisto', '#F0E4F7', '#3A1150', true, 7)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;

-- ---- PRODUTOS ----

insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('alho-desidratado', 'Alho Desidratado', 'temperos', 9.9, '100g', 'Alho selecionado, moído na hora certa.', 'Alho desidratado e moído, ideal para temperar carnes, molhos, arroz e legumes. Prático para o dia a dia, sem perder o sabor marcante do alho fresco.', '🧄', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cebola-desidratada', 'Cebola Desidratada', 'temperos', 8.9, '100g', 'Cebola em flocos, sabor concentrado.', 'Cebola desidratada em flocos, perfeita para dar sabor e aroma a molhos, sopas, carnes e receitas assadas.', '🧅', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cebola-roxa-desidratada', 'Cebola Roxa Desidratada', 'temperos', 10.9, '100g', 'Toque adocicado e cor marcante.', 'Cebola roxa desidratada, com sabor levemente adocicado. Ótima em saladas, molhos frios e pratos que pedem um toque especial.', '🧅', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cominho-em-grao', 'Cominho em Grão', 'temperos', 11.9, '80g', 'Aroma marcante para pratos especiais.', 'Cominho em grão selecionado, ideal para temperar carnes, feijão, arroz e receitas com influência árabe e mexicana.', '🌰', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cominho-em-po', 'Cominho em Pó', 'temperos', 10.9, '80g', 'Prático, moído na medida certa.', 'Cominho moído, pronto para usar. Sabor terroso e aromático, essencial em diversas receitas do dia a dia.', '🌰', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimenta-do-reino', 'Pimenta-do-Reino Moída', 'temperos', 12.9, '60g', 'O clássico que não pode faltar.', 'Pimenta-do-reino moída na hora, com aroma intenso e picância equilibrada. Indispensável na cozinha brasileira.', '⚫', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('oregano', 'Orégano Selecionado', 'temperos', 7.9, '50g', 'Perfeito para massas e pizzas.', 'Orégano selecionado e seco naturalmente, com aroma intenso. Combina com massas, pizzas, saladas e molhos.', '🌿', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('chimichurri', 'Chimichurri SuperMisto', 'temperos', 14.9, '80g', 'Blend pronto para churrasco.', 'Mistura de ervas e temperos no estilo chimichurri, pronta para uso em carnes grelhadas e churrascos.', '🌶️', true, false, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('colorau', 'Colorau', 'temperos', 8.5, '100g', 'Cor e sabor tradicionais.', 'Colorau tradicional, usado para dar cor e um sabor suave a arroz, feijão, carnes e ensopados.', '🟠', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('curcuma', 'Cúrcuma (Açafrão-da-Terra)', 'temperos', 11.5, '80g', 'Cor dourada e toque especial.', 'Cúrcuma moída, também conhecida como açafrão-da-terra. Dá cor dourada e sabor suave a arroz, carnes e sopas.', '🟡', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('lemon-pepper', 'Lemon Pepper', 'temperos', 13.9, '80g', 'Cítrico e apimentado.', 'Blend de pimenta com raspas de limão, ideal para frango, peixes e carnes grelhadas.', '🍋', true, true, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pepino-conserva', 'Pepino em Conserva', 'conservas', 15.9, '300g', 'Crocante e equilibrado.', 'Pepinos selecionados, em conserva no ponto certo de acidez e crocância. Ótimo para sanduíches e petiscos.', '🥒', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cenoura-conserva', 'Cenoura em Conserva', 'conservas', 13.9, '300g', 'Clássico da mesa brasileira.', 'Cenoura em conserva, cortada e temperada, pronta para acompanhar refeições ou compor petiscos.', '🥕', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('batatinha-conserva', 'Batatinha em Conserva', 'conservas', 14.9, '300g', 'Pequenas, saborosas, práticas.', 'Batatinhas em conserva, prontas para salpicões, saladas e petiscos do dia a dia.', '🥔', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('alho-conserva', 'Alho em Conserva', 'conservas', 16.9, '250g', 'Sabor suave e prático de usar.', 'Dentes de alho em conserva, com sabor mais suave que o alho fresco. Prático para usar direto na receita.', '🧄', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cebola-conserva', 'Cebola em Conserva', 'conservas', 13.5, '250g', 'Toque ácido e crocante.', 'Cebola em conserva, ideal para saladas, sanduíches e pratos que pedem um toque ácido.', '🧅', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimentas-conserva', 'Pimentas em Conserva', 'conservas', 17.9, '250g', 'Picância na medida.', 'Seleção de pimentas em conserva, para quem gosta de dar um toque picante às refeições.', '🌶️', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('beterraba-conserva', 'Beterraba em Conserva', 'conservas', 14.5, '300g', 'Cor viva, sabor adocicado.', 'Beterraba em conserva, com sabor levemente adocicado. Ótima para saladas e acompanhamentos.', '🔴', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('mix-legumes-conserva', 'Mix de Legumes em Conserva', 'conservas', 16.9, '300g', 'Praticidade em um único vidro.', 'Mix de legumes selecionados em conserva, prático para completar refeições e saladas.', '🥗', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('azeitonas', 'Azeitonas Selecionadas', 'conservas', 18.9, '250g', 'Clássicas em qualquer ocasião.', 'Azeitonas selecionadas, ideais para petiscos, saladas e receitas do dia a dia.', '🫒', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cogumelos-conserva', 'Cogumelos em Conserva', 'conservas', 19.9, '250g', 'Textura e sabor especiais.', 'Cogumelos em conserva, prontos para saladas, molhos e pratos quentes.', '🍄', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('milho-conserva', 'Milho em Conserva', 'conservas', 9.9, '300g', 'Doce e versátil.', 'Milho em conserva, prático para saladas, pipoca gourmet, tortas e acompanhamentos.', '🌽', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('tomate-seco', 'Tomate Seco', 'conservas', 22.9, '200g', 'Sabor concentrado e intenso.', 'Tomate seco em azeite, com sabor concentrado. Ótimo em antepastos, massas, saladas e petiscos.', '🍅', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('antepasto-supermisto', 'Antepasto SuperMisto', 'conservas', 21.9, '250g', 'Combinação pronta para servir.', 'Antepasto com seleção de legumes e temperos, pronto para servir com torradas e pães.', '🫙', true, false, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('molho-pimenta-tradicional', 'Molho de Pimenta Tradicional', 'molhos', 15.9, '150ml', 'Picância clássica e equilibrada.', 'Molho de pimenta no estilo tradicional, com picância equilibrada para acompanhar carnes, feijão e petiscos.', '🥫', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('molho-pimenta-defumado', 'Molho de Pimenta Defumado', 'molhos', 17.9, '150ml', 'Toque defumado marcante.', 'Molho de pimenta com toque defumado, ideal para churrascos e carnes grelhadas.', '🥫', true, false, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('molho-barbecue', 'Molho Barbecue SuperMisto', 'molhos', 16.9, '200ml', 'Doce, defumado e encorpado.', 'Molho barbecue encorpado, com equilíbrio entre doce e defumado. Combina com carnes, frango e sanduíches.', '🥫', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimenta-biquinho', 'Pimenta Biquinho', 'pimentas', 18.9, '200g', 'Docinha e levemente picante.', 'Pimenta biquinho em conserva, com sabor adocicado e leve picância. Ótima para petiscos e taças de recepção.', '🌶️', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimenta-dedo-de-moca', 'Pimenta Dedo-de-Moça', 'pimentas', 17.9, '200g', 'Picância marcante e aromática.', 'Pimenta dedo-de-moça selecionada, ideal para molhos, refogados e pratos que pedem mais ardência.', '🌶️', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimenta-malagueta', 'Pimenta Malagueta', 'pimentas', 16.9, '150g', 'Para quem gosta de sentir o ardor.', 'Pimenta malagueta em conserva, bem picante, tradicional na culinária brasileira.', '🌶️', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('manjericao-seco', 'Manjericão Seco', 'ervas', 8.9, '30g', 'Aroma fresco para molhos.', 'Manjericão seco, com aroma marcante, ideal para molhos de tomate, massas e pizzas.', '🌱', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('louro-folha', 'Folha de Louro', 'ervas', 7.5, '20g', 'Essencial em caldos e feijão.', 'Folhas de louro selecionadas, usadas para aromatizar caldos, feijão, carnes e ensopados.', '🍃', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('salsa-desidratada', 'Salsa Desidratada', 'ervas', 7.9, '30g', 'Frescor em qualquer prato.', 'Salsa desidratada, prática para finalizar pratos com frescor e cor.', '🌿', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('alecrim', 'Alecrim Seco', 'ervas', 9.5, '30g', 'Perfume marcante e rústico.', 'Alecrim seco, com aroma intenso, ótimo para carnes assadas, batatas e pães.', '🌿', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('kit-churrasco', 'Kit Churrasco SuperMisto', 'kits', 49.9, 'Kit com 4 itens', 'Tudo para o churrasco perfeito.', 'Kit com sal grosso temperado, chimichurri, pimenta-do-reino e molho barbecue — tudo o que você precisa para um churrasco completo.', '📦', true, true, false, true, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('kit-temperos-basicos', 'Kit Temperos Básicos', 'kits', 34.9, 'Kit com 5 itens', 'Os essenciais da cozinha.', 'Kit com alho, cebola, cominho, orégano e pimenta-do-reino — a base para o dia a dia na cozinha.', '📦', true, true, false, true, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('kit-conservas-selecionadas', 'Kit Conservas Selecionadas', 'kits', 44.9, 'Kit com 3 itens', 'Trio pronto para petiscar.', 'Kit com pepino, azeitonas e tomate seco — combinação pronta para receber visitas ou petiscar em casa.', '📦', true, false, true, true, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-camomila', 'Chá de Camomila', 'chas', 12.9, '50g', 'Clássico para relaxar.', 'Flores de camomila selecionadas, ideais para um chá calmante ao final do dia.', '🌼', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-erva-doce', 'Chá de Erva-Doce', 'chas', 11.9, '50g', 'Sabor suave e adocicado.', 'Erva-doce selecionada, com sabor suave, tradicional após as refeições.', '🌿', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-hortela', 'Chá de Hortelã', 'chas', 11.9, '40g', 'Refrescante em qualquer hora.', 'Folhas de hortelã selecionadas, para um chá refrescante, quente ou gelado.', '🌱', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-capim-cidreira', 'Chá de Capim-Cidreira', 'chas', 10.9, '40g', 'Aroma cítrico e suave.', 'Capim-cidreira selecionado, ideal para um chá calmante com toque cítrico.', '🌾', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-hibisco', 'Chá de Hibisco', 'chas', 13.9, '50g', 'Cor viva, sabor marcante.', 'Flores de hibisco selecionadas, para um chá de cor vibrante e sabor levemente ácido.', '🌺', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-boldo', 'Chá de Boldo', 'chas', 10.9, '40g', 'Tradicional depois das refeições.', 'Folhas de boldo selecionadas, tradicionalmente usadas após refeições mais pesadas.', '🍃', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-verde', 'Chá Verde', 'chas', 14.9, '50g', 'Leve e equilibrado.', 'Chá verde selecionado, com sabor leve e equilibrado para o dia a dia.', '🍵', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-preto', 'Chá Preto', 'chas', 13.9, '50g', 'Encorpado e aromático.', 'Chá preto selecionado, encorpado e aromático, ótimo puro ou com leite.', '🍵', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-maca-canela', 'Chá de Maçã com Canela', 'chas', 14.9, '50g', 'Aconchegante e adocicado.', 'Blend de maçã com canela, para um chá aconchegante e aromático.', '🍎', true, true, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-morango', 'Chá de Morango', 'chas', 14.9, '50g', 'Doce e perfumado.', 'Blend saborizado de morango, para um chá doce e perfumado.', '🍓', true, false, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-maracuja', 'Chá de Maracujá', 'chas', 14.9, '50g', 'Calmante e saboroso.', 'Blend saborizado de maracujá, conhecido por seu efeito calmante e sabor agradável.', '🧡', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;

-- ============================================================================
-- FIM DA MIGRAÇÃO. Confira no painel do Supabase (Table Editor) que
-- "categories" tem 8 linhas e "products" tem 48 linhas.
-- ============================================================================
