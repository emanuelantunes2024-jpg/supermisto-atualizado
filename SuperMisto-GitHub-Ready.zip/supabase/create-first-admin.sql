-- ============================================================================
-- SUPERMISTO — supabase/create-first-admin.sql (ETAPA 3)
-- ============================================================================
-- Este arquivo NÃO cria a senha (isso é feito pelo próprio Supabase, com
-- hash seguro). Ele só liga o usuário que você criar no painel do Supabase
-- à tabela admin_profiles, para que o painel /admin reconheça essa pessoa
-- como administrador.
--
-- PASSO A PASSO:
--
-- 1. No painel do Supabase, vá em "Authentication" → "Users" → "Add user"
--    (ou "Invite user", se preferir que a pessoa defina a própria senha
--    por e-mail). Preencha e-mail e senha do primeiro administrador.
--
-- 2. Copie o "User UID" (um código tipo
--    "3fa85f64-5717-4562-b3fc-2c963f66afa6") que aparece na lista de
--    usuários depois de criado.
--
-- 3. Cole esse UID no lugar de SEU_USER_UID_AQUI abaixo, ajuste o e-mail
--    para bater com o que você cadastrou, e rode este comando no SQL Editor:

insert into admin_profiles (id, email, full_name, role)
values (
  'SEU_USER_UID_AQUI',              -- substitua pelo User UID copiado no passo 2
  'admin@supermisto.com.br',        -- substitua pelo e-mail cadastrado no passo 1
  'Administrador SuperMisto',       -- nome de exibição (pode editar depois)
  'owner'                           -- primeiro administrador = acesso total (ver PROJETO.md, seção 17.3)
)
on conflict (id) do update set
  email = excluded.email,
  full_name = excluded.full_name;

-- 4. Pronto. Esse e-mail/senha já pode ser usado para entrar em /admin.
--
-- Para criar administradores adicionais DEPOIS que o site já estiver no ar,
-- use a tela "Administradores" dentro do próprio painel /admin — ela chama
-- a Netlify Function netlify/functions/admin-create-user.js, que faz esses
-- mesmos dois passos (criar o usuário + linkar o perfil) automaticamente,
-- sem precisar voltar aqui no SQL Editor.
-- ============================================================================
