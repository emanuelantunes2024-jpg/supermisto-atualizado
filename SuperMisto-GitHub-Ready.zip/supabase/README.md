# SuperMisto — Configurando o backend (Supabase) — Etapas 3, 4 e 5

Este guia leva o projeto do estado "código pronto, backend desligado" para
"site público, painel, carrinho, checkout e pagamento funcionando com
banco de dados real". Leva uns 20-25 minutos na primeira vez. Não precisa
saber programar para seguir os passos.

---

## Passo 1 — Criar o projeto no Supabase (gratuito)

1. Acesse [supabase.com](https://supabase.com) e crie uma conta (dá para
   usar login do GitHub/Google).
2. Clique em **"New project"**.
3. Escolha um nome (ex: `supermisto`), uma senha forte para o banco (guarde
   em um lugar seguro — é diferente da senha de administrador do site) e a
   região mais próxima do Brasil disponível (ex: São Paulo, se houver, ou a
   mais próxima).
4. Aguarde alguns minutos até o projeto ficar pronto ("Project is ready").

## Passo 2 — Rodar o schema do banco

1. No menu lateral do seu projeto Supabase, vá em **"SQL Editor"**.
2. Clique em **"New query"**.
3. Abra o arquivo `supabase/schema.sql` deste projeto, copie o conteúdo
   inteiro, cole no editor e clique em **"Run"**.
4. Confira que não apareceu nenhum erro vermelho (avisos amarelos são
   normais). Isso cria as tabelas, os buckets de imagem e as regras de
   segurança.

## Passo 3 — Migrar os 48 produtos e 8 categorias originais

1. Ainda no SQL Editor, abra uma nova query.
2. Copie o conteúdo de `supabase/seed-data.sql`, cole e clique em **"Run"**.
3. Vá em **"Table Editor"** (menu lateral) → tabela `products` → confira que
   apareceram 48 linhas. Confira também a tabela `categories` (8 linhas).

Esse script é seguro de rodar mais de uma vez — ele nunca duplica produtos
ou categorias (usa `ON CONFLICT ... DO UPDATE`).

## Passo 3b — Rodar as migrations dos Módulos 4, 5, 6 e 7

1. No SQL Editor, abra uma nova query, cole o conteúdo de
   `supabase/migrations/002_modulo4_vendas.sql` e clique em **"Run"**. Isso
   cria estoque, carrinho/pedidos/clientes/pagamentos/nota fiscal (a base
   da plataforma de vendas).
2. Repita com `supabase/migrations/003_modulo5.sql`. Isso adiciona papéis
   de administrador (owner/editor), histórico automático de alterações e
   mensagens de contato.
3. Repita com `supabase/migrations/004_modulo6.sql`. Isso adiciona o
   marketplace de vendedores (`seller_profiles`, produtos vinculados a um
   vendedor) e corrige uma política de Storage necessária para vendedores
   conseguirem enviar fotos de produto.
4. Repita com `supabase/migrations/005_modulo7.sql`. Isso adiciona as
   colunas de conexão OAuth do vendedor com o Mercado Pago (split de
   pagamento) e a tabela de inscrições de notificação push.

Todos os arquivos são seguros de rodar mais de uma vez e não apagam nada
que já existe.

## Passo 4 — Criar o primeiro administrador

1. No menu lateral, vá em **"Authentication" → "Users" → "Add user"**.
2. Preencha um e-mail e uma senha para o administrador (essa é a senha real
   de acesso ao painel `/admin` — bem diferente daquela senha de
   demonstração da Etapa 2, que foi removida do projeto).
3. Depois de criado, copie o **"User UID"** que aparece na lista.
4. Abra `supabase/create-first-admin.sql`, siga as instruções dentro do
   arquivo (colar o UID e o e-mail) e rode no SQL Editor.

Pronto — esse e-mail e senha já podem ser usados para entrar em `/admin`.

## Passo 5 — Copiar as chaves da API

1. No menu lateral, vá em **"Project Settings" → "API"**.
2. Copie o **"Project URL"** (algo como `https://xxxxxxxx.supabase.co`).
3. Copie a chave **"anon public"** (uma chave longa, começa com `eyJ...`).
4. Abra `assets/js/supabase-config.js` neste projeto e cole os dois valores:
   ```js
   window.SUPABASE_URL = "https://xxxxxxxx.supabase.co";
   window.SUPABASE_ANON_KEY = "eyJ....................";
   ```
5. **NÃO copie a chave "service_role"** para esse arquivo — ela é secreta e
   vai só no Netlify (próximo passo).

## Passo 5b — Configurar as URLs de redirecionamento (obrigatório para "Esqueci minha senha" funcionar)

Sem este passo, o e-mail de recuperação de senha é enviado normalmente,
mas o link pode não abrir a tela certa (o site tem uma proteção para esse
caso — ver `PROJETO.md`, seção 20.6 — mas o ideal é configurar certo aqui
mesmo assim).

1. No painel do Supabase, vá em **"Authentication" → "URL Configuration"**.
2. Em **"Site URL"**, cole a URL real do seu site publicado no Netlify
   (ex.: `https://supermisto.netlify.app`) — nunca deixe como
   `http://localhost:3000` ou qualquer URL de desenvolvimento.
3. Em **"Redirect URLs"**, adicione:
   `https://SEU-SITE.netlify.app/reset-password.html`
   (troque pela URL real do seu site).
4. Salve. Repita sempre que trocar de domínio (ex.: ao configurar um
   domínio próprio no lugar do `.netlify.app`).

## Passo 6 — Configurar as Netlify Functions (criar administradores, checkout, pagamentos)

1. Ainda em "Project Settings" → "API" do Supabase, copie também a chave
   **"service_role"** (secreta — trate como uma senha).
2. No painel do Netlify, vá no seu site → **"Site configuration" →
   "Environment variables"** → **"Add a variable"** e crie duas:
   - `SUPABASE_URL` → o mesmo Project URL do passo 5.
   - `SUPABASE_SERVICE_ROLE_KEY` → a chave service_role que você acabou de
     copiar.
3. Faça um novo deploy do site (qualquer novo publish já aplica as
   variáveis). Isso ativa a tela **Configurações → Administradores** do
   painel, que permite criar mais administradores sem voltar ao SQL Editor.

## Passo 7 — Publicar no Netlify

Se o site ainda não estiver publicado: suba a pasta `supermisto/` inteira
para um repositório Git e conecte no Netlify, ou arraste a pasta no painel
("Deploy manually") — igual às etapas anteriores. O arquivo `netlify.toml`
já está configurado para publicar a raiz do projeto e ativar a pasta
`netlify/functions/`.

Se o site já estiver publicado, um novo deploy é suficiente — não é preciso
mudar nenhuma configuração de build.

## Passo 8 — Testar

1. Abra o site público — o catálogo deve continuar aparecendo normalmente
   (agora vindo do banco, não mais do arquivo `products.js`).
2. Abra `/admin`, entre com o e-mail/senha criados no Passo 4.
3. Edite um produto (ex.: mude o nome ou o preço) e salve.
4. Abra o site público em **outro navegador ou outro dispositivo** — a
   alteração deve aparecer lá também. Esse é o teste definitivo de que a
   sincronização real está funcionando.
5. Adicione um produto ao carrinho, faça login como cliente (crie uma
   conta em "Minha Conta") e finalize uma compra — confira que o pedido
   aparece em `admin/pedidos.html`.

---

## Passo 9 (opcional) — Pagamento real, notificação por e-mail e nota fiscal real

Sem este passo, o projeto continua 100% funcional: o checkout usa o modo
de teste (confirmação manual pelo administrador), as mensagens de
contato ficam salvas e visíveis em `admin/mensagens.html` (só sem
notificação por e-mail), e o botão "Emitir nota fiscal" fica indisponível
com um aviso claro.

**Para pagamento real (Mercado Pago):**
1. Crie uma conta em [mercadopago.com.br/developers](https://www.mercadopago.com.br/developers) e uma aplicação.
2. Copie o "Access Token" (comece com o de teste).
3. No Netlify, adicione as variáveis `MERCADOPAGO_ACCESS_TOKEN` (o token) e `SITE_URL` (a URL pública do seu site, ex.: `https://supermisto.netlify.app`).

**Para notificação de contato por e-mail:**
1. Crie uma conta gratuita em [resend.com](https://resend.com).
2. Copie a chave de API.
3. No Netlify, adicione as variáveis `RESEND_API_KEY` (a chave) e `CONTACT_NOTIFY_EMAIL` (o e-mail da loja que deve receber os avisos).

**Para emissão real de nota fiscal (Focus NFe):**
1. Crie uma conta em [focusnfe.com.br](https://focusnfe.com.br) — comece pelo ambiente de homologação (gratuito, não emite notas que valem fiscalmente, ideal para testar).
2. Copie o token de API do ambiente de homologação.
3. No Netlify, adicione as variáveis `FOCUS_NFE_API_TOKEN` (o token) e `FOCUS_NFE_ENVIRONMENT` (`homologacao` ou, quando estiver pronto para valer, `producao`).
4. Antes de emitir qualquer nota, preencha o NCM de cada produto (formulário de produto → campos fiscais) e os dados fiscais da empresa (Configurações → Dados fiscais) — a emissão recusa com uma mensagem clara se algo estiver faltando.
5. **Confira com seu contador** a tributação usada (o payload assume Simples Nacional como ponto de partida) antes de emitir notas reais.

Detalhes completos e o que cada variável faz: `PROJETO.md`, seções 17 e 18.

---

## Passo 10 (opcional) — Ativar o marketplace de vendedores

Sem este passo, o site funciona só com os produtos da própria loja (como
sempre) — o marketplace é um recurso opcional.

1. Entre em `/admin`, vá em **Vendedores** (só visível para administradores "owner").
2. Clique em **"+ Adicionar vendedor"**, preencha os dados e uma senha provisória.
3. A conta é criada como "pendente" — clique em **"Ativar"** quando quiser liberar o vendedor.
4. Passe ao vendedor o link `/vendedor` do seu site, junto com o e-mail e senha cadastrados — ele já pode entrar e cadastrar produtos.

Nenhuma variável de ambiente extra é necessária para o marketplace — ele
usa a mesma infraestrutura (Supabase) já configurada nos passos
anteriores.

---

## Passo 11 (opcional) — PWA, notificações push e split de pagamento (Módulo 7)

Sem este passo, o site e o portal do vendedor continuam instaláveis como
PWA normalmente (isso não depende de nenhuma configuração extra) — só as
notificações push e o split de pagamento automático ficam desligados.

**Para notificações push:**
1. Na sua máquina, com Node instalado, rode: `npx web-push generate-vapid-keys`.
2. Cole a chave **pública** em `assets/js/push-config.js` (`window.VAPID_PUBLIC_KEY`).
3. No Netlify, adicione `VAPID_PRIVATE_KEY` (a chave privada) e `VAPID_CONTACT_EMAIL` (um e-mail de contato).
4. Publique de novo — os botões de "Ativar notificações" passam a aparecer em "Minha Conta" e no dashboard do vendedor.

**Para split de pagamento automático (requer Mercado Pago já configurado no Passo 9):**
1. No painel do Mercado Pago Developers, na mesma aplicação usada no Passo 9, habilite "Marketplace" e copie o **Client ID** e o **Client Secret**.
2. No Netlify, adicione `MERCADOPAGO_CLIENT_ID` e `MERCADOPAGO_CLIENT_SECRET`.
3. Publique de novo — o botão "Conectar Mercado Pago" no dashboard do vendedor passa a funcionar.
4. Lembre-se: o split só se aplica quando TODOS os itens de um pedido são de um único vendedor conectado (limitação real da API do Mercado Pago — ver `PROJETO.md`, seção 19.5).

Detalhes completos: `PROJETO.md`, seção 19.

---

## E se eu não configurar nada disso?

O site público continua funcionando normalmente, mostrando o catálogo
original da Etapa 1 (embutido em `assets/js/products.js`) — ele nunca
quebra por falta de configuração. O painel `/admin`, porém, vai mostrar uma
mensagem clara pedindo para configurar o backend antes de liberar login ou
qualquer edição, em vez de fingir que funciona.
