-- ============================================================================
-- SUPERMISTO — TUDO-EM-UM.sql
-- ============================================================================
-- Este arquivo junta TUDO que o site precisa no banco de dados: schema,
-- os 48 produtos, carrinho/pedidos, papéis de administrador, marketplace
-- de vendedores e notificações — em um ÚNICO arquivo, pra rodar de uma
-- vez só no SQL Editor do Supabase.
--
-- COMO USAR:
--   1. Crie um projeto novo no Supabase (supabase.com).
--   2. Vá em "SQL Editor" → "New query".
--   3. Copie este arquivo INTEIRO e cole na caixa.
--   4. Clique em "Run".
--   5. Pronto — todo o banco de dados está criado.
--
-- Depois disso, siga o COMECE-AQUI.md para criar seu usuário
-- administrador (isso não dá pra fazer por SQL puro — precisa ser feito
-- em Authentication → Users, é rápido).
--
-- Seguro rodar mais de uma vez (todos os comandos usam IF NOT EXISTS /
-- CREATE OR REPLACE / DROP POLICY IF EXISTS antes de criar de novo).
-- ============================================================================


-- ============================================================================
-- SUPERMISTO — supabase/schema.sql (ETAPA 3)
-- ============================================================================
-- Rode este arquivo INTEIRO uma vez no SQL Editor do seu projeto Supabase
-- (Supabase → seu projeto → SQL Editor → New query → cole tudo → Run).
--
-- Ele cria:
--   1. As tabelas do catálogo (categories, products, banners, settings)
--   2. A tabela de perfis administrativos (admin_profiles)
--   3. Triggers para manter "updated_at" sempre atualizado
--   4. RLS (Row Level Security) com as políticas de acesso público/admin
--
-- É seguro rodar mais de uma vez: todos os comandos usam
-- "IF NOT EXISTS" / "CREATE OR REPLACE" / "DROP POLICY IF EXISTS" antes de
-- criar de novo, então rodar duas vezes não quebra nada nem duplica nada.
-- ============================================================================

-- Extensão usada para gerar IDs aleatórios (uuid) em banners
create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- Função utilitária: atualiza automaticamente a coluna updated_at
-- ----------------------------------------------------------------------------
create or replace function sm_set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- ============================================================================
-- 1. CATEGORIES
-- ============================================================================
create table if not exists categories (
  slug        text primary key,
  name        text not null,
  icon        text default '⭐',
  description text default '',
  image       text,
  bg          text default '#F0E4F7',
  fg          text default '#3A1150',
  active      boolean not null default true,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

drop trigger if exists trg_categories_updated_at on categories;
create trigger trg_categories_updated_at
  before update on categories
  for each row execute function sm_set_updated_at();

-- ============================================================================
-- 2. PRODUCTS
-- ============================================================================
create table if not exists products (
  id                text primary key,
  name              text not null,
  category          text references categories(slug) on update cascade on delete set null,
  price             numeric(10,2) not null default 0,
  sale_price        numeric(10,2),
  cost_price        numeric(10,2),          -- custo interno (não aparece no site público)
  weight            text default '',
  unit              text default '',
  short_desc        text default '',
  description       text default '',
  emoji             text default '🌶️',
  image             text,
  images            text[] not null default '{}',
  available         boolean not null default true,
  featured          boolean not null default false,
  is_new            boolean not null default false,
  is_kit            boolean not null default false,
  recommended       boolean not null default false,
  buy_link          text default '#',
  whatsapp_message  text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists idx_products_category on products(category);
create index if not exists idx_products_featured on products(featured) where featured = true;

drop trigger if exists trg_products_updated_at on products;
create trigger trg_products_updated_at
  before update on products
  for each row execute function sm_set_updated_at();

-- ============================================================================
-- 3. BANNERS
-- ============================================================================
create table if not exists banners (
  id          uuid primary key default gen_random_uuid(),
  title       text default '',
  subtitle    text default '',
  button      text default '',
  link        text default '#',
  image       text,
  active      boolean not null default false,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

drop trigger if exists trg_banners_updated_at on banners;
create trigger trg_banners_updated_at
  before update on banners
  for each row execute function sm_set_updated_at();

-- ============================================================================
-- 4. SETTINGS (linha única — id sempre 1)
-- ============================================================================
create table if not exists settings (
  id                integer primary key default 1 check (id = 1),
  whatsapp          text default '5500000000000',
  whatsapp_message  text default 'Olá! Vim pelo site da SuperMisto e gostaria de saber mais sobre os produtos.',
  email             text default 'contato@supermisto.com.br',
  instagram         text default '#',
  facebook          text default '#',
  updated_at        timestamptz not null default now()
);

insert into settings (id) values (1) on conflict (id) do nothing;

drop trigger if exists trg_settings_updated_at on settings;
create trigger trg_settings_updated_at
  before update on settings
  for each row execute function sm_set_updated_at();

-- ============================================================================
-- 5. ADMIN_PROFILES
-- ============================================================================
-- Não guarda senha nenhuma aqui — a senha é gerenciada pelo Supabase Auth
-- (auth.users), com hash seguro, fora do nosso controle direto. Esta tabela
-- só guarda informações extras de cada administrador.
create table if not exists admin_profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text not null,
  full_name   text default '',
  role        text not null default 'admin',
  created_at  timestamptz not null default now()
);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================================
alter table categories     enable row level security;
alter table products       enable row level security;
alter table banners        enable row level security;
alter table settings       enable row level security;
alter table admin_profiles enable row level security;

-- ---- CATEGORIES ----
-- Leitura pública (o site público precisa ver todas para poder, por exemplo,
-- mostrar a categoria de um produto mesmo que ela esteja "inativa"; quem
-- decide o que mostrar na navegação é o próprio código do site, como já
-- acontecia na Etapa 2).
drop policy if exists categories_public_read on categories;
create policy categories_public_read on categories
  for select using (true);

-- Escrita só para quem estiver autenticado (ou seja, administradores logados
-- via Supabase Auth — não existe cadastro público de usuários neste projeto).
drop policy if exists categories_admin_write on categories;
create policy categories_admin_write on categories
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ---- PRODUCTS ----
drop policy if exists products_public_read on products;
create policy products_public_read on products
  for select using (true);

drop policy if exists products_admin_write on products;
create policy products_admin_write on products
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ---- BANNERS ----
-- O público só vê banners ativos; administradores autenticados veem todos
-- (inclusive rascunhos/inativos) para poder gerenciar.
drop policy if exists banners_public_read on banners;
create policy banners_public_read on banners
  for select using (active = true or auth.role() = 'authenticated');

drop policy if exists banners_admin_write on banners;
create policy banners_admin_write on banners
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ---- SETTINGS ----
drop policy if exists settings_public_read on settings;
create policy settings_public_read on settings
  for select using (true);

drop policy if exists settings_admin_write on settings;
create policy settings_admin_write on settings
  for update using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ---- ADMIN_PROFILES ----
-- Qualquer administrador autenticado pode ver a lista de administradores
-- (útil para uma futura tela "Usuários"). Ninguém de fora consegue ler.
drop policy if exists admin_profiles_read on admin_profiles;
create policy admin_profiles_read on admin_profiles
  for select using (auth.role() = 'authenticated');

-- A criação de novos administradores é feita só pela Netlify Function
-- (netlify/functions/admin-create-user.js), que usa a service_role key
-- (poder total, ignora RLS) — por isso não existe policy de INSERT aqui
-- para usuários comuns autenticados. Cada admin só pode editar o próprio
-- perfil (ex.: nome de exibição).
drop policy if exists admin_profiles_update_self on admin_profiles;
create policy admin_profiles_update_self on admin_profiles
  for update using (auth.uid() = id)
  with check (auth.uid() = id);

-- ============================================================================
-- 6. STORAGE (imagens de produtos e banners)
-- ============================================================================
-- Cria dois buckets públicos de leitura: "products" e "banners".
-- Upload de arquivo só é permitido para administradores autenticados.
insert into storage.buckets (id, name, public)
values ('products', 'products', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('banners', 'banners', true)
on conflict (id) do nothing;

drop policy if exists sm_storage_public_read on storage.objects;
create policy sm_storage_public_read on storage.objects
  for select using (bucket_id in ('products', 'banners'));

drop policy if exists sm_storage_admin_write on storage.objects;
create policy sm_storage_admin_write on storage.objects
  for insert with check (bucket_id in ('products', 'banners') and auth.role() = 'authenticated');

drop policy if exists sm_storage_admin_update on storage.objects;
create policy sm_storage_admin_update on storage.objects
  for update using (bucket_id in ('products', 'banners') and auth.role() = 'authenticated');

drop policy if exists sm_storage_admin_delete on storage.objects;
create policy sm_storage_admin_delete on storage.objects
  for delete using (bucket_id in ('products', 'banners') and auth.role() = 'authenticated');

-- ============================================================================
-- FIM DO SCHEMA
-- Próximo passo: rode supabase/seed-data.sql para migrar os 48 produtos e
-- 8 categorias originais da Etapa 1/2 para dentro destas tabelas.
-- ============================================================================
-- ============================================================================
-- SUPERMISTO — supabase/seed-data.sql (ETAPA 3)
-- ============================================================================
-- GERADO AUTOMATICAMENTE a partir de assets/js/products.js (dados originais
-- da Etapa 1/2). Rode DEPOIS de supabase/schema.sql, uma única vez, no SQL
-- Editor do Supabase.
--
-- SEGURO RODAR MAIS DE UMA VEZ: usa ON CONFLICT (chave primária) DO UPDATE,
-- ou seja, nunca cria produto/categoria duplicado — se já existir, só
-- atualiza os dados para bater com este arquivo.
--
-- Total: 8 categorias, 48 produtos.
-- ============================================================================

-- ---- CATEGORIAS ----

insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('temperos', 'Temperos', '🌿', 'Sabor no dia a dia', '#F0E4F7', '#3A1150', true, 0)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('conservas', 'Conservas', '🫙', 'Tradição em conserva', '#F3ECE1', '#7E2E1F', true, 1)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('pimentas', 'Pimentas', '🌶️', 'Para quem gosta de picar', '#FBEAE6', '#A6402C', true, 2)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('molhos', 'Molhos', '🥫', 'Molhos selecionados', '#F0E4F7', '#6B2F91', true, 3)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('ervas', 'Ervas e Especiarias', '🍃', 'Direto do campo', '#E9F1E7', '#4B7A4E', true, 4)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('kits', 'Kits', '📦', 'Combinações prontas', '#FBF1DF', '#B7883C', true, 5)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('chas', 'Chás', '☕', 'Momentos de pausa', '#E9F1E7', '#4B7A4E', true, 6)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;
insert into categories (slug, name, icon, description, bg, fg, active, sort_order)
values ('outros', 'Outros produtos', '⭐', 'Novidades da SuperMisto', '#F0E4F7', '#3A1150', true, 7)
on conflict (slug) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  bg = excluded.bg, fg = excluded.fg, sort_order = excluded.sort_order;

-- ---- PRODUTOS ----

insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('alho-desidratado', 'Alho Desidratado', 'temperos', 9.9, '100g', 'Alho selecionado, moído na hora certa.', 'Alho desidratado e moído, ideal para temperar carnes, molhos, arroz e legumes. Prático para o dia a dia, sem perder o sabor marcante do alho fresco.', '🧄', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cebola-desidratada', 'Cebola Desidratada', 'temperos', 8.9, '100g', 'Cebola em flocos, sabor concentrado.', 'Cebola desidratada em flocos, perfeita para dar sabor e aroma a molhos, sopas, carnes e receitas assadas.', '🧅', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cebola-roxa-desidratada', 'Cebola Roxa Desidratada', 'temperos', 10.9, '100g', 'Toque adocicado e cor marcante.', 'Cebola roxa desidratada, com sabor levemente adocicado. Ótima em saladas, molhos frios e pratos que pedem um toque especial.', '🧅', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cominho-em-grao', 'Cominho em Grão', 'temperos', 11.9, '80g', 'Aroma marcante para pratos especiais.', 'Cominho em grão selecionado, ideal para temperar carnes, feijão, arroz e receitas com influência árabe e mexicana.', '🌰', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cominho-em-po', 'Cominho em Pó', 'temperos', 10.9, '80g', 'Prático, moído na medida certa.', 'Cominho moído, pronto para usar. Sabor terroso e aromático, essencial em diversas receitas do dia a dia.', '🌰', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimenta-do-reino', 'Pimenta-do-Reino Moída', 'temperos', 12.9, '60g', 'O clássico que não pode faltar.', 'Pimenta-do-reino moída na hora, com aroma intenso e picância equilibrada. Indispensável na cozinha brasileira.', '⚫', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('oregano', 'Orégano Selecionado', 'temperos', 7.9, '50g', 'Perfeito para massas e pizzas.', 'Orégano selecionado e seco naturalmente, com aroma intenso. Combina com massas, pizzas, saladas e molhos.', '🌿', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('chimichurri', 'Chimichurri SuperMisto', 'temperos', 14.9, '80g', 'Blend pronto para churrasco.', 'Mistura de ervas e temperos no estilo chimichurri, pronta para uso em carnes grelhadas e churrascos.', '🌶️', true, false, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('colorau', 'Colorau', 'temperos', 8.5, '100g', 'Cor e sabor tradicionais.', 'Colorau tradicional, usado para dar cor e um sabor suave a arroz, feijão, carnes e ensopados.', '🟠', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('curcuma', 'Cúrcuma (Açafrão-da-Terra)', 'temperos', 11.5, '80g', 'Cor dourada e toque especial.', 'Cúrcuma moída, também conhecida como açafrão-da-terra. Dá cor dourada e sabor suave a arroz, carnes e sopas.', '🟡', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('lemon-pepper', 'Lemon Pepper', 'temperos', 13.9, '80g', 'Cítrico e apimentado.', 'Blend de pimenta com raspas de limão, ideal para frango, peixes e carnes grelhadas.', '🍋', true, true, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pepino-conserva', 'Pepino em Conserva', 'conservas', 15.9, '300g', 'Crocante e equilibrado.', 'Pepinos selecionados, em conserva no ponto certo de acidez e crocância. Ótimo para sanduíches e petiscos.', '🥒', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cenoura-conserva', 'Cenoura em Conserva', 'conservas', 13.9, '300g', 'Clássico da mesa brasileira.', 'Cenoura em conserva, cortada e temperada, pronta para acompanhar refeições ou compor petiscos.', '🥕', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('batatinha-conserva', 'Batatinha em Conserva', 'conservas', 14.9, '300g', 'Pequenas, saborosas, práticas.', 'Batatinhas em conserva, prontas para salpicões, saladas e petiscos do dia a dia.', '🥔', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('alho-conserva', 'Alho em Conserva', 'conservas', 16.9, '250g', 'Sabor suave e prático de usar.', 'Dentes de alho em conserva, com sabor mais suave que o alho fresco. Prático para usar direto na receita.', '🧄', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cebola-conserva', 'Cebola em Conserva', 'conservas', 13.5, '250g', 'Toque ácido e crocante.', 'Cebola em conserva, ideal para saladas, sanduíches e pratos que pedem um toque ácido.', '🧅', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimentas-conserva', 'Pimentas em Conserva', 'conservas', 17.9, '250g', 'Picância na medida.', 'Seleção de pimentas em conserva, para quem gosta de dar um toque picante às refeições.', '🌶️', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('beterraba-conserva', 'Beterraba em Conserva', 'conservas', 14.5, '300g', 'Cor viva, sabor adocicado.', 'Beterraba em conserva, com sabor levemente adocicado. Ótima para saladas e acompanhamentos.', '🔴', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('mix-legumes-conserva', 'Mix de Legumes em Conserva', 'conservas', 16.9, '300g', 'Praticidade em um único vidro.', 'Mix de legumes selecionados em conserva, prático para completar refeições e saladas.', '🥗', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('azeitonas', 'Azeitonas Selecionadas', 'conservas', 18.9, '250g', 'Clássicas em qualquer ocasião.', 'Azeitonas selecionadas, ideais para petiscos, saladas e receitas do dia a dia.', '🫒', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cogumelos-conserva', 'Cogumelos em Conserva', 'conservas', 19.9, '250g', 'Textura e sabor especiais.', 'Cogumelos em conserva, prontos para saladas, molhos e pratos quentes.', '🍄', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('milho-conserva', 'Milho em Conserva', 'conservas', 9.9, '300g', 'Doce e versátil.', 'Milho em conserva, prático para saladas, pipoca gourmet, tortas e acompanhamentos.', '🌽', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('tomate-seco', 'Tomate Seco', 'conservas', 22.9, '200g', 'Sabor concentrado e intenso.', 'Tomate seco em azeite, com sabor concentrado. Ótimo em antepastos, massas, saladas e petiscos.', '🍅', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('antepasto-supermisto', 'Antepasto SuperMisto', 'conservas', 21.9, '250g', 'Combinação pronta para servir.', 'Antepasto com seleção de legumes e temperos, pronto para servir com torradas e pães.', '🫙', true, false, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('molho-pimenta-tradicional', 'Molho de Pimenta Tradicional', 'molhos', 15.9, '150ml', 'Picância clássica e equilibrada.', 'Molho de pimenta no estilo tradicional, com picância equilibrada para acompanhar carnes, feijão e petiscos.', '🥫', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('molho-pimenta-defumado', 'Molho de Pimenta Defumado', 'molhos', 17.9, '150ml', 'Toque defumado marcante.', 'Molho de pimenta com toque defumado, ideal para churrascos e carnes grelhadas.', '🥫', true, false, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('molho-barbecue', 'Molho Barbecue SuperMisto', 'molhos', 16.9, '200ml', 'Doce, defumado e encorpado.', 'Molho barbecue encorpado, com equilíbrio entre doce e defumado. Combina com carnes, frango e sanduíches.', '🥫', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimenta-biquinho', 'Pimenta Biquinho', 'pimentas', 18.9, '200g', 'Docinha e levemente picante.', 'Pimenta biquinho em conserva, com sabor adocicado e leve picância. Ótima para petiscos e taças de recepção.', '🌶️', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimenta-dedo-de-moca', 'Pimenta Dedo-de-Moça', 'pimentas', 17.9, '200g', 'Picância marcante e aromática.', 'Pimenta dedo-de-moça selecionada, ideal para molhos, refogados e pratos que pedem mais ardência.', '🌶️', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('pimenta-malagueta', 'Pimenta Malagueta', 'pimentas', 16.9, '150g', 'Para quem gosta de sentir o ardor.', 'Pimenta malagueta em conserva, bem picante, tradicional na culinária brasileira.', '🌶️', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('manjericao-seco', 'Manjericão Seco', 'ervas', 8.9, '30g', 'Aroma fresco para molhos.', 'Manjericão seco, com aroma marcante, ideal para molhos de tomate, massas e pizzas.', '🌱', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('louro-folha', 'Folha de Louro', 'ervas', 7.5, '20g', 'Essencial em caldos e feijão.', 'Folhas de louro selecionadas, usadas para aromatizar caldos, feijão, carnes e ensopados.', '🍃', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('salsa-desidratada', 'Salsa Desidratada', 'ervas', 7.9, '30g', 'Frescor em qualquer prato.', 'Salsa desidratada, prática para finalizar pratos com frescor e cor.', '🌿', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('alecrim', 'Alecrim Seco', 'ervas', 9.5, '30g', 'Perfume marcante e rústico.', 'Alecrim seco, com aroma intenso, ótimo para carnes assadas, batatas e pães.', '🌿', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('kit-churrasco', 'Kit Churrasco SuperMisto', 'kits', 49.9, 'Kit com 4 itens', 'Tudo para o churrasco perfeito.', 'Kit com sal grosso temperado, chimichurri, pimenta-do-reino e molho barbecue — tudo o que você precisa para um churrasco completo.', '📦', true, true, false, true, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('kit-temperos-basicos', 'Kit Temperos Básicos', 'kits', 34.9, 'Kit com 5 itens', 'Os essenciais da cozinha.', 'Kit com alho, cebola, cominho, orégano e pimenta-do-reino — a base para o dia a dia na cozinha.', '📦', true, true, false, true, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('kit-conservas-selecionadas', 'Kit Conservas Selecionadas', 'kits', 44.9, 'Kit com 3 itens', 'Trio pronto para petiscar.', 'Kit com pepino, azeitonas e tomate seco — combinação pronta para receber visitas ou petiscar em casa.', '📦', true, false, true, true, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-camomila', 'Chá de Camomila', 'chas', 12.9, '50g', 'Clássico para relaxar.', 'Flores de camomila selecionadas, ideais para um chá calmante ao final do dia.', '🌼', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-erva-doce', 'Chá de Erva-Doce', 'chas', 11.9, '50g', 'Sabor suave e adocicado.', 'Erva-doce selecionada, com sabor suave, tradicional após as refeições.', '🌿', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-hortela', 'Chá de Hortelã', 'chas', 11.9, '40g', 'Refrescante em qualquer hora.', 'Folhas de hortelã selecionadas, para um chá refrescante, quente ou gelado.', '🌱', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-capim-cidreira', 'Chá de Capim-Cidreira', 'chas', 10.9, '40g', 'Aroma cítrico e suave.', 'Capim-cidreira selecionado, ideal para um chá calmante com toque cítrico.', '🌾', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-hibisco', 'Chá de Hibisco', 'chas', 13.9, '50g', 'Cor viva, sabor marcante.', 'Flores de hibisco selecionadas, para um chá de cor vibrante e sabor levemente ácido.', '🌺', true, true, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-boldo', 'Chá de Boldo', 'chas', 10.9, '40g', 'Tradicional depois das refeições.', 'Folhas de boldo selecionadas, tradicionalmente usadas após refeições mais pesadas.', '🍃', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-verde', 'Chá Verde', 'chas', 14.9, '50g', 'Leve e equilibrado.', 'Chá verde selecionado, com sabor leve e equilibrado para o dia a dia.', '🍵', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-preto', 'Chá Preto', 'chas', 13.9, '50g', 'Encorpado e aromático.', 'Chá preto selecionado, encorpado e aromático, ótimo puro ou com leite.', '🍵', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-maca-canela', 'Chá de Maçã com Canela', 'chas', 14.9, '50g', 'Aconchegante e adocicado.', 'Blend de maçã com canela, para um chá aconchegante e aromático.', '🍎', true, true, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-morango', 'Chá de Morango', 'chas', 14.9, '50g', 'Doce e perfumado.', 'Blend saborizado de morango, para um chá doce e perfumado.', '🍓', true, false, true, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;
insert into products (id, name, category, price, weight, short_desc, description, emoji, available, featured, is_new, is_kit, buy_link)
values ('cha-maracuja', 'Chá de Maracujá', 'chas', 14.9, '50g', 'Calmante e saboroso.', 'Blend saborizado de maracujá, conhecido por seu efeito calmante e sabor agradável.', '🧡', true, false, false, false, '#')
on conflict (id) do update set
  name = excluded.name, category = excluded.category, price = excluded.price,
  weight = excluded.weight, short_desc = excluded.short_desc, description = excluded.description,
  emoji = excluded.emoji, buy_link = excluded.buy_link;

-- ============================================================================
-- FIM DA MIGRAÇÃO. Confira no painel do Supabase (Table Editor) que
-- "categories" tem 8 linhas e "products" tem 48 linhas.
-- ============================================================================
-- ============================================================================
-- SUPERMISTO — supabase/migrations/002_modulo4_vendas.sql  (MÓDULO 4)
-- ============================================================================
-- Rode este arquivo INTEIRO no SQL Editor do Supabase, DEPOIS de já ter
-- rodado supabase/schema.sql e supabase/seed-data.sql (Etapa 3).
--
-- Este arquivo é 100% ADITIVO: não apaga tabelas, não apaga produtos, não
-- apaga categorias, não recria nada que já existe. Todos os comandos usam
-- "IF NOT EXISTS" / "ADD COLUMN IF NOT EXISTS" / "CREATE OR REPLACE" /
-- "DROP POLICY IF EXISTS" antes de criar de novo — seguro rodar mais de
-- uma vez.
--
-- O que este arquivo faz:
--   1. CORRIGE uma brecha de segurança da Etapa 3 (ver 4.0 abaixo) — deve
--      ser a primeira coisa a rodar, antes de existir qualquer cliente
--      cadastrado.
--   2. Adiciona estoque e campos fiscais aos produtos existentes (sem
--      alterar nenhum dado existente).
--   3. Cria as tabelas de clientes, endereços, pedidos, itens do pedido,
--      histórico de status, pagamentos e documentos fiscais.
--   4. Cria a função sm_create_order(), que cria um pedido inteiro (com
--      todos os itens e a baixa de estoque) em uma única transação atômica
--      — evita duas pessoas comprarem o último item em estoque ao mesmo
--      tempo e os dois pedidos serem aceitos.
-- ============================================================================


-- ============================================================================
-- 0. CORREÇÃO DE SEGURANÇA — LEIA ANTES DE CONTINUAR
-- ============================================================================
-- Na Etapa 3, todas as políticas de escrita (produtos, categorias, banners,
-- configurações) usavam `auth.role() = 'authenticated'` como critério de
-- "é administrador". Isso era seguro na época porque só existiam contas de
-- administrador no sistema.
--
-- A partir do Módulo 4, CLIENTES também podem criar conta e fazer login
-- (Supabase Auth). Se não corrigirmos isso agora, qualquer cliente logado
-- passaria a satisfazer `auth.role() = 'authenticated'` e conseguiria, por
-- exemplo, editar preços de produtos direto pela API — uma falha grave.
--
-- A correção: uma função `sm_is_admin()` que verifica se o usuário logado
-- tem uma linha correspondente em `admin_profiles` (que só é populada pela
-- Netlify Function admin-create-user.js ou pelo SQL de
-- create-first-admin.sql — nunca por auto-cadastro). Todas as políticas
-- "_admin_write" de produtos/categorias/banners/configurações/storage são
-- recriadas para usar `sm_is_admin()` no lugar de `auth.role() = 'authenticated'`.
create or replace function sm_is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from admin_profiles where id = auth.uid()
  );
$$;

comment on function sm_is_admin() is
  'Retorna true apenas se o usuário logado tiver um perfil em admin_profiles. Usado em todas as políticas RLS que prote gem operações administrativas — NUNCA usar auth.role() = ''authenticated'' sozinho para decidir permissão de admin, pois isso também é verdadeiro para clientes logados.';

-- Recria as políticas de escrita existentes usando sm_is_admin()
drop policy if exists categories_admin_write on categories;
create policy categories_admin_write on categories
  for all using (sm_is_admin()) with check (sm_is_admin());

drop policy if exists products_admin_write on products;
create policy products_admin_write on products
  for all using (sm_is_admin()) with check (sm_is_admin());

drop policy if exists banners_public_read on banners;
create policy banners_public_read on banners
  for select using (active = true or sm_is_admin());

drop policy if exists banners_admin_write on banners;
create policy banners_admin_write on banners
  for all using (sm_is_admin()) with check (sm_is_admin());

drop policy if exists settings_admin_write on settings;
create policy settings_admin_write on settings
  for update using (sm_is_admin()) with check (sm_is_admin());

drop policy if exists admin_profiles_read on admin_profiles;
create policy admin_profiles_read on admin_profiles
  for select using (sm_is_admin());

drop policy if exists sm_storage_admin_write on storage.objects;
create policy sm_storage_admin_write on storage.objects
  for insert with check (bucket_id in ('products', 'banners') and sm_is_admin());

drop policy if exists sm_storage_admin_update on storage.objects;
create policy sm_storage_admin_update on storage.objects
  for update using (bucket_id in ('products', 'banners') and sm_is_admin());

drop policy if exists sm_storage_admin_delete on storage.objects;
create policy sm_storage_admin_delete on storage.objects
  for delete using (bucket_id in ('products', 'banners') and sm_is_admin());


-- ============================================================================
-- 1. ESTOQUE E CAMPOS FISCAIS EM PRODUCTS (aditivo — não altera dados existentes)
-- ============================================================================
alter table products add column if not exists track_stock boolean not null default false;
alter table products add column if not exists stock_quantity integer not null default 0;

-- Campos fiscais do PRODUTO (preparação para nota fiscal — ver seção 9 do
-- PROJETO.md). Ficam nulos até serem preenchidos; não afetam o site público.
alter table products add column if not exists ncm text;
alter table products add column if not exists cfop text;
alter table products add column if not exists fiscal_origin text;

comment on column products.track_stock is
  'Se false (padrão), o produto usa só o campo "available" (disponível/indisponível) como na Etapa 2/3 — sem controle numérico. Se true, o site e o checkout passam a validar stock_quantity antes de vender.';
comment on column products.stock_quantity is
  'Quantidade em estoque. Só é validada no checkout quando track_stock = true.';

create index if not exists idx_products_track_stock on products(track_stock) where track_stock = true;


-- ============================================================================
-- 2. CUSTOMERS (clientes)
-- ============================================================================
-- Um cliente é sempre um usuário do Supabase Auth (mesma tecnologia usada
-- para administradores desde a Etapa 3, mas em uma tabela separada de
-- admin_profiles — um cliente NUNCA aparece em admin_profiles, e portanto
-- sm_is_admin() é sempre false para ele).
create table if not exists customers (
  id          uuid primary key references auth.users(id) on delete cascade,
  name        text not null default '',
  email       text not null,
  phone       text default '',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

drop trigger if exists trg_customers_updated_at on customers;
create trigger trg_customers_updated_at
  before update on customers
  for each row execute function sm_set_updated_at();

alter table customers enable row level security;

drop policy if exists customers_self_or_admin_read on customers;
create policy customers_self_or_admin_read on customers
  for select using (auth.uid() = id or sm_is_admin());

drop policy if exists customers_self_insert on customers;
create policy customers_self_insert on customers
  for insert with check (auth.uid() = id);

drop policy if exists customers_self_or_admin_update on customers;
create policy customers_self_or_admin_update on customers
  for update using (auth.uid() = id or sm_is_admin())
  with check (auth.uid() = id or sm_is_admin());


-- ============================================================================
-- 3. ADDRESSES (endereços de entrega)
-- ============================================================================
create table if not exists addresses (
  id              uuid primary key default gen_random_uuid(),
  customer_id     uuid not null references customers(id) on delete cascade,
  label           text default 'Principal',
  recipient_name  text default '',
  phone           text default '',
  cep             text default '',
  street          text default '',
  number          text default '',
  complement      text default '',
  neighborhood    text default '',
  city            text default '',
  state           text default '',
  is_default      boolean not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index if not exists idx_addresses_customer on addresses(customer_id);

drop trigger if exists trg_addresses_updated_at on addresses;
create trigger trg_addresses_updated_at
  before update on addresses
  for each row execute function sm_set_updated_at();

alter table addresses enable row level security;

drop policy if exists addresses_owner_or_admin on addresses;
create policy addresses_owner_or_admin on addresses
  for all using (customer_id = auth.uid() or sm_is_admin())
  with check (customer_id = auth.uid() or sm_is_admin());


-- ============================================================================
-- 4. ORDERS (pedidos)
-- ============================================================================
-- Sequência usada para gerar um número de pedido legível (SM-000001,
-- SM-000002, ...) de forma atômica, sem depender de lógica no frontend.
create sequence if not exists sm_order_seq start 1;

create or replace function sm_next_order_number()
returns text
language sql
as $$
  select 'SM-' || lpad(nextval('sm_order_seq')::text, 6, '0');
$$;

create table if not exists orders (
  id                 uuid primary key default gen_random_uuid(),
  order_number       text not null unique default sm_next_order_number(),
  customer_id        uuid references customers(id),
  status             text not null default 'aguardando_pagamento'
                       check (status in (
                         'aguardando_pagamento','pagamento_aprovado','em_preparacao',
                         'pronto_envio','enviado','entregue','cancelado','reembolsado'
                       )),
  payment_status     text not null default 'pending'
                       check (payment_status in ('pending','approved','refused','cancelled','refunded')),
  subtotal           numeric(10,2) not null default 0,
  discount           numeric(10,2) not null default 0,
  shipping           numeric(10,2) not null default 0,
  total              numeric(10,2) not null default 0,
  shipping_address   jsonb,                    -- snapshot do endereço no momento da compra
  customer_snapshot  jsonb,                    -- snapshot de nome/e-mail/telefone no momento da compra
  notes              text default '',
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create index if not exists idx_orders_customer on orders(customer_id);
create index if not exists idx_orders_status on orders(status);
create index if not exists idx_orders_created on orders(created_at desc);

drop trigger if exists trg_orders_updated_at on orders;
create trigger trg_orders_updated_at
  before update on orders
  for each row execute function sm_set_updated_at();

alter table orders enable row level security;

-- Clientes só veem os próprios pedidos; administradores veem todos.
drop policy if exists orders_owner_or_admin_read on orders;
create policy orders_owner_or_admin_read on orders
  for select using (customer_id = auth.uid() or sm_is_admin());

-- Criação de pedido NÃO tem policy de INSERT para authenticated/anon de
-- propósito: todo pedido é criado através da função sm_create_order()
-- (chamada pela Netlify Function checkout-create-order.js com a
-- service_role key), que valida estoque e preços no servidor antes de
-- gravar qualquer coisa. Isso impede um cliente de inserir um pedido
-- diretamente pela API com preços ou totais forjados.
--
-- Só administradores podem alterar o status de um pedido diretamente pelo
-- painel (ex.: marcar como "enviado").
drop policy if exists orders_admin_update on orders;
create policy orders_admin_update on orders
  for update using (sm_is_admin()) with check (sm_is_admin());


-- ============================================================================
-- 5. ORDER_ITEMS (itens do pedido)
-- ============================================================================
create table if not exists order_items (
  id            uuid primary key default gen_random_uuid(),
  order_id      uuid not null references orders(id) on delete cascade,
  product_id    text references products(id) on delete set null,
  product_name  text not null,          -- snapshot: nome no momento da compra
  unit_price    numeric(10,2) not null, -- snapshot: preço no momento da compra
  quantity      integer not null check (quantity > 0),
  subtotal      numeric(10,2) not null
);

create index if not exists idx_order_items_order on order_items(order_id);

alter table order_items enable row level security;

drop policy if exists order_items_via_order on order_items;
create policy order_items_via_order on order_items
  for select using (
    exists (
      select 1 from orders o
      where o.id = order_items.order_id
        and (o.customer_id = auth.uid() or sm_is_admin())
    )
  );
-- Sem policy de insert/update/delete para authenticated/anon: os itens só
-- são criados dentro de sm_create_order() (executada com privilégio de
-- dono da função — ver "security definer" abaixo).


-- ============================================================================
-- 6. ORDER_STATUS_HISTORY (histórico de alterações do pedido)
-- ============================================================================
create table if not exists order_status_history (
  id          uuid primary key default gen_random_uuid(),
  order_id    uuid not null references orders(id) on delete cascade,
  status      text not null,
  changed_by  uuid references auth.users(id),
  note        text default '',
  created_at  timestamptz not null default now()
);

create index if not exists idx_status_history_order on order_status_history(order_id);

alter table order_status_history enable row level security;

drop policy if exists status_history_read on order_status_history;
create policy status_history_read on order_status_history
  for select using (
    exists (
      select 1 from orders o
      where o.id = order_status_history.order_id
        and (o.customer_id = auth.uid() or sm_is_admin())
    )
  );

drop policy if exists status_history_admin_insert on order_status_history;
create policy status_history_admin_insert on order_status_history
  for insert with check (sm_is_admin());


-- ============================================================================
-- 7. PAYMENTS (pagamentos)
-- ============================================================================
create table if not exists payments (
  id                        uuid primary key default gen_random_uuid(),
  order_id                  uuid not null references orders(id) on delete cascade,
  customer_id               uuid references customers(id),
  provider                  text not null default 'mock',   -- 'mock' | futuramente 'mercadopago', 'stripe', etc.
  provider_transaction_id   text,
  amount                    numeric(10,2) not null,
  status                    text not null default 'pending'
                              check (status in ('pending','approved','refused','cancelled','refunded')),
  method                    text,                            -- 'pix' | 'credit_card' | 'boleto' | ...
  raw_response              jsonb,
  created_at                timestamptz not null default now(),
  updated_at                timestamptz not null default now()
);

create index if not exists idx_payments_order on payments(order_id);

drop trigger if exists trg_payments_updated_at on payments;
create trigger trg_payments_updated_at
  before update on payments
  for each row execute function sm_set_updated_at();

alter table payments enable row level security;

drop policy if exists payments_owner_or_admin_read on payments;
create policy payments_owner_or_admin_read on payments
  for select using (customer_id = auth.uid() or sm_is_admin());

-- Administradores podem atualizar manualmente (ex.: confirmar um pagamento
-- via transferência bancária). Criação inicial do pagamento é feita dentro
-- de sm_create_order(); confirmações automáticas (modo de teste) vêm da
-- Netlify Function payment-mock-confirm.js, usando a service_role key.
drop policy if exists payments_admin_update on payments;
create policy payments_admin_update on payments
  for update using (sm_is_admin()) with check (sm_is_admin());


-- ============================================================================
-- 8. FISCAL_DOCUMENTS (nota fiscal — só estrutura, sem integração real)
-- ============================================================================
-- IMPORTANTE: esta tabela só guarda o ESTADO de uma futura nota fiscal.
-- Nenhuma nota fiscal é emitida de verdade por este projeto — não existe
-- integração com nenhuma API fiscal (SEFAZ, NFE.io, Focus NFe, etc.) nesta
-- etapa. Ver seção "Nota fiscal" do PROJETO.md para o que falta conectar.
create table if not exists fiscal_documents (
  id             uuid primary key default gen_random_uuid(),
  order_id       uuid not null references orders(id) on delete cascade,
  status         text not null default 'nao_emitida'
                   check (status in ('nao_emitida','pendente','emitida','erro','cancelada')),
  numero         text,
  serie          text,
  chave_acesso   text,
  provider       text,          -- nome do provedor fiscal, quando existir uma integração real
  emitted_at     timestamptz,
  raw_response   jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create index if not exists idx_fiscal_documents_order on fiscal_documents(order_id);

drop trigger if exists trg_fiscal_documents_updated_at on fiscal_documents;
create trigger trg_fiscal_documents_updated_at
  before update on fiscal_documents
  for each row execute function sm_set_updated_at();

alter table fiscal_documents enable row level security;

drop policy if exists fiscal_documents_admin_only on fiscal_documents;
create policy fiscal_documents_admin_only on fiscal_documents
  for all using (sm_is_admin()) with check (sm_is_admin());


-- ============================================================================
-- 9. COMPANY_FISCAL_INFO (dados fiscais da empresa — linha única, id=1)
-- ============================================================================
create table if not exists company_fiscal_info (
  id                    integer primary key default 1 check (id = 1),
  razao_social          text default '',
  nome_fantasia         text default '',
  cnpj                  text default '',
  inscricao_estadual    text default '',
  regime_tributario     text default '',
  endereco              jsonb default '{}',
  updated_at            timestamptz not null default now()
);

insert into company_fiscal_info (id) values (1) on conflict (id) do nothing;

drop trigger if exists trg_company_fiscal_updated_at on company_fiscal_info;
create trigger trg_company_fiscal_updated_at
  before update on company_fiscal_info
  for each row execute function sm_set_updated_at();

alter table company_fiscal_info enable row level security;

drop policy if exists company_fiscal_admin_only on company_fiscal_info;
create policy company_fiscal_admin_only on company_fiscal_info
  for all using (sm_is_admin()) with check (sm_is_admin());


-- ============================================================================
-- 10. sm_create_order() — criação atômica de pedido (valida estoque e preço)
-- ============================================================================
-- Recebe os itens do carrinho (só product_id + quantity — NUNCA confia em
-- preço vindo do cliente) e cria, em uma única transação:
--   - o pedido (orders)
--   - os itens do pedido, com preço vindo do banco no momento da compra (order_items)
--   - o registro de pagamento inicial, status "pending" (payments)
--   - a baixa de estoque dos produtos com track_stock = true (products)
--   - o primeiro registro de histórico de status (order_status_history)
--
-- Se qualquer produto não existir, estiver indisponível, ou não tiver
-- estoque suficiente, a função inteira falha (raise exception) e o
-- Postgres desfaz automaticamente tudo que já tinha sido feito — não fica
-- nenhum pedido "pela metade".
--
-- security definer: roda com o dono da função (que tem acesso total às
-- tabelas), então funciona mesmo com RLS habilitado nas tabelas envolvidas
-- — é por isso que orders/order_items não precisam de policy pública de
-- INSERT: toda escrita passa por aqui.
create or replace function sm_create_order(
  p_customer_id uuid,
  p_items jsonb,               -- [{"product_id": "alho-desidratado", "quantity": 2}, ...]
  p_shipping_address jsonb,
  p_customer_snapshot jsonb,
  p_shipping numeric default 0,
  p_discount numeric default 0,
  p_payment_method text default 'pix'
)
returns table (order_id uuid, order_number text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item jsonb;
  v_product products%rowtype;
  v_qty integer;
  v_unit_price numeric(10,2);
  v_subtotal numeric(10,2) := 0;
  v_total numeric(10,2);
  v_order_id uuid;
  v_order_number text;
begin
  if p_items is null or jsonb_array_length(p_items) = 0 then
    raise exception 'O pedido precisa ter pelo menos um item.';
  end if;

  -- 1ª passada: valida cada item (existe, disponível, estoque suficiente)
  -- e soma o subtotal usando o preço ATUAL do banco (nunca o do cliente).
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product from products where id = (v_item->>'product_id');
    if not found then
      raise exception 'Produto % não encontrado.', (v_item->>'product_id');
    end if;

    if v_product.available = false then
      raise exception 'Produto "%" está indisponível no momento.', v_product.name;
    end if;

    v_qty := (v_item->>'quantity')::integer;
    if v_qty is null or v_qty <= 0 then
      raise exception 'Quantidade inválida para o produto "%".', v_product.name;
    end if;

    if v_product.track_stock and v_product.stock_quantity < v_qty then
      raise exception 'Estoque insuficiente para "%": disponível %, solicitado %.',
        v_product.name, v_product.stock_quantity, v_qty;
    end if;

    v_unit_price := coalesce(v_product.sale_price, v_product.price);
    v_subtotal := v_subtotal + (v_unit_price * v_qty);
  end loop;

  v_total := v_subtotal - coalesce(p_discount, 0) + coalesce(p_shipping, 0);
  if v_total < 0 then
    v_total := 0;
  end if;

  -- Cria o pedido
  insert into orders (customer_id, subtotal, discount, shipping, total, shipping_address, customer_snapshot)
  values (p_customer_id, v_subtotal, coalesce(p_discount, 0), coalesce(p_shipping, 0), v_total, p_shipping_address, p_customer_snapshot)
  returning id, order_number into v_order_id, v_order_number;

  -- 2ª passada: cria os itens e dá baixa no estoque
  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product from products where id = (v_item->>'product_id');
    v_qty := (v_item->>'quantity')::integer;
    v_unit_price := coalesce(v_product.sale_price, v_product.price);

    insert into order_items (order_id, product_id, product_name, unit_price, quantity, subtotal)
    values (v_order_id, v_product.id, v_product.name, v_unit_price, v_qty, v_unit_price * v_qty);

    if v_product.track_stock then
      update products set stock_quantity = stock_quantity - v_qty where id = v_product.id;
    end if;
  end loop;

  -- Cria o registro de pagamento inicial (modo mock/teste — ver
  -- netlify/functions/payment-mock-confirm.js)
  insert into payments (order_id, customer_id, provider, amount, status, method)
  values (v_order_id, p_customer_id, 'mock', v_total, 'pending', p_payment_method);

  -- Primeiro registro de histórico
  insert into order_status_history (order_id, status, note)
  values (v_order_id, 'aguardando_pagamento', 'Pedido criado.');

  return query select v_order_id, v_order_number;
end;
$$;

comment on function sm_create_order is
  'Cria um pedido completo (order + order_items + payment inicial + baixa de estoque) em uma transação atômica. Chamada exclusivamente pela Netlify Function checkout-create-order.js. Não deve ser exposta diretamente ao cliente sem validação de autenticação antes.';

-- ============================================================================
-- FIM DA MIGRATION DO MÓDULO 4
-- ============================================================================
-- ============================================================================
-- SUPERMISTO — supabase/migrations/003_modulo5.sql  (MÓDULO 5)
-- ============================================================================
-- Rode este arquivo INTEIRO no SQL Editor do Supabase, DEPOIS de já ter
-- rodado 001 (schema.sql), seed-data.sql e 002_modulo4_vendas.sql.
--
-- 100% ADITIVO — não apaga tabelas, não apaga produtos/categorias/pedidos,
-- não recria nada que já existe. Seguro rodar mais de uma vez.
--
-- O que este arquivo faz:
--   1. Papéis de administrador (owner / editor) — permissões diferenciadas.
--   2. Histórico/auditoria automática de produtos e categorias (triggers).
--   3. Mensagens de contato (armazenadas de verdade; e-mail é best-effort,
--      só se configurado — ver seção "Contato" do PROJETO.md).
--   4. Preparação de pagamento real (a integração em si mora nas Netlify
--      Functions; aqui só garantimos que "payments" aceita o provedor real).
-- ============================================================================


-- ============================================================================
-- 1. PAPÉIS DE ADMINISTRADOR (owner / editor)
-- ============================================================================
-- admin_profiles.role já existia (Etapa 3), mas sem restrição de valores e
-- sem nada checando o papel de verdade. A partir de agora:
--   owner  → acesso total (inclusive Configurações, dados fiscais, criar
--            outros administradores).
--   editor → gerencia catálogo e pedidos, mas NÃO vê Configurações,
--            dados fiscais nem consegue criar outro administrador.
--
-- Administradores já existentes (criados antes desta migration) viram
-- "owner" automaticamente, para não perder acesso a nada que já usavam.
alter table admin_profiles alter column role set default 'editor';

update admin_profiles set role = 'owner' where role is null or role not in ('owner', 'editor');

alter table admin_profiles drop constraint if exists admin_profiles_role_check;
alter table admin_profiles add constraint admin_profiles_role_check check (role in ('owner', 'editor'));

create or replace function sm_admin_role()
returns text
language sql
security definer
stable
set search_path = public
as $$
  select role from admin_profiles where id = auth.uid();
$$;

create or replace function sm_is_owner()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select coalesce((select role from admin_profiles where id = auth.uid()) = 'owner', false);
$$;

comment on function sm_is_owner() is
  'Retorna true só para administradores com role = owner. Usado nas políticas RLS de Configurações, dados fiscais e nas Netlify Functions que criam outros administradores.';

-- Configurações (WhatsApp/e-mail/redes) e dados fiscais passam a exigir
-- owner para escrever (editor pode continuar lendo, via as policies de
-- leitura já existentes, que continuam usando sm_is_admin()).
drop policy if exists settings_admin_write on settings;
create policy settings_admin_write on settings
  for update using (sm_is_owner()) with check (sm_is_owner());

drop policy if exists company_fiscal_admin_only on company_fiscal_info;
create policy company_fiscal_admin_only on company_fiscal_info
  for all using (sm_is_admin()) with check (sm_is_admin());
-- (leitura continua para qualquer admin; escrita real de fato é reforçada
-- também na interface do painel — só a tela de Configurações, visível
-- apenas para owner, oferece o formulário de edição.)


-- ============================================================================
-- 2. HISTÓRICO/AUDITORIA DE PRODUTOS E CATEGORIAS
-- ============================================================================
create table if not exists audit_log (
  id             uuid primary key default gen_random_uuid(),
  table_name     text not null,
  record_id      text not null,
  action         text not null check (action in ('insert', 'update', 'delete')),
  changed_by     uuid references auth.users(id),
  changed_by_email text,
  before_data    jsonb,
  after_data     jsonb,
  created_at     timestamptz not null default now()
);

create index if not exists idx_audit_log_table_record on audit_log(table_name, record_id);
create index if not exists idx_audit_log_created on audit_log(created_at desc);

alter table audit_log enable row level security;

drop policy if exists audit_log_admin_read on audit_log;
create policy audit_log_admin_read on audit_log
  for select using (sm_is_admin());
-- Sem policy de insert para authenticated/anon: só a trigger (security
-- definer) grava aqui — ninguém consegue forjar um registro de auditoria
-- direto pela API.

create or replace function sm_audit_trigger()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_record_id text;
  v_email text;
begin
  select email into v_email from admin_profiles where id = auth.uid();

  if tg_op = 'DELETE' then
    v_record_id := old.id::text;
    insert into audit_log (table_name, record_id, action, changed_by, changed_by_email, before_data, after_data)
    values (tg_table_name, v_record_id, 'delete', auth.uid(), v_email, to_jsonb(old), null);
    return old;
  elsif tg_op = 'UPDATE' then
    v_record_id := new.id::text;
    insert into audit_log (table_name, record_id, action, changed_by, changed_by_email, before_data, after_data)
    values (tg_table_name, v_record_id, 'update', auth.uid(), v_email, to_jsonb(old), to_jsonb(new));
    return new;
  else
    v_record_id := new.id::text;
    insert into audit_log (table_name, record_id, action, changed_by, changed_by_email, before_data, after_data)
    values (tg_table_name, v_record_id, 'insert', auth.uid(), v_email, null, to_jsonb(new));
    return new;
  end if;
end;
$$;

comment on function sm_audit_trigger() is
  'Grava uma linha em audit_log a cada INSERT/UPDATE/DELETE em produtos ou categorias. Roda no banco (trigger), não pode ser contornada pelo front-end nem pelas Netlify Functions.';

drop trigger if exists trg_audit_products on products;
create trigger trg_audit_products
  after insert or update or delete on products
  for each row execute function sm_audit_trigger();

drop trigger if exists trg_audit_categories on categories;
create trigger trg_audit_categories
  after insert or update or delete on categories
  for each row execute function sm_audit_trigger();


-- ============================================================================
-- 3. MENSAGENS DE CONTATO
-- ============================================================================
-- O formulário de contato do site público grava aqui diretamente (RLS
-- permite INSERT público, como uma caixa de correio). A leitura é só para
-- administradores — ver admin/mensagens.html.
create table if not exists contact_messages (
  id          uuid primary key default gen_random_uuid(),
  name        text not null default '',
  email       text not null,
  phone       text default '',
  message     text not null,
  status      text not null default 'novo' check (status in ('novo', 'lido', 'respondido')),
  email_sent  boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists idx_contact_messages_status on contact_messages(status);

drop trigger if exists trg_contact_messages_updated_at on contact_messages;
create trigger trg_contact_messages_updated_at
  before update on contact_messages
  for each row execute function sm_set_updated_at();

alter table contact_messages enable row level security;

drop policy if exists contact_messages_public_insert on contact_messages;
create policy contact_messages_public_insert on contact_messages
  for insert with check (true);

drop policy if exists contact_messages_admin_read on contact_messages;
create policy contact_messages_admin_read on contact_messages
  for select using (sm_is_admin());

drop policy if exists contact_messages_admin_update on contact_messages;
create policy contact_messages_admin_update on contact_messages
  for update using (sm_is_admin()) with check (sm_is_admin());

comment on table contact_messages is
  'Mensagens enviadas pelo formulário de contato do site público. Sempre gravadas aqui de verdade; o envio de e-mail de notificação para o lojista é best-effort e só acontece se houver um provedor de e-mail configurado (ver netlify/functions/contact-notify-email.js).';


-- ============================================================================
-- 4. PAGAMENTO REAL — nada de schema novo, só documentação
-- ============================================================================
-- A tabela "payments" (Módulo 4) já tem os campos necessários para um
-- provedor real: "provider" (ex.: 'mercadopago'), "provider_transaction_id"
-- e "raw_response" (payload devolvido pelo gateway). Nenhuma coluna nova é
-- necessária — a integração real mora inteiramente nas Netlify Functions
-- payment-create-preference.js e payment-webhook-mercadopago.js. Ver
-- PROJETO.md, seção 17 (Módulo 5), para as variáveis de ambiente exigidas.

-- ============================================================================
-- FIM DA MIGRATION DO MÓDULO 5
-- ============================================================================
-- ============================================================================
-- SUPERMISTO — supabase/migrations/004_modulo6.sql  (MÓDULO 6)
-- ============================================================================
-- Rode DEPOIS de 001 (schema.sql), seed-data.sql, 002_modulo4_vendas.sql e
-- 003_modulo5.sql.
--
-- 100% ADITIVO — não apaga produtos/categorias/pedidos/clientes/admins,
-- não recria nada que já existe. Seguro rodar mais de uma vez.
--
-- O que este arquivo faz:
--   1. Marketplace: vendedores (seller_profiles), produtos vinculados a um
--      vendedor (products.seller_id, opcional — null = produto da própria
--      loja SuperMisto, como os 48 produtos originais), e o "recorte" de
--      qual vendedor forneceu cada item vendido (order_items.seller_id).
--   2. Preparação para nota fiscal real (nenhuma coluna nova necessária —
--      fiscal_documents e company_fiscal_info já existiam desde o Módulo 4;
--      a integração real mora nas Netlify Functions fiscal-emit-nfe.js e
--      fiscal-check-status.js).
-- ============================================================================


-- ============================================================================
-- 1. SELLER_PROFILES (vendedores do marketplace)
-- ============================================================================
-- Um vendedor é um usuário do Supabase Auth (mesma tecnologia usada para
-- administradores e clientes), mas em uma tabela própria — um vendedor
-- NUNCA aparece em admin_profiles nem em customers, então sm_is_admin() e
-- sm_is_owner() continuam sempre false para ele (não ganha nenhum acesso
-- administrativo por engano).
create table if not exists seller_profiles (
  id                uuid primary key references auth.users(id) on delete cascade,
  store_name        text not null default '',
  email             text not null,
  phone             text default '',
  commission_rate   numeric(5,2) not null default 15.00 check (commission_rate >= 0 and commission_rate <= 100),
  status            text not null default 'pending' check (status in ('pending', 'active', 'suspended')),
  payout_info       jsonb default '{}',   -- dados de repasse (ex.: chave Pix) — preenchido pelo próprio vendedor
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

drop trigger if exists trg_seller_profiles_updated_at on seller_profiles;
create trigger trg_seller_profiles_updated_at
  before update on seller_profiles
  for each row execute function sm_set_updated_at();

alter table seller_profiles enable row level security;

create or replace function sm_is_seller()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from seller_profiles where id = auth.uid() and status = 'active'
  );
$$;

comment on function sm_is_seller() is
  'Retorna true só para vendedores com status = active. Usado nas políticas RLS que permitem um vendedor gerenciar os próprios produtos.';

-- O próprio vendedor vê e atualiza seu perfil; administradores veem/gerenciam todos.
drop policy if exists seller_profiles_self_or_admin_read on seller_profiles;
create policy seller_profiles_self_or_admin_read on seller_profiles
  for select using (auth.uid() = id or sm_is_admin());

drop policy if exists seller_profiles_self_update on seller_profiles;
create policy seller_profiles_self_update on seller_profiles
  for update using (auth.uid() = id or sm_is_owner())
  with check (auth.uid() = id or sm_is_owner());
-- Sem policy de INSERT para authenticated/anon: a conta de vendedor só é
-- criada pela Netlify Function seller-create.js (owner-only), do mesmo
-- jeito que administradores só são criados por admin-create-user.js.


-- ============================================================================
-- 2. PRODUTOS — vínculo opcional com um vendedor
-- ============================================================================
alter table products add column if not exists seller_id uuid references seller_profiles(id) on delete set null;

create index if not exists idx_products_seller on products(seller_id) where seller_id is not null;

comment on column products.seller_id is
  'Vendedor do marketplace dono deste produto. NULL = produto da própria loja SuperMisto (todos os 48 produtos originais continuam assim).';

-- Um vendedor ativo pode gerenciar (inserir/editar/excluir) SÓ os produtos
-- que já são dele (seller_id = auth.uid()) — nunca produtos de outro
-- vendedor nem produtos da loja (seller_id null). A política de admin
-- (products_admin_write, do Módulo 3) continua valendo em paralelo, sem
-- mudanças — administradores continuam podendo mexer em qualquer produto.
drop policy if exists products_seller_write on products;
create policy products_seller_write on products
  for all using (sm_is_seller() and seller_id = auth.uid())
  with check (sm_is_seller() and seller_id = auth.uid());

-- Vendedores ativos também precisam conseguir enviar fotos dos próprios
-- produtos para o bucket "products" do Storage — as políticas de Storage
-- da Etapa 3 só liberavam isso para sm_is_admin(). Sem esta política, um
-- vendedor conseguiria criar o produto mas nunca conseguiria subir uma
-- imagem para ele.
drop policy if exists sm_storage_seller_write on storage.objects;
create policy sm_storage_seller_write on storage.objects
  for insert with check (bucket_id = 'products' and sm_is_seller());


-- ============================================================================
-- 3. ORDER_ITEMS — snapshot de qual vendedor forneceu o item
-- ============================================================================
alter table order_items add column if not exists seller_id uuid references seller_profiles(id);

comment on column order_items.seller_id is
  'Snapshot de products.seller_id no momento da compra (preenchido por sm_create_order). NULL = item vendido pela própria loja.';

-- Um vendedor consegue ver os itens vendidos que são dele (para
-- acompanhar as próprias vendas), além do que já era permitido
-- (cliente dono do pedido e administradores).
drop policy if exists order_items_via_order on order_items;
create policy order_items_via_order on order_items
  for select using (
    (seller_id is not null and seller_id = auth.uid())
    or exists (
      select 1 from orders o
      where o.id = order_items.order_id
        and (o.customer_id = auth.uid() or sm_is_admin())
    )
  );


-- ============================================================================
-- 4. sm_create_order() — atualizada para registrar o vendedor de cada item
-- ============================================================================
-- Mesma lógica da versão do Módulo 4 (validação de estoque/preço, criação
-- atômica), só acrescentando o snapshot de seller_id em order_items.
create or replace function sm_create_order(
  p_customer_id uuid,
  p_items jsonb,
  p_shipping_address jsonb,
  p_customer_snapshot jsonb,
  p_shipping numeric default 0,
  p_discount numeric default 0,
  p_payment_method text default 'pix'
)
returns table (order_id uuid, order_number text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item jsonb;
  v_product products%rowtype;
  v_qty integer;
  v_unit_price numeric(10,2);
  v_subtotal numeric(10,2) := 0;
  v_total numeric(10,2);
  v_order_id uuid;
  v_order_number text;
begin
  if p_items is null or jsonb_array_length(p_items) = 0 then
    raise exception 'O pedido precisa ter pelo menos um item.';
  end if;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product from products where id = (v_item->>'product_id');
    if not found then
      raise exception 'Produto % não encontrado.', (v_item->>'product_id');
    end if;

    if v_product.available = false then
      raise exception 'Produto "%" está indisponível no momento.', v_product.name;
    end if;

    v_qty := (v_item->>'quantity')::integer;
    if v_qty is null or v_qty <= 0 then
      raise exception 'Quantidade inválida para o produto "%".', v_product.name;
    end if;

    if v_product.track_stock and v_product.stock_quantity < v_qty then
      raise exception 'Estoque insuficiente para "%": disponível %, solicitado %.',
        v_product.name, v_product.stock_quantity, v_qty;
    end if;

    v_unit_price := coalesce(v_product.sale_price, v_product.price);
    v_subtotal := v_subtotal + (v_unit_price * v_qty);
  end loop;

  v_total := v_subtotal - coalesce(p_discount, 0) + coalesce(p_shipping, 0);
  if v_total < 0 then
    v_total := 0;
  end if;

  insert into orders (customer_id, subtotal, discount, shipping, total, shipping_address, customer_snapshot)
  values (p_customer_id, v_subtotal, coalesce(p_discount, 0), coalesce(p_shipping, 0), v_total, p_shipping_address, p_customer_snapshot)
  returning id, order_number into v_order_id, v_order_number;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product from products where id = (v_item->>'product_id');
    v_qty := (v_item->>'quantity')::integer;
    v_unit_price := coalesce(v_product.sale_price, v_product.price);

    insert into order_items (order_id, product_id, product_name, unit_price, quantity, subtotal, seller_id)
    values (v_order_id, v_product.id, v_product.name, v_unit_price, v_qty, v_unit_price * v_qty, v_product.seller_id);

    if v_product.track_stock then
      update products set stock_quantity = stock_quantity - v_qty where id = v_product.id;
    end if;
  end loop;

  insert into payments (order_id, customer_id, provider, amount, status, method)
  values (v_order_id, p_customer_id, 'mock', v_total, 'pending', p_payment_method);

  insert into order_status_history (order_id, status, note)
  values (v_order_id, 'aguardando_pagamento', 'Pedido criado.');

  return query select v_order_id, v_order_number;
end;
$$;

comment on function sm_create_order is
  'Cria um pedido completo (order + order_items com snapshot de vendedor + payment inicial + baixa de estoque) em uma transação atômica. Chamada exclusivamente pela Netlify Function checkout-create-order.js.';

-- ============================================================================
-- FIM DA MIGRATION DO MÓDULO 6
-- ============================================================================
-- ============================================================================
-- SUPERMISTO — supabase/migrations/005_modulo7.sql  (MÓDULO 7)
-- ============================================================================
-- Rode DEPOIS de 001 (schema.sql), seed-data.sql, 002, 003 e
-- 004_modulo6.sql.
--
-- 100% ADITIVO — não apaga produtos/categorias/pedidos/clientes/admins/
-- vendedores, não recria nada que já existe. Seguro rodar mais de uma vez.
--
-- O que este arquivo faz:
--   1. Split de pagamento: cada vendedor pode conectar a própria conta do
--      Mercado Pago (OAuth). Quando conectado, o checkout de um pedido com
--      produtos daquele vendedor divide o pagamento automaticamente —
--      quando não conectado, continua funcionando exatamente como no
--      Módulo 5/6 (tudo cai na conta principal da loja).
--   2. Notificações push: tabela para guardar as "inscrições" de push do
--      navegador de cada usuário (cliente, vendedor ou admin) — usada
--      pela PWA para avisar sobre mudança de status de pedido/nova venda.
-- ============================================================================


-- ============================================================================
-- 1. SPLIT DE PAGAMENTO — conexão da conta Mercado Pago do vendedor
-- ============================================================================
alter table seller_profiles add column if not exists mp_user_id text;
alter table seller_profiles add column if not exists mp_access_token text;
alter table seller_profiles add column if not exists mp_refresh_token text;
alter table seller_profiles add column if not exists mp_connected_at timestamptz;

comment on column seller_profiles.mp_user_id is
  'ID da conta Mercado Pago do vendedor, obtido via OAuth (seller-connect-mercadopago.js). NULL = vendedor não conectou conta própria; os produtos dele continuam vendendo normalmente, só sem split automático de pagamento.';
comment on column seller_profiles.mp_access_token is
  'Token de acesso OAuth do vendedor no Mercado Pago. Sensível — nunca é lido pelo navegador do vendedor nem de ninguém: só a Netlify Function payment-create-preference.js usa isso, com a service_role key, para montar o split de pagamento.';

-- Nenhuma policy nova de SELECT para estas colunas sensíveis: a policy de
-- leitura já existente (seller_profiles_self_or_admin_read, Módulo 6)
-- permite ao próprio vendedor e a administradores ler a própria linha —
-- o token fica visível para o dono da conta e para quem já é admin, o que
-- é aceitável (o vendedor já é dono desse token; um admin já tem acesso
-- total à conta Mercado Pago da própria loja de qualquer forma). Não é
-- exposto ao público nem a outros vendedores/clientes.


-- ============================================================================
-- 2. PUSH_SUBSCRIPTIONS — notificações push do navegador (PWA)
-- ============================================================================
create table if not exists push_subscriptions (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  endpoint    text not null,
  keys        jsonb not null,       -- {p256dh, auth} — chaves públicas da inscrição (não secretas)
  user_agent  text default '',
  created_at  timestamptz not null default now(),
  unique (user_id, endpoint)
);

create index if not exists idx_push_subscriptions_user on push_subscriptions(user_id);

alter table push_subscriptions enable row level security;

-- Cada usuário (cliente, vendedor ou admin — todos são "auth.users")
-- gerencia só as próprias inscrições.
drop policy if exists push_subscriptions_own on push_subscriptions;
create policy push_subscriptions_own on push_subscriptions
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

comment on table push_subscriptions is
  'Inscrições de notificação push do navegador (Web Push API), usadas pela PWA. Uma linha por combinação usuário+dispositivo/navegador. As chaves aqui são públicas por natureza (é assim que Web Push funciona) — o segredo real (VAPID private key) fica só em variável de ambiente no Netlify, nunca no banco.';

-- ============================================================================
-- FIM DA MIGRATION DO MÓDULO 7
-- ============================================================================
