/**
 * ============================================================================
 * SUPERMISTO — assets/js/push-config.js  (MÓDULO 7)
 * ============================================================================
 * Chave pública VAPID usada para notificações push (Web Push API).
 *
 * Assim como a "anon key" do Supabase, esta chave é PÚBLICA POR DESENHO —
 * é assim que o protocolo Web Push funciona (a chave pública identifica
 * quem pode enviar notificação, mas só quem tem a chave PRIVADA
 * correspondente consegue realmente assinar e enviar uma notificação de
 * verdade). A chave privada nunca aparece em nenhum arquivo do site — só
 * como variável de ambiente no Netlify (ver
 * netlify/functions/push-send-notification.js).
 *
 * Gere o par de chaves com (uma vez, na sua máquina, com Node instalado):
 *   npx web-push generate-vapid-keys
 *
 * Cole a chave PÚBLICA aqui embaixo, e a chave PRIVADA + seu e-mail de
 * contato como variáveis de ambiente no Netlify:
 *   VAPID_PRIVATE_KEY, VAPID_CONTACT_EMAIL
 *
 * Enquanto o valor abaixo estiver com o placeholder, os botões de
 * "Ativar notificações" simplesmente não aparecem — o site funciona
 * normalmente sem isso.
 * ============================================================================
 */
window.VAPID_PUBLIC_KEY = "SUA_CHAVE_VAPID_PUBLICA_AQUI";
