/**
 * Lógica exclusiva da página produtos.html (catálogo).
 * Lê os parâmetros da URL (?categoria=... e/ou ?busca=...), filtra e
 * ordena os produtos vindos de assets/js/products.js e renderiza tudo
 * usando as funções utilitárias de assets/js/main.js.
 */
document.addEventListener("DOMContentLoaded", async () => {
  await smStoreInit(); // Etapa 3 — garante que os produtos/categorias já vieram do Supabase (ou do fallback)

  const params = new URLSearchParams(window.location.search);
  let currentCategory = params.get("categoria") || "";
  let currentSearch = (params.get("busca") || "").trim().toLowerCase();
  let currentSort = "relevancia";

  const grid = document.getElementById("productsGrid");
  const resultCount = document.getElementById("resultCount");
  const categoryList = document.getElementById("categoryFilterList");
  const activeChips = document.getElementById("activeChips");
  const sortSelect = document.getElementById("sortSelect");
  const pageTitle = document.getElementById("pageTitle");
  const pageSubtitle = document.getElementById("pageSubtitle");
  const breadcrumbCurrent = document.getElementById("breadcrumbCurrent");

  function countForCategory(slug) {
    return window.SUPERMISTO_PRODUCTS.filter(p => p.category === slug).length;
  }

  function renderCategoryFilters() {
    const all = window.SUPERMISTO_CATEGORIES;
    const items = [
      `<button data-slug="" class="${currentCategory === '' ? 'active' : ''}">
         <span>Todas as categorias</span><span class="count">${window.SUPERMISTO_PRODUCTS.length}</span>
       </button>`,
      ...all.map(c => `
        <button data-slug="${c.slug}" class="${currentCategory === c.slug ? 'active' : ''}">
          <span>${c.icon} ${c.name}</span><span class="count">${countForCategory(c.slug)}</span>
        </button>`)
    ];
    categoryList.innerHTML = items.join("");

    categoryList.querySelectorAll("button").forEach(btn => {
      btn.addEventListener("click", () => {
        currentCategory = btn.getAttribute("data-slug");
        syncURL();
        update();
      });
    });
  }

  function renderChips() {
    const chips = [];
    if (currentCategory) {
      const cat = getCategory(currentCategory);
      chips.push({ label: `Categoria: ${cat ? cat.name : currentCategory}`, clear: () => { currentCategory = ""; } });
    }
    if (currentSearch) {
      chips.push({ label: `Busca: "${currentSearch}"`, clear: () => { currentSearch = ""; } });
    }
    if (!chips.length) { activeChips.innerHTML = ""; return; }

    activeChips.innerHTML = chips.map((c, i) => `<button class="chip active" data-chip="${i}">${c.label} ✕</button>`).join("")
      + `<button class="chip" id="clearAllChip">Limpar tudo</button>`;

    activeChips.querySelectorAll("[data-chip]").forEach((btn, i) => {
      btn.addEventListener("click", () => { chips[i].clear(); syncURL(); update(); });
    });
    document.getElementById("clearAllChip")?.addEventListener("click", () => {
      currentCategory = ""; currentSearch = "";
      syncURL(); update();
    });
  }

  function syncURL() {
    const p = new URLSearchParams();
    if (currentCategory) p.set("categoria", currentCategory);
    if (currentSearch) p.set("busca", currentSearch);
    const qs = p.toString();
    history.replaceState(null, "", "produtos.html" + (qs ? `?${qs}` : ""));
  }

  function getFilteredProducts() {
    let list = window.SUPERMISTO_PRODUCTS.slice();
    if (currentCategory) list = list.filter(p => p.category === currentCategory);
    if (currentSearch) {
      list = list.filter(p =>
        p.name.toLowerCase().includes(currentSearch) ||
        p.shortDesc.toLowerCase().includes(currentSearch) ||
        p.description.toLowerCase().includes(currentSearch) ||
        (getCategory(p.category)?.name || "").toLowerCase().includes(currentSearch)
      );
    }
    switch (currentSort) {
      case "menor-preco": list.sort((a, b) => a.price - b.price); break;
      case "maior-preco": list.sort((a, b) => b.price - a.price); break;
      case "nome": list.sort((a, b) => a.name.localeCompare(b.name, "pt-BR")); break;
      default: break; // relevância = ordem original
    }
    return list;
  }

  function updateHeaderText() {
    if (currentCategory) {
      const cat = getCategory(currentCategory);
      pageTitle.textContent = cat ? cat.name : "Produtos";
      pageSubtitle.textContent = cat ? cat.desc : "";
      breadcrumbCurrent.textContent = cat ? cat.name : "Produtos";
    } else if (currentSearch) {
      pageTitle.textContent = `Resultados para "${currentSearch}"`;
      pageSubtitle.textContent = "Veja os produtos que encontramos para a sua busca.";
      breadcrumbCurrent.textContent = "Busca";
    } else {
      pageTitle.textContent = "Nossos produtos";
      pageSubtitle.textContent = "Explore o catálogo completo da SuperMisto e encontre o sabor certo para cada receita.";
      breadcrumbCurrent.textContent = "Produtos";
    }
  }

  function update() {
    const list = getFilteredProducts();
    updateHeaderText();
    renderCategoryFilters();
    renderChips();
    resultCount.textContent = `${list.length} produto${list.length === 1 ? "" : "s"} encontrado${list.length === 1 ? "" : "s"}`;
    renderProductGrid(grid, list);
    refreshRevealAnimations();
  }

  sortSelect.addEventListener("change", () => {
    currentSort = sortSelect.value;
    update();
  });

  update();
});
