/**
 * ============================================================================
 * SUPERMISTO — assets/js/reset-password-page.js
 * ============================================================================
 * Lógica de /reset-password.html — página única na raiz do site,
 * compartilhada pelos três tipos de conta (administrador, vendedor,
 * cliente), já que todos usam o mesmo Supabase Auth.
 *
 * Como funciona: quando a pessoa clica no link recebido por e-mail (via
 * smAdminRequestPasswordReset / smVendorRequestPasswordReset /
 * smCustomerRequestPasswordReset), o Supabase manda ela para cá com um
 * token de recuperação na própria URL. O `supabase-js` já detecta esse
 * token sozinho ao carregar a página (comportamento padrão da biblioteca)
 * e cria uma sessão temporária só para permitir trocar a senha — por
 * isso não pedimos a senha atual aqui, só a nova senha duas vezes.
 *
 * Depois de trocar a senha com sucesso, verificamos em qual das três
 * tabelas (admin_profiles, seller_profiles, customers) o ID da pessoa
 * aparece, e mandamos ela direto para o painel/portal/conta certos —
 * sem precisar logar de novo, porque a sessão da recuperação já vira uma
 * sessão normal depois da troca de senha.
 * ============================================================================
 */
document.addEventListener("DOMContentLoaded", async () => {
  await smStoreInit();

  const introEl = document.getElementById("resetIntro");
  const errorEl = document.getElementById("resetError");
  const successEl = document.getElementById("resetSuccess");
  const formEl = document.getElementById("resetForm");
  const linksEl = document.getElementById("resetLinks");

  function showError(msg) {
    errorEl.textContent = msg;
    errorEl.style.display = "block";
  }

  const client = window.smSupabaseReady ? await window.smSupabaseReady : null;
  if (!client) {
    introEl.textContent = "";
    showError("O backend ainda não está configurado neste site. Fale com a loja para redefinir sua senha.");
    return;
  }

  const session = await smDetectRecoverySession(client);

  if (!session) {
    introEl.textContent = "";
    showError(
      "Este link de redefinição é inválido ou já expirou. Volte para a tela de login e clique em " +
      '"Esqueci minha senha" para receber um novo link.'
    );
    linksEl.style.display = "block";
    return;
  }

  introEl.textContent = "Escolha uma nova senha para a sua conta.";
  formEl.style.display = "block";

  formEl.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorEl.style.display = "none";
    successEl.style.display = "none";

    const newPass = document.getElementById("newPassword").value;
    const confirmPass = document.getElementById("confirmPassword").value;

    if (newPass.length < 6) {
      showError("A senha precisa ter pelo menos 6 caracteres.");
      return;
    }
    if (newPass !== confirmPass) {
      showError("As duas senhas não são iguais.");
      return;
    }

    const btn = document.getElementById("resetSubmitBtn");
    btn.disabled = true;
    btn.textContent = "Salvando...";

    const { error } = await client.auth.updateUser({ password: newPass });

    if (error) {
      showError(error.message || "Não foi possível trocar a senha. Tente pedir um novo link.");
      btn.disabled = false;
      btn.textContent = "Salvar nova senha";
      return;
    }

    formEl.style.display = "none";
    successEl.textContent = "Senha atualizada com sucesso! Redirecionando...";
    successEl.style.display = "block";

    const destination = await smResolveAccountDestination(client, session.user.id);
    setTimeout(() => {
      window.location.href = destination;
    }, 1500);
  });
});

// ---------------------------------------------------------------------------
// Detecta a sessão de recuperação de senha, cobrindo os dois formatos que
// o Supabase Auth pode usar para o link do e-mail:
//
//   1. Fluxo "implicit" (mais comum em projetos mais antigos): o token
//      vem no HASH da URL — #access_token=...&refresh_token=...&type=recovery
//      O supabase-js detecta isso sozinho ao carregar (detectSessionInUrl,
//      ligado por padrão) e dispara o evento "PASSWORD_RECOVERY".
//
//   2. Fluxo "PKCE" (padrão em projetos mais novos do Supabase — como o
//      formato de chave "sb_publishable_..."): o token vem como
//      ?code=xxxxxxxx na URL. Depende de trocar esse código por uma
//      sessão de verdade — o supabase-js v2 também faz isso sozinho na
//      maioria das versões, mas aqui chamamos explicitamente
//      exchangeCodeForSession() como reforço, caso a detecção automática
//      não tenha rodado a tempo.
//
// Também escreve pistas no console (F12 → Console) para facilitar
// diagnosticar em produção se o link ainda assim não funcionar.
// ---------------------------------------------------------------------------
async function smDetectRecoverySession(client) {
  console.info("SuperMisto: verificando link de recuperação de senha...");
  console.info("SuperMisto: URL atual —", window.location.href);

  // 1) Já existe uma sessão? (a detecção automática pode ter rodado antes
  // deste script terminar de carregar)
  let session = (await client.auth.getSession()).data.session;
  if (session) {
    console.info("SuperMisto: sessão de recuperação já estava ativa.");
    return session;
  }

  // 2) Fluxo PKCE — tenta trocar o "?code=" explicitamente.
  const codeParam = new URLSearchParams(window.location.search).get("code");
  if (codeParam) {
    console.info("SuperMisto: encontrado parâmetro ?code= na URL, trocando por uma sessão...");
    try {
      const { data, error } = await client.auth.exchangeCodeForSession(codeParam);
      if (error) {
        console.error("SuperMisto: falha ao trocar o código de recuperação por uma sessão.", error);
      } else if (data && data.session) {
        console.info("SuperMisto: sessão criada com sucesso via código PKCE.");
        return data.session;
      }
    } catch (err) {
      console.error("SuperMisto: erro inesperado ao processar o código de recuperação.", err);
    }
  }

  // 3) Fluxo implicit — escuta o evento PASSWORD_RECOVERY (ou qualquer
  // sessão que apareça), dando um tempo generoso para o supabase-js
  // terminar de processar o hash da URL sozinho.
  const hasImplicitHash = window.location.hash.indexOf("access_token=") !== -1;
  if (hasImplicitHash) {
    console.info("SuperMisto: encontrado #access_token= na URL (fluxo implicit), aguardando o Supabase processar...");
  }

  session = await new Promise((resolve) => {
    const timeout = setTimeout(() => resolve(null), 5000);
    const { data: sub } = client.auth.onAuthStateChange((event, newSession) => {
      console.info("SuperMisto: evento de autenticação recebido —", event);
      if (event === "PASSWORD_RECOVERY" || newSession) {
        clearTimeout(timeout);
        sub?.subscription?.unsubscribe();
        resolve(newSession);
      }
    });
  });

  if (session) {
    console.info("SuperMisto: sessão de recuperação detectada com sucesso.");
  } else {
    console.warn(
      "SuperMisto: não foi possível detectar nenhuma sessão de recuperação nesta URL. " +
      "Confira se a URL de redirecionamento (" + window.location.origin + "/reset-password.html) " +
      "está cadastrada em Supabase → Authentication → URL Configuration → Redirect URLs."
    );
  }

  return session;
}

// Descobre em qual tabela (admin_profiles / seller_profiles / customers) o
// usuário aparece, para mandar ele para a área certa depois de trocar a
// senha. Se não encontrar em nenhuma (caso raro), volta para a Home.
async function smResolveAccountDestination(client, userId) {
  try {
    const { data: admin } = await client.from("admin_profiles").select("id").eq("id", userId).maybeSingle();
    if (admin) return "admin/dashboard.html";
  } catch {
    // tabela pode não existir ainda em instalações mais antigas — segue tentando as outras
  }
  try {
    const { data: seller } = await client.from("seller_profiles").select("id").eq("id", userId).maybeSingle();
    if (seller) return "vendedor/dashboard.html";
  } catch {
    // idem
  }
  try {
    const { data: customer } = await client.from("customers").select("id").eq("id", userId).maybeSingle();
    if (customer) return "minha-conta.html";
  } catch {
    // idem
  }
  return "index.html";
}
