/**
 * ============================================================================
 * SUPERMISTO — assets/js/push-notifications.js  (MÓDULO 7)
 * ============================================================================
 * Assina/cancela notificações push no navegador do usuário logado
 * (cliente ou vendedor — qualquer `auth.users`) e guarda a inscrição na
 * tabela push_subscriptions (RLS: cada usuário só mexe na própria).
 *
 * Usa `window.smSupabase` (já carregado por supabase-client.js) e exige
 * que `window.VAPID_PUBLIC_KEY` esteja preenchido (assets/js/push-config.js)
 * — sem isso, smPushIsAvailable() retorna false e a interface não deve
 * nem mostrar a opção de ativar notificações.
 * ============================================================================
 */

function smPushIsAvailable() {
  return (
    "serviceWorker" in navigator &&
    "PushManager" in window &&
    !!window.VAPID_PUBLIC_KEY &&
    window.VAPID_PUBLIC_KEY !== "SUA_CHAVE_VAPID_PUBLICA_AQUI"
  );
}

function smPushPermission() {
  if (!("Notification" in window)) return "unsupported";
  return Notification.permission; // "granted" | "denied" | "default"
}

function smUrlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}

// swPath: caminho do service worker relativo à página atual (ex.:
// "service-worker.js" no site público, "../service-worker.js" se chamado
// de dentro de /vendedor). Cada área da PWA registra o próprio worker.
async function smPushSubscribe(swPath, client, userId) {
  if (!smPushIsAvailable()) {
    return { ok: false, error: "Notificações push não estão configuradas neste site." };
  }
  try {
    const reg = await navigator.serviceWorker.register(swPath);
    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      return { ok: false, error: "Permissão de notificação não concedida." };
    }

    const subscription = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: smUrlBase64ToUint8Array(window.VAPID_PUBLIC_KEY),
    });

    const raw = subscription.toJSON();
    const { error } = await client.from("push_subscriptions").upsert(
      {
        user_id: userId,
        endpoint: raw.endpoint,
        keys: raw.keys,
        user_agent: navigator.userAgent,
      },
      { onConflict: "user_id,endpoint" }
    );
    if (error) throw error;

    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message || String(err) };
  }
}

async function smPushUnsubscribe(swPath, client, userId) {
  try {
    const reg = await navigator.serviceWorker.getRegistration(swPath);
    const subscription = reg ? await reg.pushManager.getSubscription() : null;
    if (subscription) {
      const endpoint = subscription.endpoint;
      await subscription.unsubscribe();
      await client.from("push_subscriptions").delete().eq("user_id", userId).eq("endpoint", endpoint);
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message || String(err) };
  }
}
