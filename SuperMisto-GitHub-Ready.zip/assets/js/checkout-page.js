document.addEventListener("DOMContentLoaded", async () => {
  await smStoreInit();
  const root = document.getElementById("checkoutRoot");

  const { items, subtotal } = smCartResolve();
  if (!items.length) {
    root.innerHTML = `
      <div class="cart-empty">
        <p>Seu carrinho está vazio.</p>
        <a href="produtos.html" class="btn btn-primary">Ver produtos</a>
      </div>
    `;
    return;
  }

  const loggedIn = await smCustomerIsLoggedIn();
  if (!loggedIn) {
    root.innerHTML = `
      <div class="account-panel" style="max-width:520px;margin:0 auto;text-align:center">
        <h2 style="margin-top:0">Entre para continuar</h2>
        <p style="color:var(--ink-soft)">
          Para finalizar sua compra e acompanhar o pedido, entre na sua conta
          ou crie uma (leva menos de um minuto).
        </p>
        <a href="minha-conta.html" class="btn btn-primary">Entrar / Criar conta</a>
      </div>
    `;
    return;
  }

  smRenderCheckoutForm(root, items, subtotal);
});

function smRenderCheckoutForm(root, items, subtotal) {
  const shipping = 0; // frete simples — cálculo real fica para uma etapa futura
  const total = subtotal + shipping;

  root.innerHTML = `
    <div class="checkout-layout">
      <form class="checkout-form-card" id="checkoutForm">
        <h2>Endereço de entrega</h2>
        <div class="checkout-grid cols-2" style="margin-bottom:14px">
          <div class="checkout-field"><label>Nome do destinatário *</label><input type="text" id="ck_name" required></div>
          <div class="checkout-field"><label>Telefone *</label><input type="text" id="ck_phone" required placeholder="(11) 99999-9999"></div>
        </div>
        <div class="checkout-grid cols-3" style="margin-bottom:14px">
          <div class="checkout-field"><label>CEP *</label><input type="text" id="ck_cep" required placeholder="00000-000"></div>
          <div class="checkout-field" style="grid-column:span 2"><label>Rua *</label><input type="text" id="ck_street" required></div>
        </div>
        <div class="checkout-grid cols-3" style="margin-bottom:14px">
          <div class="checkout-field"><label>Número *</label><input type="text" id="ck_number" required></div>
          <div class="checkout-field" style="grid-column:span 2"><label>Complemento</label><input type="text" id="ck_complement"></div>
        </div>
        <div class="checkout-grid cols-3" style="margin-bottom:14px">
          <div class="checkout-field"><label>Bairro *</label><input type="text" id="ck_neighborhood" required></div>
          <div class="checkout-field"><label>Cidade *</label><input type="text" id="ck_city" required></div>
          <div class="checkout-field"><label>Estado *</label><input type="text" id="ck_state" required maxlength="2" placeholder="SP"></div>
        </div>

        <h2>Pagamento</h2>
        <div class="checkout-field" style="margin-bottom:6px">
          <label>Forma de pagamento</label>
          <select id="ck_payment">
            <option value="pix">Pix</option>
            <option value="credit_card">Cartão de crédito</option>
            <option value="boleto">Boleto</option>
          </select>
        </div>
        <div class="notice-banner">
          ⚠️ <strong>Modo de teste ou pagamento real, dependendo da configuração da loja.</strong>
          Se um gateway de pagamento (Mercado Pago) estiver configurado, você será
          redirecionado para pagar de verdade. Caso contrário, o pedido é criado como
          "aguardando pagamento" e um administrador confirma manualmente — nenhuma
          cobrança falsa é feita em nenhum dos dois casos.
        </div>

        <div id="checkoutError" class="notice-banner" style="display:none;background:#FBEAE9;border-color:#F2C6C3;color:#B3261E"></div>

        <button type="submit" class="btn btn-primary" id="checkoutSubmitBtn" style="width:100%;justify-content:center;margin-top:6px">
          Confirmar pedido — ${formatPrice(total)}
        </button>
      </form>

      <aside class="checkout-summary">
        <h3 style="margin-top:0;font-family:var(--font-display);color:var(--purple-800)">Seu pedido</h3>
        ${items.map((i) => `<div class="checkout-order-item"><span>${i.quantity}x ${i.name}</span><span>${formatPrice(i.lineTotal)}</span></div>`).join("")}
        <div class="checkout-order-item"><span>Frete</span><span>${shipping === 0 ? "Grátis" : formatPrice(shipping)}</span></div>
        <div class="checkout-total-row"><span>Total</span><span>${formatPrice(total)}</span></div>
      </aside>
    </div>
  `;

  document.getElementById("checkoutForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const errorBox = document.getElementById("checkoutError");
    const btn = document.getElementById("checkoutSubmitBtn");
    errorBox.style.display = "none";
    btn.disabled = true;
    btn.textContent = "Enviando pedido...";

    const shippingAddress = {
      recipientName: document.getElementById("ck_name").value.trim(),
      phone: document.getElementById("ck_phone").value.trim(),
      cep: document.getElementById("ck_cep").value.trim(),
      street: document.getElementById("ck_street").value.trim(),
      number: document.getElementById("ck_number").value.trim(),
      complement: document.getElementById("ck_complement").value.trim(),
      neighborhood: document.getElementById("ck_neighborhood").value.trim(),
      city: document.getElementById("ck_city").value.trim(),
      state: document.getElementById("ck_state").value.trim().toUpperCase(),
    };

    try {
      const client = await smCustomerGetClient();
      const { data } = await client.auth.getSession();
      const token = data && data.session ? data.session.access_token : null;
      if (!token) throw new Error("Sessão expirada. Entre novamente.");

      const res = await fetch("/.netlify/functions/checkout-create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
        body: JSON.stringify({
          items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
          shippingAddress,
          shipping,
          discount: 0,
          paymentMethod: document.getElementById("ck_payment").value,
        }),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || "Não foi possível criar o pedido.");

      smCartClear();

      // (Módulo 5) Tenta redirecionar para o pagamento real (Mercado Pago).
      // Se o gateway não estiver configurado, a função responde com
      // gatewayConfigured:false e o site mostra a tela de modo de teste de
      // sempre (pagamento confirmado manualmente pelo administrador).
      btn.textContent = "Preparando pagamento...";
      try {
        const prefRes = await fetch("/.netlify/functions/payment-create-preference", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
          body: JSON.stringify({ orderId: body.orderId }),
        });
        const prefBody = await prefRes.json();
        if (prefRes.ok && prefBody.gatewayConfigured && prefBody.initPoint) {
          window.location.href = prefBody.initPoint;
          return;
        }
      } catch (prefErr) {
        console.warn("SuperMisto: não foi possível iniciar o pagamento real, seguindo em modo de teste.", prefErr);
      }

      smRenderCheckoutSuccess(document.getElementById("checkoutRoot"), body.orderNumber);
    } catch (err) {
      errorBox.textContent = err.message;
      errorBox.style.display = "block";
      btn.disabled = false;
      btn.textContent = `Confirmar pedido — ${formatPrice(total)}`;
    }
  });
}

function smRenderCheckoutSuccess(root, orderNumber) {
  root.innerHTML = `
    <div class="account-panel" style="max-width:560px;margin:0 auto;text-align:center">
      <h2 style="margin-top:0">Pedido realizado! 🎉</h2>
      <p style="font-size:1.1rem;color:var(--purple-700);font-weight:700">${orderNumber}</p>
      <p style="color:var(--ink-soft)">
        Seu pedido foi registrado como "aguardando pagamento". Assim que o
        pagamento for confirmado, você será avisado e poderá acompanhar tudo
        em "Meus pedidos".
      </p>
      <div class="notice-banner" style="text-align:left">
        ⚠️ Modo de teste: nenhuma cobrança real foi feita. A confirmação do
        pagamento neste ambiente é simulada manualmente pelo administrador.
      </div>
      <a href="minha-conta.html" class="btn btn-primary">Ver meus pedidos</a>
      <a href="produtos.html" class="btn btn-outline" style="margin-left:10px">Continuar comprando</a>
    </div>
  `;
}
