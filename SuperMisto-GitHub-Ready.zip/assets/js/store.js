/**
 * ============================================================================
 * SUPERMISTO — assets/js/store.js  (ETAPA 3)
 * ============================================================================
 * Substitui o assets/js/store-sync.js da Etapa 2 (que lia dados do
 * localStorage). Agora o site público busca os dados diretamente do banco
 * de dados real (Supabase), com fallback automático e silencioso para os
 * dados de fábrica de assets/js/products.js sempre que:
 *   - o Supabase ainda não foi configurado (ver assets/js/supabase-config.js), ou
 *   - houver qualquer falha de rede/conexão no momento do carregamento.
 *
 * Isso cumpre o requisito de "tratar problemas de conexão sem quebrar o
 * site": o pior cenário possível é o visitante ver o catálogo da Etapa 1
 * (sempre correto, sempre embutido no próprio site), nunca uma tela quebrada.
 *
 * COMO USAR EM CADA PÁGINA PÚBLICA:
 *   1. Inclua, nesta ordem, no <body>:
 *        <script src="assets/js/products.js"></script>
 *        <script src="assets/js/supabase-config.js"></script>
 *        <script src="assets/js/supabase-client.js"></script>
 *        <script src="assets/js/store.js"></script>
 *        <script src="assets/js/main.js"></script>
 *        <script>algum script específico da página</script>
 *   2. No script específico da página, troque
 *        document.addEventListener("DOMContentLoaded", () => { ...renderiza... });
 *      por
 *        document.addEventListener("DOMContentLoaded", async () => {
 *          await smStoreInit();
 *          ...renderiza... (window.SUPERMISTO_PRODUCTS etc. já estarão prontos)
 *        });
 * ============================================================================
 */

let smStoreInitPromise = null;

function smStoreInit() {
  if (!smStoreInitPromise) smStoreInitPromise = smStoreInitOnce();
  return smStoreInitPromise;
}

async function smStoreInitOnce() {
  window.SUPERMISTO_BANNERS = window.SUPERMISTO_BANNERS || [];
  window.SUPERMISTO_SETTINGS = window.SUPERMISTO_SETTINGS || null;
  window.SM_DATA_SOURCE = "fabrica"; // "fabrica" (products.js) ou "supabase"

  const client = await (window.smSupabaseReady || Promise.resolve(null));
  if (!client) {
    return { source: "fabrica" };
  }

  try {
    const [{ data: categories, error: catErr }, { data: products, error: prodErr }, { data: banners, error: banErr }, { data: settingsRows, error: setErr }, { data: sellers }] =
      await Promise.all([
        client.from("categories").select("*").order("sort_order", { ascending: true }),
        client.from("products").select("*").order("created_at", { ascending: true }),
        client.from("banners").select("*").eq("active", true).order("sort_order", { ascending: true }),
        client.from("settings").select("*").eq("id", 1).limit(1),
        client.from("seller_profiles").select("id, store_name").eq("status", "active"),
      ]);

    if (catErr || prodErr) {
      throw catErr || prodErr;
    }

    if (Array.isArray(categories) && categories.length) {
      window.SUPERMISTO_CATEGORIES = categories
        .filter((c) => c.active !== false)
        .map(smMapCategoryFromDB);
    }

    if (Array.isArray(products) && products.length) {
      window.SUPERMISTO_PRODUCTS = products.map(smMapProductFromDB);
    }

    window.SUPERMISTO_BANNERS = Array.isArray(banners) ? banners.map(smMapBannerFromDB) : [];

    // Módulo 6 — mapa {seller_id: nome da loja} para exibir "Vendido por"
    // nos produtos de marketplace. Só inclui vendedores ativos; se a
    // consulta falhar (ex.: tabela ainda não existe, projeto sem
    // Módulo 6 aplicado), simplesmente fica vazio sem quebrar nada.
    window.SUPERMISTO_SELLERS = {};
    (Array.isArray(sellers) ? sellers : []).forEach((s) => { window.SUPERMISTO_SELLERS[s.id] = s.store_name; });

    if (!setErr && Array.isArray(settingsRows) && settingsRows[0]) {
      window.SUPERMISTO_SETTINGS = smMapSettingsFromDB(settingsRows[0]);
    }

    window.SM_DATA_SOURCE = "supabase";
    return { source: "supabase" };
  } catch (err) {
    console.warn("SuperMisto: não foi possível carregar dados do Supabase, usando dados de fábrica.", err);
    window.SM_DATA_SOURCE = "fabrica";
    return { source: "fabrica", error: err };
  }
}

// ---------------------------------------------------------------------------
// Conversão entre o formato de linha do banco (snake_case) e o formato de
// objeto já usado por todo o front-end público desde a Etapa 1 (camelCase).
// Mantendo essa camada de tradução aqui, main.js/produtos-page.js/
// product-detail.js não precisaram ser reescritos — continuam recebendo
// exatamente o mesmo "formato de produto" de sempre.
// ---------------------------------------------------------------------------
function smMapProductFromDB(row) {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    price: Number(row.price),
    salePrice: row.sale_price !== null && row.sale_price !== undefined ? Number(row.sale_price) : undefined,
    weight: row.weight || "",
    unit: row.unit || "",
    shortDesc: row.short_desc || "",
    description: row.description || "",
    emoji: row.emoji || "🌶️",
    image: row.image || undefined,
    images: row.images || [],
    available: row.available !== false,
    featured: !!row.featured,
    isNew: !!row.is_new,
    isKit: !!row.is_kit,
    recommended: !!row.recommended,
    buyLink: row.buy_link || "#",
    whatsappMessage: row.whatsapp_message || undefined,
    trackStock: !!row.track_stock,
    stockQuantity: row.stock_quantity || 0,
    sellerId: row.seller_id || null,
  };
}

function smMapCategoryFromDB(row) {
  return {
    slug: row.slug,
    name: row.name,
    icon: row.icon || "⭐",
    desc: row.description || "",
    image: row.image || undefined,
    bg: row.bg || "#F0E4F7",
    fg: row.fg || "#3A1150",
    active: row.active !== false,
  };
}

function smMapBannerFromDB(row) {
  return {
    id: row.id,
    title: row.title || "",
    subtitle: row.subtitle || "",
    button: row.button || "",
    link: row.link || "#",
    image: row.image || undefined,
    active: !!row.active,
    order: row.sort_order || 0,
  };
}

function smMapSettingsFromDB(row) {
  return {
    whatsapp: row.whatsapp || "",
    whatsappMessage: row.whatsapp_message || "",
    email: row.email || "",
    instagram: row.instagram || "#",
    facebook: row.facebook || "#",
  };
}
