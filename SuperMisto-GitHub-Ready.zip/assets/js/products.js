/**
 * ============================================================================
 * SUPERMISTO — DADOS CENTRALIZADOS DE PRODUTOS E CATEGORIAS
 * ============================================================================
 *
 * ESTE É O ÚNICO ARQUIVO QUE DEVE SER EDITADO PARA:
 *   - adicionar produtos
 *   - editar produtos (nome, preço, descrição, foto, categoria, peso...)
 *   - remover produtos
 *   - adicionar/editar categorias
 *
 * Nenhuma outra página ou arquivo contém dados fixos de produtos.
 * Todas as páginas (Home, Produtos, Produto, Busca) leem estes arrays
 * e renderizam o HTML dinamicamente via assets/js/main.js.
 *
 * QUANDO A ÁREA ADMINISTRATIVA (/admin) FOR CRIADA (Etapa 2+ do PROJETO.md),
 * este arquivo poderá ser substituído por uma chamada a uma API / banco de
 * dados que devolva exatamente este mesmo formato de objeto. Por isso a
 * estrutura de cada campo foi mantida simples e previsível.
 *
 * IMAGENS: como esta etapa não usa fotografias reais dos produtos, cada
 * produto tem um "emoji" e uma cor de fundo ("mediaBg"/"mediaFg") usados
 * para montar um cartão ilustrativo consistente com a identidade roxa da
 * marca. Quando houver fotos reais, basta adicionar um campo "image" com
 * o caminho do arquivo (ex: "assets/img/produtos/alho.jpg") — o código em
 * main.js já está preparado para usar "image" no lugar do emoji quando
 * o campo existir (ver função productMediaHTML).
 * ============================================================================
 */

// ----------------------------------------------------------------------------
// CATEGORIAS
// ----------------------------------------------------------------------------
// slug      -> usado nas URLs (produtos.html?categoria=slug)
// name      -> nome exibido
// icon      -> emoji usado nos cartões de categoria
// desc      -> frase curta exibida no cartão da categoria
// bg / fg   -> cores do ícone (usam os tokens definidos em style.css)
const CATEGORIES = [
  { slug: "temperos",   name: "Temperos",           icon: "🌿", desc: "Sabor no dia a dia",        bg: "#F0E4F7", fg: "#3A1150" },
  { slug: "conservas",  name: "Conservas",           icon: "🫙", desc: "Tradição em conserva",       bg: "#F3ECE1", fg: "#7E2E1F" },
  { slug: "pimentas",   name: "Pimentas",            icon: "🌶️", desc: "Para quem gosta de picar",   bg: "#FBEAE6", fg: "#A6402C" },
  { slug: "molhos",     name: "Molhos",              icon: "🥫", desc: "Molhos selecionados",         bg: "#F0E4F7", fg: "#6B2F91" },
  { slug: "ervas",      name: "Ervas e Especiarias", icon: "🍃", desc: "Direto do campo",             bg: "#E9F1E7", fg: "#4B7A4E" },
  { slug: "kits",       name: "Kits",                icon: "📦", desc: "Combinações prontas",         bg: "#FBF1DF", fg: "#B7883C" },
  { slug: "chas",       name: "Chás",                icon: "☕", desc: "Momentos de pausa",           bg: "#E9F1E7", fg: "#4B7A4E" },
  { slug: "outros",     name: "Outros produtos",     icon: "⭐", desc: "Novidades da SuperMisto",     bg: "#F0E4F7", fg: "#3A1150" },
];

// ----------------------------------------------------------------------------
// PRODUTOS
// ----------------------------------------------------------------------------
// id          -> identificador único (usado na URL produto.html?id=...)
// slug        -> versão amigável do nome, usada só como referência
// name        -> nome exibido
// category    -> slug de uma categoria acima
// price       -> número (em reais), ex: 12.9
// weight      -> texto livre, ex: "100g", "250ml", "Kit com 3"
// shortDesc   -> descrição curta (cartões)
// description -> descrição longa (página do produto)
// emoji       -> ilustração do cartão enquanto não há fotos reais
// featured    -> true = aparece na seção "Produtos em destaque" da Home
// isNew       -> true = recebe selo "Novidade"
// isKit       -> true = recebe selo "Kit"
// buyLink     -> link externo de compra (Shopee, WhatsApp, etc). Use "#"
//                como placeholder até existir o link real.
const PRODUCTS = [
  // ---------------- TEMPEROS ----------------
  { id: "alho-desidratado", name: "Alho Desidratado", category: "temperos", price: 9.9, weight: "100g",
    shortDesc: "Alho selecionado, moído na hora certa.", 
    description: "Alho desidratado e moído, ideal para temperar carnes, molhos, arroz e legumes. Prático para o dia a dia, sem perder o sabor marcante do alho fresco.",
    emoji: "🧄", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "cebola-desidratada", name: "Cebola Desidratada", category: "temperos", price: 8.9, weight: "100g",
    shortDesc: "Cebola em flocos, sabor concentrado.",
    description: "Cebola desidratada em flocos, perfeita para dar sabor e aroma a molhos, sopas, carnes e receitas assadas.",
    emoji: "🧅", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cebola-roxa-desidratada", name: "Cebola Roxa Desidratada", category: "temperos", price: 10.9, weight: "100g",
    shortDesc: "Toque adocicado e cor marcante.",
    description: "Cebola roxa desidratada, com sabor levemente adocicado. Ótima em saladas, molhos frios e pratos que pedem um toque especial.",
    emoji: "🧅", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cominho-em-grao", name: "Cominho em Grão", category: "temperos", price: 11.9, weight: "80g",
    shortDesc: "Aroma marcante para pratos especiais.",
    description: "Cominho em grão selecionado, ideal para temperar carnes, feijão, arroz e receitas com influência árabe e mexicana.",
    emoji: "🌰", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "cominho-em-po", name: "Cominho em Pó", category: "temperos", price: 10.9, weight: "80g",
    shortDesc: "Prático, moído na medida certa.",
    description: "Cominho moído, pronto para usar. Sabor terroso e aromático, essencial em diversas receitas do dia a dia.",
    emoji: "🌰", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "pimenta-do-reino", name: "Pimenta-do-Reino Moída", category: "temperos", price: 12.9, weight: "60g",
    shortDesc: "O clássico que não pode faltar.",
    description: "Pimenta-do-reino moída na hora, com aroma intenso e picância equilibrada. Indispensável na cozinha brasileira.",
    emoji: "⚫", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "oregano", name: "Orégano Selecionado", category: "temperos", price: 7.9, weight: "50g",
    shortDesc: "Perfeito para massas e pizzas.",
    description: "Orégano selecionado e seco naturalmente, com aroma intenso. Combina com massas, pizzas, saladas e molhos.",
    emoji: "🌿", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "chimichurri", name: "Chimichurri SuperMisto", category: "temperos", price: 14.9, weight: "80g",
    shortDesc: "Blend pronto para churrasco.",
    description: "Mistura de ervas e temperos no estilo chimichurri, pronta para uso em carnes grelhadas e churrascos.",
    emoji: "🌶️", featured: false, isNew: true, isKit: false, buyLink: "#" },

  { id: "colorau", name: "Colorau", category: "temperos", price: 8.5, weight: "100g",
    shortDesc: "Cor e sabor tradicionais.",
    description: "Colorau tradicional, usado para dar cor e um sabor suave a arroz, feijão, carnes e ensopados.",
    emoji: "🟠", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "curcuma", name: "Cúrcuma (Açafrão-da-Terra)", category: "temperos", price: 11.5, weight: "80g",
    shortDesc: "Cor dourada e toque especial.",
    description: "Cúrcuma moída, também conhecida como açafrão-da-terra. Dá cor dourada e sabor suave a arroz, carnes e sopas.",
    emoji: "🟡", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "lemon-pepper", name: "Lemon Pepper", category: "temperos", price: 13.9, weight: "80g",
    shortDesc: "Cítrico e apimentado.",
    description: "Blend de pimenta com raspas de limão, ideal para frango, peixes e carnes grelhadas.",
    emoji: "🍋", featured: true, isNew: true, isKit: false, buyLink: "#" },

  // ---------------- CONSERVAS ----------------
  { id: "pepino-conserva", name: "Pepino em Conserva", category: "conservas", price: 15.9, weight: "300g",
    shortDesc: "Crocante e equilibrado.",
    description: "Pepinos selecionados, em conserva no ponto certo de acidez e crocância. Ótimo para sanduíches e petiscos.",
    emoji: "🥒", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "cenoura-conserva", name: "Cenoura em Conserva", category: "conservas", price: 13.9, weight: "300g",
    shortDesc: "Clássico da mesa brasileira.",
    description: "Cenoura em conserva, cortada e temperada, pronta para acompanhar refeições ou compor petiscos.",
    emoji: "🥕", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "batatinha-conserva", name: "Batatinha em Conserva", category: "conservas", price: 14.9, weight: "300g",
    shortDesc: "Pequenas, saborosas, práticas.",
    description: "Batatinhas em conserva, prontas para salpicões, saladas e petiscos do dia a dia.",
    emoji: "🥔", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "alho-conserva", name: "Alho em Conserva", category: "conservas", price: 16.9, weight: "250g",
    shortDesc: "Sabor suave e prático de usar.",
    description: "Dentes de alho em conserva, com sabor mais suave que o alho fresco. Prático para usar direto na receita.",
    emoji: "🧄", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cebola-conserva", name: "Cebola em Conserva", category: "conservas", price: 13.5, weight: "250g",
    shortDesc: "Toque ácido e crocante.",
    description: "Cebola em conserva, ideal para saladas, sanduíches e pratos que pedem um toque ácido.",
    emoji: "🧅", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "pimentas-conserva", name: "Pimentas em Conserva", category: "conservas", price: 17.9, weight: "250g",
    shortDesc: "Picância na medida.",
    description: "Seleção de pimentas em conserva, para quem gosta de dar um toque picante às refeições.",
    emoji: "🌶️", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "beterraba-conserva", name: "Beterraba em Conserva", category: "conservas", price: 14.5, weight: "300g",
    shortDesc: "Cor viva, sabor adocicado.",
    description: "Beterraba em conserva, com sabor levemente adocicado. Ótima para saladas e acompanhamentos.",
    emoji: "🔴", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "mix-legumes-conserva", name: "Mix de Legumes em Conserva", category: "conservas", price: 16.9, weight: "300g",
    shortDesc: "Praticidade em um único vidro.",
    description: "Mix de legumes selecionados em conserva, prático para completar refeições e saladas.",
    emoji: "🥗", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "azeitonas", name: "Azeitonas Selecionadas", category: "conservas", price: 18.9, weight: "250g",
    shortDesc: "Clássicas em qualquer ocasião.",
    description: "Azeitonas selecionadas, ideais para petiscos, saladas e receitas do dia a dia.",
    emoji: "🫒", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "cogumelos-conserva", name: "Cogumelos em Conserva", category: "conservas", price: 19.9, weight: "250g",
    shortDesc: "Textura e sabor especiais.",
    description: "Cogumelos em conserva, prontos para saladas, molhos e pratos quentes.",
    emoji: "🍄", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "milho-conserva", name: "Milho em Conserva", category: "conservas", price: 9.9, weight: "300g",
    shortDesc: "Doce e versátil.",
    description: "Milho em conserva, prático para saladas, pipoca gourmet, tortas e acompanhamentos.",
    emoji: "🌽", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "tomate-seco", name: "Tomate Seco", category: "conservas", price: 22.9, weight: "200g",
    shortDesc: "Sabor concentrado e intenso.",
    description: "Tomate seco em azeite, com sabor concentrado. Ótimo em antepastos, massas, saladas e petiscos.",
    emoji: "🍅", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "antepasto-supermisto", name: "Antepasto SuperMisto", category: "conservas", price: 21.9, weight: "250g",
    shortDesc: "Combinação pronta para servir.",
    description: "Antepasto com seleção de legumes e temperos, pronto para servir com torradas e pães.",
    emoji: "🫙", featured: false, isNew: true, isKit: false, buyLink: "#" },

  // ---------------- MOLHOS E PIMENTAS ----------------
  { id: "molho-pimenta-tradicional", name: "Molho de Pimenta Tradicional", category: "molhos", price: 15.9, weight: "150ml",
    shortDesc: "Picância clássica e equilibrada.",
    description: "Molho de pimenta no estilo tradicional, com picância equilibrada para acompanhar carnes, feijão e petiscos.",
    emoji: "🥫", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "molho-pimenta-defumado", name: "Molho de Pimenta Defumado", category: "molhos", price: 17.9, weight: "150ml",
    shortDesc: "Toque defumado marcante.",
    description: "Molho de pimenta com toque defumado, ideal para churrascos e carnes grelhadas.",
    emoji: "🥫", featured: false, isNew: true, isKit: false, buyLink: "#" },

  { id: "molho-barbecue", name: "Molho Barbecue SuperMisto", category: "molhos", price: 16.9, weight: "200ml",
    shortDesc: "Doce, defumado e encorpado.",
    description: "Molho barbecue encorpado, com equilíbrio entre doce e defumado. Combina com carnes, frango e sanduíches.",
    emoji: "🥫", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "pimenta-biquinho", name: "Pimenta Biquinho", category: "pimentas", price: 18.9, weight: "200g",
    shortDesc: "Docinha e levemente picante.",
    description: "Pimenta biquinho em conserva, com sabor adocicado e leve picância. Ótima para petiscos e taças de recepção.",
    emoji: "🌶️", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "pimenta-dedo-de-moca", name: "Pimenta Dedo-de-Moça", category: "pimentas", price: 17.9, weight: "200g",
    shortDesc: "Picância marcante e aromática.",
    description: "Pimenta dedo-de-moça selecionada, ideal para molhos, refogados e pratos que pedem mais ardência.",
    emoji: "🌶️", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "pimenta-malagueta", name: "Pimenta Malagueta", category: "pimentas", price: 16.9, weight: "150g",
    shortDesc: "Para quem gosta de sentir o ardor.",
    description: "Pimenta malagueta em conserva, bem picante, tradicional na culinária brasileira.",
    emoji: "🌶️", featured: false, isNew: false, isKit: false, buyLink: "#" },

  // ---------------- ERVAS E ESPECIARIAS ----------------
  { id: "manjericao-seco", name: "Manjericão Seco", category: "ervas", price: 8.9, weight: "30g",
    shortDesc: "Aroma fresco para molhos.",
    description: "Manjericão seco, com aroma marcante, ideal para molhos de tomate, massas e pizzas.",
    emoji: "🌱", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "louro-folha", name: "Folha de Louro", category: "ervas", price: 7.5, weight: "20g",
    shortDesc: "Essencial em caldos e feijão.",
    description: "Folhas de louro selecionadas, usadas para aromatizar caldos, feijão, carnes e ensopados.",
    emoji: "🍃", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "salsa-desidratada", name: "Salsa Desidratada", category: "ervas", price: 7.9, weight: "30g",
    shortDesc: "Frescor em qualquer prato.",
    description: "Salsa desidratada, prática para finalizar pratos com frescor e cor.",
    emoji: "🌿", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "alecrim", name: "Alecrim Seco", category: "ervas", price: 9.5, weight: "30g",
    shortDesc: "Perfume marcante e rústico.",
    description: "Alecrim seco, com aroma intenso, ótimo para carnes assadas, batatas e pães.",
    emoji: "🌿", featured: false, isNew: false, isKit: false, buyLink: "#" },

  // ---------------- KITS ----------------
  { id: "kit-churrasco", name: "Kit Churrasco SuperMisto", category: "kits", price: 49.9, weight: "Kit com 4 itens",
    shortDesc: "Tudo para o churrasco perfeito.",
    description: "Kit com sal grosso temperado, chimichurri, pimenta-do-reino e molho barbecue — tudo o que você precisa para um churrasco completo.",
    emoji: "📦", featured: true, isNew: false, isKit: true, buyLink: "#" },

  { id: "kit-temperos-basicos", name: "Kit Temperos Básicos", category: "kits", price: 34.9, weight: "Kit com 5 itens",
    shortDesc: "Os essenciais da cozinha.",
    description: "Kit com alho, cebola, cominho, orégano e pimenta-do-reino — a base para o dia a dia na cozinha.",
    emoji: "📦", featured: true, isNew: false, isKit: true, buyLink: "#" },

  { id: "kit-conservas-selecionadas", name: "Kit Conservas Selecionadas", category: "kits", price: 44.9, weight: "Kit com 3 itens",
    shortDesc: "Trio pronto para petiscar.",
    description: "Kit com pepino, azeitonas e tomate seco — combinação pronta para receber visitas ou petiscar em casa.",
    emoji: "📦", featured: false, isNew: true, isKit: true, buyLink: "#" },

  // ---------------- CHÁS ----------------
  { id: "cha-camomila", name: "Chá de Camomila", category: "chas", price: 12.9, weight: "50g",
    shortDesc: "Clássico para relaxar.",
    description: "Flores de camomila selecionadas, ideais para um chá calmante ao final do dia.",
    emoji: "🌼", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cha-erva-doce", name: "Chá de Erva-Doce", category: "chas", price: 11.9, weight: "50g",
    shortDesc: "Sabor suave e adocicado.",
    description: "Erva-doce selecionada, com sabor suave, tradicional após as refeições.",
    emoji: "🌿", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cha-hortela", name: "Chá de Hortelã", category: "chas", price: 11.9, weight: "40g",
    shortDesc: "Refrescante em qualquer hora.",
    description: "Folhas de hortelã selecionadas, para um chá refrescante, quente ou gelado.",
    emoji: "🌱", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cha-capim-cidreira", name: "Chá de Capim-Cidreira", category: "chas", price: 10.9, weight: "40g",
    shortDesc: "Aroma cítrico e suave.",
    description: "Capim-cidreira selecionado, ideal para um chá calmante com toque cítrico.",
    emoji: "🌾", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cha-hibisco", name: "Chá de Hibisco", category: "chas", price: 13.9, weight: "50g",
    shortDesc: "Cor viva, sabor marcante.",
    description: "Flores de hibisco selecionadas, para um chá de cor vibrante e sabor levemente ácido.",
    emoji: "🌺", featured: true, isNew: false, isKit: false, buyLink: "#" },

  { id: "cha-boldo", name: "Chá de Boldo", category: "chas", price: 10.9, weight: "40g",
    shortDesc: "Tradicional depois das refeições.",
    description: "Folhas de boldo selecionadas, tradicionalmente usadas após refeições mais pesadas.",
    emoji: "🍃", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cha-verde", name: "Chá Verde", category: "chas", price: 14.9, weight: "50g",
    shortDesc: "Leve e equilibrado.",
    description: "Chá verde selecionado, com sabor leve e equilibrado para o dia a dia.",
    emoji: "🍵", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cha-preto", name: "Chá Preto", category: "chas", price: 13.9, weight: "50g",
    shortDesc: "Encorpado e aromático.",
    description: "Chá preto selecionado, encorpado e aromático, ótimo puro ou com leite.",
    emoji: "🍵", featured: false, isNew: false, isKit: false, buyLink: "#" },

  { id: "cha-maca-canela", name: "Chá de Maçã com Canela", category: "chas", price: 14.9, weight: "50g",
    shortDesc: "Aconchegante e adocicado.",
    description: "Blend de maçã com canela, para um chá aconchegante e aromático.",
    emoji: "🍎", featured: true, isNew: true, isKit: false, buyLink: "#" },

  { id: "cha-morango", name: "Chá de Morango", category: "chas", price: 14.9, weight: "50g",
    shortDesc: "Doce e perfumado.",
    description: "Blend saborizado de morango, para um chá doce e perfumado.",
    emoji: "🍓", featured: false, isNew: true, isKit: false, buyLink: "#" },

  { id: "cha-maracuja", name: "Chá de Maracujá", category: "chas", price: 14.9, weight: "50g",
    shortDesc: "Calmante e saboroso.",
    description: "Blend saborizado de maracujá, conhecido por seu efeito calmante e sabor agradável.",
    emoji: "🧡", featured: false, isNew: false, isKit: false, buyLink: "#" },
];

// Torna os dados acessíveis globalmente (usados por assets/js/main.js e páginas)
window.SUPERMISTO_CATEGORIES = CATEGORIES;
window.SUPERMISTO_PRODUCTS = PRODUCTS;
