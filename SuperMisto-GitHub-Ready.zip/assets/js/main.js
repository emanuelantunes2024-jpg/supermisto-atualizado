/**
 * ============================================================================
 * SUPERMISTO — main.js
 * ============================================================================
 * Lógica compartilhada por TODAS as páginas:
 *   - injeta o cabeçalho (header) e rodapé (footer) a partir de um único lugar
 *   - controla o menu mobile
 *   - controla o formulário de busca do cabeçalho
 *   - funções utilitárias de renderização de cartões (categoria e produto),
 *     reaproveitadas pela Home, pela página de Produtos e pela Busca.
 *
 * Cada página específica (home.js, produtos-page.js, product-detail.js,
 * contato.js) cuida apenas do que é exclusivo daquela página e usa as
 * funções utilitárias definidas aqui.
 * ============================================================================
 */

const WHATSAPP_NUMBER = "5500000000000"; // TODO: substituir pelo número real do WhatsApp da SuperMisto
const WHATSAPP_MESSAGE = "Olá! Vim pelo site da SuperMisto e gostaria de saber mais sobre os produtos.";

// A partir da Etapa 2, se o administrador salvar dados em "Configurações"
// (/admin/configuracoes.html), assets/js/store-sync.js carrega esses dados
// em window.SUPERMISTO_SETTINGS ANTES deste arquivo rodar. Se existirem,
// eles têm prioridade sobre os valores fixos acima. Se não existirem
// (ou o navegador não tiver os dados do painel), os valores fixos acima
// continuam sendo usados normalmente — o site nunca fica quebrado.
function currentSettings() {
  return (window.SUPERMISTO_SETTINGS && typeof window.SUPERMISTO_SETTINGS === "object")
    ? window.SUPERMISTO_SETTINGS
    : {};
}

function whatsappLink(customMessage) {
  const s = currentSettings();
  const number = s.whatsapp || WHATSAPP_NUMBER;
  const msg = encodeURIComponent(customMessage || s.whatsappMessage || WHATSAPP_MESSAGE);
  return `https://wa.me/${number}?text=${msg}`;
}

// ----------------------------------------------------------------------------
// ÍCONES (inline SVG, sem dependências externas)
// ----------------------------------------------------------------------------
const ICONS = {
  search: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  cart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>`,
  menu: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/></svg>`,
  close: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="6" y1="18" x2="18" y2="6"/></svg>`,
  arrow: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`,
  leaf: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 5.5 0 8.5 -2 3-4.5 3.5-8 3.5"/><path d="M2 21c0-3 1.85-5.36 5.08-6"/></svg>`,
  whatsapp: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 2C6.477 2 2 6.477 2 12c0 1.9.529 3.68 1.446 5.196L2 22l4.94-1.412A9.94 9.94 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2zm0 18a7.94 7.94 0 0 1-4.267-1.24l-.306-.183-3.02.863.83-2.94-.2-.312A7.94 7.94 0 0 1 4 12c0-4.411 3.589-8 8-8s8 3.589 8 8-3.589 8-8 8z"/></svg>`,
  instagram: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>`,
  facebook: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>`,
  mail: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>`,
  pin: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>`,
  leafBadge: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22c6-2 9-6 9-13a1 1 0 0 0-1-1c-7 0-11 3-13 9"/><path d="M12 22c-6-2-9-6-9-13a1 1 0 0 1 1-1c3 0 5 .6 7 2"/></svg>`,
  box: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21 8-9-5-9 5 9 5 9-5Z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/></svg>`,
  shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/></svg>`,
  truck: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="6" width="14" height="11"/><path d="M15 10h4l3 3v4h-7z"/><circle cx="5.5" cy="19.5" r="1.5"/><circle cx="17.5" cy="19.5" r="1.5"/></svg>`,
  user: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
};

// ----------------------------------------------------------------------------
// HEADER / FOOTER
// ----------------------------------------------------------------------------
const NAV_LINKS = [
  { href: "index.html", label: "Início", key: "home" },
  { href: "produtos.html", label: "Produtos", key: "produtos" },
  { href: "categorias.html", label: "Categorias", key: "categorias" },
  { href: "sobre.html", label: "Sobre", key: "sobre" },
  { href: "contato.html", label: "Contato", key: "contato" },
];

function renderHeader(activeKey) {
  const el = document.getElementById("site-header");
  if (!el) return;

  el.innerHTML = `
    <header class="site-header">
      <div class="container">
        <div class="header-inner">
          <a href="index.html" class="brand" aria-label="SuperMisto — página inicial">
            <img src="assets/img/logo-purple.png" alt="SuperMisto">
          </a>

          <nav class="main-nav" aria-label="Navegação principal">
            ${NAV_LINKS.map(l => `<a href="${l.href}" class="${l.key === activeKey ? 'active' : ''}">${l.label}</a>`).join("")}
          </nav>

          <div class="header-actions">
            <a href="${whatsappLink()}" target="_blank" rel="noopener" class="icon-btn" aria-label="Falar no WhatsApp" title="WhatsApp">
              ${ICONS.whatsapp}
            </a>
            <a href="minha-conta.html" class="icon-btn" aria-label="Minha conta" title="Minha conta">
              ${ICONS.user}
            </a>
            <a href="carrinho.html" class="icon-btn cart-btn" id="headerCartBtn" aria-label="Carrinho de compras" title="Carrinho">
              ${ICONS.cart}
              <span class="cart-badge" id="headerCartBadge" hidden>0</span>
            </a>
            <button class="icon-btn menu-toggle" id="menuToggleBtn" aria-label="Abrir menu" aria-expanded="false">
              ${ICONS.menu}
            </button>
          </div>
        </div>

        <div class="header-search-row">
          <form class="search-form" id="headerSearchForm" role="search">
            <input type="search" name="busca" placeholder="Buscar temperos, conservas, pimentas..." aria-label="Buscar produtos">
            <button type="submit" aria-label="Buscar">${ICONS.search}</button>
          </form>
        </div>
      </div>
    </header>

    <div class="mobile-nav" id="mobileNav">
      <div class="mobile-nav-backdrop" id="mobileNavBackdrop"></div>
      <div class="mobile-nav-panel">
        <div class="mobile-nav-top">
          <img src="assets/img/logo-purple.png" alt="SuperMisto" style="height:32px">
          <button class="icon-btn" id="mobileNavCloseBtn" aria-label="Fechar menu">${ICONS.close}</button>
        </div>

        <form class="search-form" id="mobileSearchForm" role="search">
          <input type="search" name="busca" placeholder="Buscar produtos..." aria-label="Buscar produtos">
          <button type="submit" aria-label="Buscar">${ICONS.search}</button>
        </form>

        <ul class="mobile-nav-links">
          ${NAV_LINKS.map(l => `<li><a href="${l.href}">${l.label} ${ICONS.arrow}</a></li>`).join("")}
        </ul>

        <div class="mobile-nav-social">
          <a href="${whatsappLink()}" target="_blank" rel="noopener" class="icon-btn" aria-label="WhatsApp">${ICONS.whatsapp}</a>
          <a href="${currentSettings().instagram || '#'}" target="_blank" rel="noopener" class="icon-btn" aria-label="Instagram">${ICONS.instagram}</a>
          <a href="${currentSettings().facebook || '#'}" target="_blank" rel="noopener" class="icon-btn" aria-label="Facebook">${ICONS.facebook}</a>
        </div>
      </div>
    </div>
  `;

  // Mobile menu toggle
  const mobileNav = document.getElementById("mobileNav");
  const openBtn = document.getElementById("menuToggleBtn");
  const closeBtn = document.getElementById("mobileNavCloseBtn");
  const backdrop = document.getElementById("mobileNavBackdrop");

  function openNav() {
    mobileNav.classList.add("is-open");
    document.body.classList.add("nav-open");
    openBtn.setAttribute("aria-expanded", "true");
  }
  function closeNav() {
    mobileNav.classList.remove("is-open");
    document.body.classList.remove("nav-open");
    openBtn.setAttribute("aria-expanded", "false");
  }
  openBtn?.addEventListener("click", openNav);
  closeBtn?.addEventListener("click", closeNav);
  backdrop?.addEventListener("click", closeNav);

  // Search forms -> redirect to produtos.html?busca=...
  [document.getElementById("headerSearchForm"), document.getElementById("mobileSearchForm")].forEach(form => {
    form?.addEventListener("submit", (e) => {
      e.preventDefault();
      const q = new FormData(form).get("busca")?.toString().trim();
      window.location.href = "produtos.html" + (q ? `?busca=${encodeURIComponent(q)}` : "");
    });
  });

  // Contador do carrinho (Módulo 4) — atualiza sozinho quando o carrinho muda
  smUpdateCartBadge();
  document.addEventListener("sm-cart-changed", smUpdateCartBadge);
}

function smUpdateCartBadge() {
  const badge = document.getElementById("headerCartBadge");
  if (!badge || typeof smCartCount !== "function") return;
  const count = smCartCount();
  badge.textContent = count > 99 ? "99+" : String(count);
  badge.hidden = count === 0;
}

function renderFooter() {
  const el = document.getElementById("site-footer");
  if (!el) return;
  const year = new Date().getFullYear();
  const s = currentSettings();
  const igLink = s.instagram || "#";
  const fbLink = s.facebook || "#";
  const emailAddr = s.email || "contato@supermisto.com.br";

  el.innerHTML = `
    <footer class="site-footer">
      <div class="container footer-top">
        <div class="footer-grid">
          <div class="footer-brand">
            <img src="assets/img/logo-white.png" alt="SuperMisto">
            <p>Temperos, conservas, molhos e muito sabor para transformar a sua cozinha no dia a dia.</p>
            <div class="footer-social">
              <a href="${whatsappLink()}" target="_blank" rel="noopener" class="icon-btn" style="border-color:rgba(255,255,255,.2);color:#fff" aria-label="WhatsApp">${ICONS.whatsapp}</a>
              <a href="${igLink}" target="_blank" rel="noopener" class="icon-btn" style="border-color:rgba(255,255,255,.2);color:#fff" aria-label="Instagram">${ICONS.instagram}</a>
              <a href="${fbLink}" target="_blank" rel="noopener" class="icon-btn" style="border-color:rgba(255,255,255,.2);color:#fff" aria-label="Facebook">${ICONS.facebook}</a>
            </div>
          </div>

          <div class="footer-col">
            <h4>Institucional</h4>
            <ul>
              <li><a href="index.html">Início</a></li>
              <li><a href="sobre.html">Sobre a SuperMisto</a></li>
              <li><a href="contato.html">Contato</a></li>
              <li><a href="produtos.html">Todos os produtos</a></li>
            </ul>
          </div>

          <div class="footer-col" id="footerCategories">
            <h4>Categorias</h4>
            <ul></ul>
          </div>

          <div class="footer-col">
            <h4>Contato</h4>
            <ul>
              <li><a href="${whatsappLink()}" target="_blank" rel="noopener">WhatsApp</a></li>
              <li><a href="mailto:${emailAddr}">${emailAddr}</a></li>
              <li><a href="contato.html">Fale conosco</a></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="container">
        <div class="footer-bottom">
          <span>&copy; ${year} SuperMisto. Todos os direitos reservados.</span>
          <div class="legal-links">
            <a href="privacidade.html">Política de Privacidade</a>
            <a href="termos.html">Termos de Uso</a>
          </div>
        </div>
      </div>
    </footer>

    <a href="${whatsappLink()}" target="_blank" rel="noopener" class="whatsapp-float" aria-label="Falar no WhatsApp">
      ${ICONS.whatsapp}
    </a>
  `;

  const catList = el.querySelector("#footerCategories ul");
  if (catList && window.SUPERMISTO_CATEGORIES) {
    catList.innerHTML = window.SUPERMISTO_CATEGORIES.slice(0, 6)
      .map(c => `<li><a href="produtos.html?categoria=${c.slug}">${c.name}</a></li>`)
      .join("");
  }
}

// ----------------------------------------------------------------------------
// RENDERIZAÇÃO DE CARTÕES (usada em várias páginas)
// ----------------------------------------------------------------------------
function getCategory(slug) {
  return (window.SUPERMISTO_CATEGORIES || []).find(c => c.slug === slug);
}

function formatPrice(value) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

// Monta o "cartão visual" do produto. Se o produto tiver um campo "image"
// (caminho de arquivo), a foto real é usada. Caso contrário, usa-se o emoji
// ilustrativo sobre um fundo colorido — assim o layout nunca fica quebrado
// enquanto não há fotografias reais dos produtos.
function productMediaHTML(product) {
  const cat = getCategory(product.category);
  if (product.image) {
    return `<img src="${product.image}" alt="${product.name}" loading="lazy" style="width:100%;height:100%;object-fit:cover">`;
  }
  return `<span class="ring"></span><span class="emoji">${product.emoji || "🌶️"}</span>`;
}

function productBadgeHTML(product) {
  // Etapa 2: produto marcado como indisponível pelo painel (/admin) tem
  // prioridade visual sobre os outros selos.
  if (product.available === false) return `<span class="product-badge badge-off">Indisponível</span>`;
  if (product.isKit) return `<span class="product-badge badge-kit">Kit</span>`;
  if (product.isNew) return `<span class="product-badge badge-novidade">Novidade</span>`;
  if (product.featured) return `<span class="product-badge badge-destaque">Destaque</span>`;
  return "";
}

// Etapa 2: se o painel salvar um "preço promocional" menor que o preço
// normal, mostra o preço original riscado ao lado do preço com desconto.
function productPriceHTML(product) {
  const hasPromo = typeof product.salePrice === "number" && product.salePrice > 0 && product.salePrice < product.price;
  if (hasPromo) {
    return `<span class="product-price">${formatPrice(product.salePrice)}</span>
            <span class="product-price-old">${formatPrice(product.price)}</span>`;
  }
  return `<span class="product-price">${formatPrice(product.price)}</span>`;
}

// Módulo 6 — "Vendido por X" quando o produto é de um vendedor do
// marketplace (product.sellerId aponta para window.SUPERMISTO_SELLERS,
// preenchido por store.js). Produtos da própria loja (sellerId null,
// incluindo os 48 originais) não mostram nada aqui.
function productSellerTagHTML(product) {
  const sellers = window.SUPERMISTO_SELLERS || {};
  if (!product.sellerId || !sellers[product.sellerId]) return "";
  return `<span class="product-seller-tag">Vendido por ${sellers[product.sellerId]}</span>`;
}

function productCardHTML(product) {
  const cat = getCategory(product.category);
  const unavailable = product.available === false;
  const outOfStock = product.trackStock && (product.stockQuantity || 0) <= 0;
  const canBuy = !unavailable && !outOfStock;
  return `
    <article class="product-card${unavailable ? " is-unavailable" : ""}" data-reveal>
      <a href="produto.html?id=${product.id}" style="display:block">
        <div class="product-media" style="--media-bg:${cat?.bg || '#F0E4F7'}">
          ${productBadgeHTML(product)}
          ${productMediaHTML(product)}
        </div>
      </a>
      <div class="product-body">
        <span class="product-cat">${cat?.name || product.category || 'Sem categoria'}</span>
        <h3><a href="produto.html?id=${product.id}">${product.name}</a></h3>
        <p class="product-desc">${product.shortDesc}</p>
        ${productSellerTagHTML(product)}
        <div class="product-meta">
          ${productPriceHTML(product)}
          <span class="product-weight">${product.weight}</span>
        </div>
        <div class="product-actions">
          <a href="produto.html?id=${product.id}" class="btn btn-outline btn-sm">Ver produto</a>
          ${canBuy
            ? `<button class="btn btn-primary btn-sm" data-add-to-cart="${product.id}">${ICONS.cart} Adicionar</button>`
            : `<span class="btn btn-outline btn-sm" style="opacity:.6;pointer-events:none">${outOfStock ? "Sem estoque" : "Indisponível"}</span>`}
        </div>
      </div>
    </article>
  `;
}

function renderProductGrid(container, products) {
  if (!container) return;
  if (!products.length) {
    container.innerHTML = `
      <div class="empty-state">
        ${ICONS.search}
        <p><strong>Nenhum produto encontrado.</strong><br>Tente buscar por outro termo ou explore nossas categorias.</p>
      </div>`;
    return;
  }
  container.innerHTML = products.map(productCardHTML).join("");
}

function categoryCardHTML(cat) {
  return `
    <a href="produtos.html?categoria=${cat.slug}" class="category-card" data-reveal style="--cat-bg:${cat.bg};--cat-fg:${cat.fg}">
      <span class="icon-wrap">${cat.icon}</span>
      <h3>${cat.name}</h3>
      <p>${cat.desc}</p>
      <span class="go">Ver produtos ${ICONS.arrow}</span>
    </a>
  `;
}

function renderCategoryGrid(container, categories) {
  if (!container) return;
  container.innerHTML = categories.map(categoryCardHTML).join("");
}

// ----------------------------------------------------------------------------
// BANNERS (Etapa 2 — dados gerenciados em /admin/banners.html)
// ----------------------------------------------------------------------------
// Só é chamada quando existe pelo menos um banner ativo salvo pelo painel
// administrativo (ver window.SUPERMISTO_BANNERS em assets/js/store-sync.js).
function bannerCardHTML(banner) {
  const hasImage = !!banner.image;
  return `
    <a href="${banner.link || '#'}" class="promo-banner" data-reveal
       style="${hasImage ? `--banner-img:url('${banner.image}')` : ""}">
      ${!hasImage ? `<div class="promo-banner-fallback"></div>` : ""}
      <div class="promo-banner-content">
        ${banner.title ? `<h3>${banner.title}</h3>` : ""}
        ${banner.subtitle ? `<p>${banner.subtitle}</p>` : ""}
        ${banner.button ? `<span class="btn btn-primary btn-sm">${banner.button}</span>` : ""}
      </div>
    </a>
  `;
}

function renderBannerStrip(container, banners) {
  if (!container) return;
  container.innerHTML = banners.map(bannerCardHTML).join("");
}

// ----------------------------------------------------------------------------
// REVEAL ON SCROLL
// ----------------------------------------------------------------------------
function initRevealAnimations() {
  const items = document.querySelectorAll("[data-reveal]");
  if (!items.length) return;
  if (!("IntersectionObserver" in window)) {
    items.forEach(i => i.classList.add("is-visible"));
    return;
  }
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  items.forEach(i => obs.observe(i));
}

// Re-observa elementos adicionados dinamicamente depois do load inicial
function refreshRevealAnimations() {
  initRevealAnimations();
}

// ----------------------------------------------------------------------------
// INIT GLOBAL (roda em toda página que inclui este arquivo)
// ----------------------------------------------------------------------------
document.addEventListener("DOMContentLoaded", async () => {
  // Etapa 3: aguarda os dados do Supabase (categorias/config usadas no
  // header e no footer) antes de desenhar — com fallback automático para
  // os dados de fábrica se o Supabase não estiver configurado/acessível.
  // smStoreInit() é seguro chamar em mais de um script: a primeira
  // chamada busca os dados, as demais reaproveitam o mesmo resultado.
  if (typeof smStoreInit === "function") {
    await smStoreInit();
  }

  const activeKey = document.body.getAttribute("data-page") || "";
  renderHeader(activeKey);
  renderFooter();
  initRevealAnimations();
});

