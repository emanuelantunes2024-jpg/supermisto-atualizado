document.addEventListener("DOMContentLoaded", async () => {
  await smStoreInit();
  smRenderCartPage();
  document.addEventListener("sm-cart-changed", smRenderCartPage);
});

function smRenderCartPage() {
  const layout = document.getElementById("cartLayout");
  const notice = document.getElementById("cartRemovedNotice");
  const { items, removed, subtotal } = smCartResolve();

  if (removed.length) {
    notice.style.display = "block";
    notice.textContent = `Alguns itens foram removidos do seu carrinho porque não estão mais disponíveis (${removed.join(", ")}).`;
  } else {
    notice.style.display = "none";
  }

  if (!items.length) {
    layout.innerHTML = `
      <div class="cart-empty">
        <p>Seu carrinho está vazio.</p>
        <a href="produtos.html" class="btn btn-primary">Ver produtos</a>
      </div>
    `;
    return;
  }

  layout.innerHTML = `
    <div class="cart-items">
      ${items.map(smCartItemRowHTML).join("")}
    </div>
    <aside class="cart-summary">
      <h3>Resumo</h3>
      <div class="cart-summary-row"><span>Subtotal</span><strong>${formatPrice(subtotal)}</strong></div>
      <p class="form-hint">Frete e total final são calculados na próxima etapa.</p>
      <a href="checkout.html" class="btn btn-primary" style="width:100%;justify-content:center">Ir para o checkout</a>
      <a href="produtos.html" class="btn btn-outline" style="width:100%;justify-content:center;margin-top:10px">Continuar comprando</a>
    </aside>
  `;

  layout.querySelectorAll("[data-cart-remove]").forEach((btn) =>
    btn.addEventListener("click", () => smCartRemove(btn.getAttribute("data-cart-remove")))
  );
  layout.querySelectorAll("[data-cart-qty-input]").forEach((input) =>
    input.addEventListener("change", () => smCartSetQuantity(input.getAttribute("data-cart-qty-input"), input.value))
  );
}

function smCartItemRowHTML(item) {
  const media = item.image ? `<img src="${item.image}" alt="">` : (item.emoji || "🌶️");
  return `
    <div class="cart-item">
      <div class="cart-item-media">${media}</div>
      <div class="cart-item-info">
        <a href="produto.html?id=${item.productId}"><strong>${item.name}</strong></a>
        <span class="cart-item-weight">${item.weight || ""}</span>
        <span class="cart-item-price">${formatPrice(item.unitPrice)} / un.</span>
      </div>
      <input type="number" min="1" value="${item.quantity}" data-cart-qty-input="${item.productId}" class="cart-item-qty">
      <div class="cart-item-total">${formatPrice(item.lineTotal)}</div>
      <button class="icon-btn-sm" data-cart-remove="${item.productId}" aria-label="Remover">🗑️</button>
    </div>
  `;
}
