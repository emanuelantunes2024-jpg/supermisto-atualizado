document.addEventListener("DOMContentLoaded", async () => {
  await smStoreInit();
  const root = document.getElementById("accountRoot");
  const loggedIn = await smCustomerIsLoggedIn();

  if (!loggedIn) {
    smRenderLoginSignup(root);
  } else {
    await smRenderAccountDashboard(root);
  }
});

function smRenderLoginSignup(root) {
  root.innerHTML = `
    <div class="account-tabs">
      <button class="btn btn-primary btn-sm" id="tabLogin">Entrar</button>
      <button class="btn btn-outline btn-sm" id="tabSignup">Criar conta</button>
    </div>

    <div class="account-panel" id="loginPanel">
      <h2 style="margin-top:0">Entrar</h2>
      <div id="loginError" class="notice-banner" style="display:none"></div>
      <div id="resetSentMsg" class="notice-banner" style="display:none;background:#E8F3E7;border-color:#B9DAB8;color:#3D7A45">
        Se esse e-mail tiver uma conta na SuperMisto, enviamos um link para
        redefinir a senha. Confira sua caixa de entrada (e o spam).
      </div>
      <form id="loginForm">
        <div class="checkout-field" style="margin-bottom:14px">
          <label>E-mail</label>
          <input type="email" id="li_email" required>
        </div>
        <div class="checkout-field" style="margin-bottom:14px">
          <label>Senha</label>
          <input type="password" id="li_pass" required>
        </div>
        <button type="submit" class="btn btn-primary">Entrar</button>
        <button type="button" class="admin-forgot-link" id="forgotPasswordBtn" style="margin-top:12px">Esqueci minha senha</button>
      </form>
    </div>

    <div class="account-panel" id="signupPanel" style="display:none">
      <h2 style="margin-top:0">Criar conta</h2>
      <div id="signupError" class="notice-banner" style="display:none"></div>
      <div id="signupSuccess" class="notice-banner" style="display:none;background:#E8F3E7;border-color:#B9DAB8;color:#3D7A45"></div>
      <form id="signupForm">
        <div class="checkout-grid cols-2" style="margin-bottom:14px">
          <div class="checkout-field"><label>Nome</label><input type="text" id="su_name" required></div>
          <div class="checkout-field"><label>Telefone</label><input type="text" id="su_phone" placeholder="(11) 99999-9999"></div>
        </div>
        <div class="checkout-field" style="margin-bottom:14px"><label>E-mail</label><input type="email" id="su_email" required></div>
        <div class="checkout-field" style="margin-bottom:14px"><label>Senha (mínimo 6 caracteres)</label><input type="password" id="su_pass" required minlength="6"></div>
        <button type="submit" class="btn btn-primary">Criar conta</button>
      </form>
    </div>
  `;

  const loginPanel = document.getElementById("loginPanel");
  const signupPanel = document.getElementById("signupPanel");
  document.getElementById("tabLogin").addEventListener("click", () => {
    loginPanel.style.display = "";
    signupPanel.style.display = "none";
  });
  document.getElementById("tabSignup").addEventListener("click", () => {
    loginPanel.style.display = "none";
    signupPanel.style.display = "";
  });

  document.getElementById("loginForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const errorBox = document.getElementById("loginError");
    errorBox.style.display = "none";
    const result = await smCustomerLogin(document.getElementById("li_email").value.trim(), document.getElementById("li_pass").value);
    if (result.ok) {
      window.location.reload();
    } else {
      errorBox.textContent = result.error;
      errorBox.style.display = "block";
    }
  });

  document.getElementById("forgotPasswordBtn").addEventListener("click", async () => {
    const email = document.getElementById("li_email").value.trim();
    const errorBox = document.getElementById("loginError");
    const sentBox = document.getElementById("resetSentMsg");
    errorBox.style.display = "none";
    sentBox.style.display = "none";

    if (!email) {
      errorBox.textContent = 'Digite seu e-mail no campo acima e clique em "Esqueci minha senha" de novo.';
      errorBox.style.display = "block";
      document.getElementById("li_email").focus();
      return;
    }

    const btn = document.getElementById("forgotPasswordBtn");
    btn.disabled = true;
    const result = await smCustomerRequestPasswordReset(email);
    btn.disabled = false;

    if (result.ok) {
      sentBox.style.display = "block";
    } else {
      errorBox.textContent = result.error;
      errorBox.style.display = "block";
    }
  });

  document.getElementById("signupForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const errorBox = document.getElementById("signupError");
    const successBox = document.getElementById("signupSuccess");
    errorBox.style.display = "none";
    successBox.style.display = "none";

    const result = await smCustomerSignUp(
      document.getElementById("su_name").value.trim(),
      document.getElementById("su_email").value.trim(),
      document.getElementById("su_pass").value,
      document.getElementById("su_phone").value.trim()
    );

    if (!result.ok) {
      errorBox.textContent = result.error;
      errorBox.style.display = "block";
      return;
    }
    if (result.needsEmailConfirmation) {
      successBox.textContent = "Conta criada! Confirme seu e-mail para poder entrar (verifique a caixa de entrada).";
      successBox.style.display = "block";
    } else {
      window.location.reload();
    }
  });
}

async function smRenderAccountDashboard(root) {
  root.innerHTML = `<div class="admin-empty" style="background:var(--white);border-radius:var(--radius-md);padding:40px;text-align:center;color:var(--ink-soft)">Carregando sua conta...</div>`;

  const [profile, addresses, orders] = await Promise.all([
    smCustomerGetProfile(),
    smCustomerGetAddresses(),
    smCustomerGetOrders(),
  ]);

  const statusLabels = {
    aguardando_pagamento: "Aguardando pagamento",
    pagamento_aprovado: "Pagamento aprovado",
    em_preparacao: "Em preparação",
    pronto_envio: "Pronto para envio",
    enviado: "Enviado",
    entregue: "Entregue",
    cancelado: "Cancelado",
    reembolsado: "Reembolsado",
  };

  root.innerHTML = `
    <div class="account-panel">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
        <div>
          <h2 style="margin:0 0 4px">Olá, ${smEscapeHTMLPublic(profile?.name || "")}</h2>
          <p style="margin:0;color:var(--ink-soft);font-size:.9rem">${smEscapeHTMLPublic(profile?.email || "")}</p>
        </div>
        <button class="btn btn-outline btn-sm" id="logoutBtn">Sair</button>
      </div>
    </div>

    <div class="account-panel">
      <h2 style="margin-top:0">Meus pedidos</h2>
      ${orders.length
        ? orders.map(smOrderHistoryItemHTML).join("")
        : `<p style="color:var(--ink-soft)">Você ainda não fez nenhum pedido. <a href="produtos.html">Ver produtos</a></p>`}
    </div>

    <div class="account-panel">
      <h2 style="margin-top:0">Meus endereços</h2>
      <div id="addressList">
        ${addresses.length
          ? addresses.map((a) => `<div class="order-history-item"><strong>${smEscapeHTMLPublic(a.label)}</strong><br>${smEscapeHTMLPublic(a.street)}, ${smEscapeHTMLPublic(a.number)} — ${smEscapeHTMLPublic(a.city)}/${smEscapeHTMLPublic(a.state)}</div>`).join("")
          : `<p style="color:var(--ink-soft)">Nenhum endereço cadastrado ainda. Um endereço é adicionado automaticamente no seu primeiro checkout.</p>`}
      </div>
    </div>

    <div class="account-panel">
      <h2 style="margin-top:0">Notificações</h2>
      <p style="color:var(--ink-soft);font-size:.9rem;margin:0 0 12px" id="pushStatusText">Verificando disponibilidade...</p>
      <button class="btn btn-outline btn-sm" id="pushToggleBtn" style="display:none">Ativar notificações do meu pedido</button>
    </div>
  `;

  document.getElementById("logoutBtn").addEventListener("click", smCustomerLogout);

  const pushText = document.getElementById("pushStatusText");
  const pushBtn = document.getElementById("pushToggleBtn");
  if (typeof smPushIsAvailable === "function" && smPushIsAvailable()) {
    const user = await smCustomerCurrentUser();
    const permission = smPushPermission();
    pushText.textContent = permission === "granted"
      ? "Notificações ativadas neste navegador."
      : "Ative para ser avisado quando o pagamento do seu pedido for confirmado.";
    pushBtn.style.display = permission === "granted" ? "none" : "";
    pushBtn.addEventListener("click", async () => {
      pushBtn.disabled = true;
      const client = await smCustomerGetClient();
      const result = await smPushSubscribe("service-worker.js", client, user.id);
      if (result.ok) {
        smToastPublic("Notificações ativadas!");
        pushText.textContent = "Notificações ativadas neste navegador.";
        pushBtn.style.display = "none";
      } else {
        smToastPublic(result.error, "error");
        pushBtn.disabled = false;
      }
    });
  } else {
    pushText.textContent = "Notificações push ainda não estão configuradas nesta loja.";
  }

  function smOrderHistoryItemHTML(order) {
    const label = statusLabels[order.status] || order.status;
    const date = new Date(order.created_at).toLocaleDateString("pt-BR");
    const items = order.order_items || [];
    return `
      <div class="order-history-item">
        <div class="order-history-head">
          <strong>${order.order_number}</strong>
          <span class="order-status-pill">${label}</span>
        </div>
        <p style="margin:0 0 8px;color:var(--ink-soft);font-size:.85rem">${date} · ${items.length} item(ns) · ${formatPrice(order.total)}</p>
        <ul style="margin:0;padding-left:18px;font-size:.85rem;color:var(--ink-soft)">
          ${items.map((it) => `<li>${it.quantity}x ${smEscapeHTMLPublic(it.product_name)}</li>`).join("")}
        </ul>
      </div>
    `;
  }
}

function smEscapeHTMLPublic(str) {
  return (str ?? "").toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// Toast simples reaproveitado nas páginas públicas que precisam de feedback
// rápido (Módulo 7 — notificações push). Mesmo padrão visual do admin.
function smToastPublic(message, type) {
  let el = document.getElementById("smToastPublic");
  if (!el) {
    el = document.createElement("div");
    el.id = "smToastPublic";
    el.style.cssText =
      "position:fixed;bottom:22px;right:22px;z-index:200;background:var(--ink);color:#fff;padding:14px 20px;" +
      "border-radius:12px;box-shadow:var(--shadow-lg);font-size:.9rem;opacity:0;transform:translateY(10px);" +
      "transition:all .25s ease;pointer-events:none;max-width:80vw";
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.style.background = type === "error" ? "#B3261E" : "var(--ink)";
  el.style.opacity = "1";
  el.style.transform = "translateY(0)";
  clearTimeout(el._timer);
  el._timer = setTimeout(() => {
    el.style.opacity = "0";
    el.style.transform = "translateY(10px)";
  }, 3200);
}
