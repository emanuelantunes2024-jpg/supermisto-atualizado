/**
 * ============================================================================
 * SUPERMISTO — assets/js/customer-auth.js  (MÓDULO 4)
 * ============================================================================
 * Login/cadastro de CLIENTES no site público — completamente separado do
 * login de administradores (admin/assets/js/admin-auth.js). Usa o mesmo
 * Supabase Auth, mas os clientes nunca ganham uma linha em admin_profiles,
 * então sm_is_admin() (banco) sempre retorna false para eles — um cliente
 * jamais consegue acessar funções administrativas, mesmo tentando manipular
 * o token diretamente.
 *
 * Ao se cadastrar, o cliente também ganha uma linha em "customers" (nome,
 * e-mail, telefone) — necessária para endereços e pedidos.
 * ============================================================================
 */

async function smCustomerGetClient() {
  return window.smSupabaseReady ? await window.smSupabaseReady : null;
}

async function smCustomerIsLoggedIn() {
  const client = await smCustomerGetClient();
  if (!client) return false;
  const { data } = await client.auth.getSession();
  return !!(data && data.session);
}

async function smCustomerCurrentUser() {
  const client = await smCustomerGetClient();
  if (!client) return null;
  const { data } = await client.auth.getUser();
  return data ? data.user : null;
}

async function smCustomerSignUp(name, email, password, phone) {
  const client = await smCustomerGetClient();
  if (!client) return { ok: false, error: "Loja ainda não está com o backend configurado. Tente novamente mais tarde." };

  const { data, error } = await client.auth.signUp({ email, password });
  if (error) return { ok: false, error: smCustomerFriendlyAuthError(error) };

  // Cria o registro correspondente em "customers" (RLS exige auth.uid() = id,
  // então isso só funciona porque acabamos de logar como esse mesmo usuário).
  if (data.user) {
    await client.from("customers").insert({
      id: data.user.id,
      name: name || "",
      email,
      phone: phone || "",
    });
  }

  return { ok: true, session: data.session, needsEmailConfirmation: !data.session };
}

async function smCustomerLogin(email, password) {
  const client = await smCustomerGetClient();
  if (!client) return { ok: false, error: "Loja ainda não está com o backend configurado. Tente novamente mais tarde." };

  const { data, error } = await client.auth.signInWithPassword({ email, password });
  if (error) return { ok: false, error: smCustomerFriendlyAuthError(error) };
  return { ok: true, session: data.session };
}

async function smCustomerRequestPasswordReset(email) {
  const client = await smCustomerGetClient();
  if (!client) return { ok: false, error: "Loja ainda não está com o backend configurado." };

  const redirectTo = `${window.location.origin}/reset-password.html`;
  const { error } = await client.auth.resetPasswordForEmail(email, { redirectTo });
  if (error) return { ok: false, error: error.message || "Não foi possível enviar o e-mail de redefinição." };
  return { ok: true };
}

async function smCustomerLogout() {
  const client = await smCustomerGetClient();
  if (client) await client.auth.signOut();
  window.location.href = "index.html";
}

function smCustomerFriendlyAuthError(error) {
  const msg = (error && error.message) || "";
  if (msg.includes("Invalid login credentials")) return "E-mail ou senha incorretos.";
  if (msg.includes("User already registered")) return "Já existe uma conta com este e-mail. Tente entrar em vez de cadastrar.";
  if (msg.includes("Password should be")) return "A senha precisa ter pelo menos 6 caracteres.";
  return "Não foi possível concluir: " + msg;
}

// ---------------------------------------------------------------------------
// Dados do cliente logado (perfil + endereços)
// ---------------------------------------------------------------------------
async function smCustomerGetProfile() {
  const client = await smCustomerGetClient();
  const user = await smCustomerCurrentUser();
  if (!client || !user) return null;
  const { data } = await client.from("customers").select("*").eq("id", user.id).maybeSingle();
  return data;
}

async function smCustomerGetAddresses() {
  const client = await smCustomerGetClient();
  const user = await smCustomerCurrentUser();
  if (!client || !user) return [];
  const { data, error } = await client.from("addresses").select("*").eq("customer_id", user.id).order("is_default", { ascending: false });
  if (error) { console.error(error); return []; }
  return data || [];
}

async function smCustomerAddAddress(address) {
  const client = await smCustomerGetClient();
  const user = await smCustomerCurrentUser();
  if (!client || !user) return null;
  const row = Object.assign({}, address, { customer_id: user.id });
  const { data, error } = await client.from("addresses").insert(row).select().maybeSingle();
  if (error) { console.error(error); return null; }
  return data;
}

async function smCustomerGetOrders() {
  const client = await smCustomerGetClient();
  const user = await smCustomerCurrentUser();
  if (!client || !user) return [];
  const { data, error } = await client
    .from("orders")
    .select("*, order_items(*)")
    .eq("customer_id", user.id)
    .order("created_at", { ascending: false });
  if (error) { console.error(error); return []; }
  return data || [];
}
