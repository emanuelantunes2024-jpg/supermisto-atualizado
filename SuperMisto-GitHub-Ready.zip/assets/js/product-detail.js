/**
 * Lógica exclusiva da página produto.html.
 * Lê o parâmetro ?id= da URL, busca o produto correspondente em
 * assets/js/products.js e monta a página. Também mostra produtos
 * relacionados (mesma categoria).
 */
document.addEventListener("DOMContentLoaded", async () => {
  await smStoreInit(); // Etapa 3 — garante que os produtos já vieram do Supabase (ou do fallback)

  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  const root = document.getElementById("productDetailRoot");
  const relatedSection = document.getElementById("relatedSection");
  const relatedGrid = document.getElementById("relatedGrid");

  const product = window.SUPERMISTO_PRODUCTS.find(p => p.id === id);

  if (!product) {
    root.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        ${ICONS.search}
        <p><strong>Produto não encontrado.</strong><br>O produto que você procura pode ter sido removido ou o link está incorreto.</p>
        <div style="margin-top:18px"><a href="produtos.html" class="btn btn-primary">Ver todos os produtos</a></div>
      </div>`;
    relatedSection.style.display = "none";
    return;
  }

  const cat = getCategory(product.category);

  document.title = `${product.name} — SuperMisto`;
  document.getElementById("pageTitleTag").textContent = `${product.name} — SuperMisto`;
  document.getElementById("breadcrumbCategory").textContent = cat?.name || product.category || 'Sem categoria';
  document.getElementById("breadcrumbCategory").href = `produtos.html?categoria=${product.category}`;
  document.getElementById("breadcrumbProduct").textContent = product.name;

  // Etapa 2: mensagem de WhatsApp específica do produto (definida no painel)
  // tem prioridade sobre a mensagem genérica de sempre.
  const whatsMsg = product.whatsappMessage
    || `Olá! Tenho interesse no produto "${product.name}" da SuperMisto. Pode me passar mais informações?`;

  const unavailable = product.available === false;
  const outOfStock = !!product.trackStock && (product.stockQuantity || 0) <= 0;
  const hasPromo = typeof product.salePrice === "number" && product.salePrice > 0 && product.salePrice < product.price;

  root.innerHTML = `
    <div class="pd-media" style="--media-bg:${cat?.bg || '#F0E4F7'}" id="pdMainMedia">
      ${productBadgeHTML(product)}
      ${productMediaHTML(product)}
    </div>
    ${smProductGalleryHTML(product)}

    <div class="pd-info">
      <span class="product-cat">${cat?.name || product.category || 'Sem categoria'}</span>
      <h1>${product.name}</h1>
      ${productSellerTagHTML(product)}

      <div class="pd-price-row">
        ${hasPromo
          ? `<span class="pd-price">${formatPrice(product.salePrice)}</span><span class="pd-price-old">${formatPrice(product.price)}</span>`
          : `<span class="pd-price">${formatPrice(product.price)}</span>`}
        <span class="pd-weight-tag">${product.weight}</span>
      </div>

      <p class="pd-desc">${product.description}</p>

      <div class="pd-actions">
        ${outOfStock
          ? `<span class="btn btn-outline" style="pointer-events:none;opacity:.7">Sem estoque no momento</span>`
          : unavailable
          ? `<span class="btn btn-outline" style="pointer-events:none;opacity:.7">Indisponível no momento</span>`
          : `<span class="qty-stepper">
               <button type="button" data-qty-minus aria-label="Diminuir quantidade">−</button>
               <input type="number" id="pdQty" data-cart-qty value="1" min="1" ${product.trackStock ? `max="${product.stockQuantity}"` : ''} aria-label="Quantidade">
               <button type="button" data-qty-plus aria-label="Aumentar quantidade">+</button>
             </span>
             <button class="btn btn-primary" data-add-to-cart="${product.id}">${ICONS.cart} Adicionar ao carrinho</button>
             ${product.buyLink && product.buyLink !== '#' ? `<a href="${product.buyLink}" target="_blank" rel="noopener" class="btn btn-outline">Comprar na Shopee</a>` : ""}`}
        <a href="${whatsappLink(whatsMsg)}" target="_blank" rel="noopener" class="btn btn-whatsapp">
          ${ICONS.whatsapp} Falar no WhatsApp
        </a>
      </div>
      ${product.trackStock && !outOfStock && !unavailable ? `<p class="pd-stock-note">${product.stockQuantity} unidade${product.stockQuantity === 1 ? "" : "s"} em estoque</p>` : ""}

      <div class="pd-info-grid">
        <div class="pd-info-card"><span>Categoria</span><strong>${cat?.name || product.category || 'Sem categoria'}</strong></div>
        <div class="pd-info-card"><span>Peso / Quantidade</span><strong>${product.weight}</strong></div>
        <div class="pd-info-card"><span>Código</span><strong>${product.id}</strong></div>
        <div class="pd-info-card"><span>Disponibilidade</span><strong>${unavailable ? "Indisponível" : "Disponível"}</strong></div>
      </div>

      <div class="pd-future-note">
        Em breve: mais fotos, informações nutricionais, ingredientes, modo de conservação, avaliações de clientes e controle de estoque para este produto.
      </div>
    </div>
  `;

  smInitProductGallery(product);

  // Produtos relacionados (mesma categoria, excluindo o atual)
  const related = window.SUPERMISTO_PRODUCTS
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  if (related.length) {
    renderProductGrid(relatedGrid, related);
  } else {
    relatedSection.style.display = "none";
  }

  refreshRevealAnimations();
});

// ----------------------------------------------------------------------------
// GALERIA DE IMAGENS (Módulo 5) — miniaturas trocam a imagem principal
// ----------------------------------------------------------------------------
function smProductGalleryHTML(product) {
  const gallery = [product.image, ...(product.images || [])].filter(Boolean);
  if (gallery.length < 2) return ""; // sem galeria se só tem (no máximo) a imagem principal
  return `
    <div class="pd-gallery" id="pdGallery">
      ${gallery.map((src, i) => `<button type="button" class="pd-gallery-thumb${i === 0 ? " is-active" : ""}" data-gallery-src="${src}">
        <img src="${src}" alt="${product.name} — foto ${i + 1}" loading="lazy">
      </button>`).join("")}
    </div>
  `;
}

function smInitProductGallery(product) {
  const gallery = document.getElementById("pdGallery");
  const mainMedia = document.getElementById("pdMainMedia");
  if (!gallery || !mainMedia) return;

  gallery.querySelectorAll("[data-gallery-src]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const src = btn.getAttribute("data-gallery-src");
      const img = mainMedia.querySelector("img");
      if (img) {
        img.src = src;
      } else {
        // produto não tinha imagem principal (só emoji) — troca para <img>
        mainMedia.innerHTML = `${productBadgeHTML(product)}<img src="${src}" alt="${product.name}" style="width:100%;height:100%;object-fit:cover">`;
      }
      gallery.querySelectorAll(".pd-gallery-thumb").forEach((t) => t.classList.toggle("is-active", t === btn));
    });
  });
}
