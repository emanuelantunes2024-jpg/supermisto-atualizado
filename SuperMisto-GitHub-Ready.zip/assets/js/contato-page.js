/**
 * ============================================================================
 * SUPERMISTO — assets/js/contato-page.js  (MÓDULO 5)
 * ============================================================================
 * O formulário de contato agora grava a mensagem de verdade na tabela
 * "contact_messages" (Supabase) — visível para os administradores em
 * /admin/mensagens.html. Isso funciona assim que o Supabase estiver
 * configurado, sem depender de mais nada.
 *
 * Além de salvar, tenta (best-effort, "fire and forget") avisar a loja por
 * e-mail chamando a Netlify Function contact-notify-email.js. Essa parte só
 * funciona de verdade se um provedor de e-mail estiver configurado (ver
 * PROJETO.md) — se não estiver, a mensagem AINDA ASSIM foi salva e
 * aparecerá no painel, então o formulário nunca falha por causa disso.
 * ============================================================================
 */
document.addEventListener("DOMContentLoaded", async () => {
  await smStoreInit();

  const form = document.getElementById("contactForm");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const successBox = document.getElementById("formSuccess");
    const errorBox = document.getElementById("formError");
    const btn = document.getElementById("contactSubmitBtn");
    successBox.style.display = "none";
    errorBox.style.display = "none";

    const payload = {
      name: document.getElementById("nome").value.trim(),
      email: document.getElementById("email").value.trim(),
      phone: document.getElementById("telefone").value.trim(),
      message: `[${document.getElementById("assunto").value}] ${document.getElementById("mensagem").value.trim()}`,
    };

    btn.disabled = true;
    btn.textContent = "Enviando...";

    try {
      const client = await (window.smSupabaseReady || Promise.resolve(null));
      if (!client) {
        throw new Error("O backend ainda não está configurado neste site. Tente novamente mais tarde ou fale pelo WhatsApp.");
      }

      const { error } = await client.from("contact_messages").insert(payload);
      if (error) throw error;

      // Melhor esforço: tenta notificar por e-mail. Não trava nem falha o
      // formulário se isso não funcionar (ver aviso no topo do arquivo).
      fetch("/.netlify/functions/contact-notify-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }).catch(() => {});

      successBox.style.display = "block";
      form.reset();
    } catch (err) {
      errorBox.textContent = "Não foi possível enviar: " + err.message;
      errorBox.style.display = "block";
    } finally {
      btn.disabled = false;
      btn.textContent = "Enviar mensagem";
    }
  });
});
