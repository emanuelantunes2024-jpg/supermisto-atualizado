/**
 * ============================================================================
 * SUPERMISTO — assets/js/supabase-client.js (ETAPA 3)
 * ============================================================================
 * Cria um cliente Supabase compartilhado (window.smSupabase), usado tanto
 * pelo site público (assets/js/store.js) quanto pelo painel administrativo
 * (admin/assets/js/admin-data.js e admin-auth.js).
 *
 * Não usamos npm/build: a biblioteca oficial "@supabase/supabase-js" é
 * carregada via CDN (jsdelivr) diretamente no navegador, como um módulo ES.
 * Isso mantém o projeto 100% estático, sem passo de build, publicável no
 * Netlify exatamente como antes.
 *
 * Se supabase-config.js não tiver sido preenchido (ainda com os valores de
 * exemplo), window.smSupabase fica como "null" — todo o resto do código
 * (store.js e admin-data.js) sabe lidar com isso e usa os dados de fábrica
 * (assets/js/products.js) no site público, e mostra um aviso claro no painel
 * administrativo em vez de travar.
 * ============================================================================
 */
window.smSupabase = null;
window.smSupabaseReady = (async function initSupabaseClient() {
  const url = window.SUPABASE_URL;
  const key = window.SUPABASE_ANON_KEY;

  const isConfigured = url && key && url !== "SUA_URL_AQUI" && key !== "SUA_CHAVE_AQUI";
  if (!isConfigured) {
    console.info(
      "SuperMisto: Supabase ainda não configurado (assets/js/supabase-config.js). " +
      "Site público usando dados de fábrica de products.js; painel administrativo " +
      "vai avisar que precisa de configuração."
    );
    return null;
  }

  try {
    // Versão travada (não "@2" solto) — o navegador consegue guardar essa
    // biblioteca em cache de verdade entre uma página do painel e outra,
    // em vez de ter que resolver "qual é a versão mais nova" toda vez que
    // você clica em outro menu. Ajuda a navegação entre as páginas do
    // /admin a ficar mais rápida depois do primeiro carregamento.
    const { createClient } = await import("https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm");
    window.smSupabase = createClient(url, key);
    return window.smSupabase;
  } catch (err) {
    console.error("SuperMisto: não foi possível carregar a biblioteca do Supabase (sem internet?).", err);
    return null;
  }
})();
