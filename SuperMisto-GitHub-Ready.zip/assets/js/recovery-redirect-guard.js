/**
 * ============================================================================
 * SUPERMISTO — assets/js/recovery-redirect-guard.js
 * ============================================================================
 * Rede de segurança para o fluxo de "esqueci minha senha".
 *
 * O QUE ESTE ARQUIVO RESOLVE: se o painel do Supabase (Authentication →
 * URL Configuration) não tiver a URL de redirecionamento cadastrada
 * corretamente na lista de permissões, o Supabase ignora o "redirectTo"
 * que o código manda e volta para a "Site URL" padrão do projeto — que,
 * em muitos projetos, é só a raiz do site (a Home). Isso faz o link do
 * e-mail "abrir o site normalmente", sem nunca chegar em
 * /reset-password.html, mesmo com o token de recuperação preso na URL.
 *
 * Este script roda bem no início de TODA página pública (antes de
 * qualquer outro script) e verifica se a URL atual carrega um token de
 * recuperação do Supabase — nos dois formatos possíveis:
 *   - fluxo "implicit":  #access_token=...&type=recovery&...
 *   - fluxo "pkce":      ?code=...  (usado por versões mais novas do Supabase)
 *
 * Se encontrar, e a página atual NÃO for /reset-password.html, redireciona
 * na hora para lá, preservando o token — assim a pessoa sempre cai na
 * tela certa de "criar nova senha", não importa para onde o Supabase
 * decidiu mandar ela.
 *
 * Isso é só uma rede de segurança: o ideal é sempre configurar a URL de
 * redirecionamento corretamente no painel do Supabase (ver
 * supabase/README.md) — mas mesmo que isso esteja errado ou desatualizado
 * (ex.: depois de trocar de domínio), o fluxo continua funcionando.
 * ============================================================================
 */
(function () {
  var path = window.location.pathname;
  var onResetPage = /\/reset-password\.html$/.test(path) || path === "/reset-password.html";
  if (onResetPage) return;

  var hash = window.location.hash || "";
  var search = window.location.search || "";

  var hasImplicitRecoveryToken = hash.indexOf("type=recovery") !== -1 && hash.indexOf("access_token=") !== -1;
  var hasPkceCode = /[?&]code=/.test(search);
  // Alguns links do Supabase também chegam como "?type=recovery" (sem
  // hash), dependendo do template de e-mail configurado no projeto.
  var hasQueryRecoveryType = /[?&]type=recovery\b/.test(search);

  if (hasImplicitRecoveryToken || hasPkceCode || hasQueryRecoveryType) {
    var base = window.location.origin + "/reset-password.html";
    window.location.replace(base + search + hash);
  }
})();
