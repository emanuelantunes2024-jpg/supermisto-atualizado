/**
 * ============================================================================
 * SUPERMISTO — assets/js/supabase-config.js (ETAPA 3)
 * ============================================================================
 * Preencha estes dois valores com os dados do SEU projeto Supabase
 * (Supabase → seu projeto → Project Settings → API):
 *
 *   window.SUPABASE_URL      → "Project URL"     (ex: https://xxxxx.supabase.co)
 *   window.SUPABASE_ANON_KEY → a chave PÚBLICA do projeto. O Supabase usa dois
 *                               formatos, dependendo de quando o projeto foi
 *                               criado — os dois funcionam igual aqui:
 *                                 - formato novo:  "sb_publishable_..."
 *                                 - formato antigo: um token longo "eyJ..." (JWT),
 *                                   chamado de "anon public" key
 *
 * ⚠️ NÃO coloque aqui a chave SECRETA do projeto ("service_role" no formato
 * antigo, ou "sb_secret_..." no formato novo). A chave pública É PARA SER
 * PÚBLICA — foi desenhada pelo próprio Supabase para funcionar em sites
 * estáticos como este, protegida pelas regras de RLS (Row Level Security)
 * definidas em supabase/schema.sql. A chave secreta só é usada dentro de
 * netlify/functions/ (Node, do lado do servidor), nunca aqui.
 *
 * Enquanto os campos abaixo estiverem com os valores de exemplo
 * ("SUA_URL_AQUI" / "SUA_CHAVE_AQUI"), o site funciona normalmente usando
 * os dados de fábrica de assets/js/products.js — ele NUNCA quebra por falta
 * de configuração (ver assets/js/store.js e admin/assets/js/admin-data.js).
 * ============================================================================
 */
window.SUPABASE_URL = "https://bzcqlkvnzeszyjjgaapb.supabase.co";
window.SUPABASE_ANON_KEY = "sb_publishable_PpjMfsHuBYcKaQlAFwVOgw_-VD1WE-j";
