/**
 * ============================================================================
 * SUPERMISTO — assets/js/pwa-register.js  (MÓDULO 7)
 * ============================================================================
 * Registra o Service Worker do site público (torna o site instalável e
 * funcional offline). Roda em toda página pública. Falha silenciosamente
 * em navegadores sem suporte (ex.: navegadores muito antigos) — o site
 * continua funcionando normalmente, só sem os recursos de PWA.
 * ============================================================================
 */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/service-worker.js").catch((err) => {
      console.warn("SuperMisto: não foi possível registrar o Service Worker.", err);
    });
  });
}
