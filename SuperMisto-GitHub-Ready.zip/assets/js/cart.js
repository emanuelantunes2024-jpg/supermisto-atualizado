/**
 * ============================================================================
 * SUPERMISTO — assets/js/cart.js  (MÓDULO 4)
 * ============================================================================
 * Carrinho de compras do site público.
 *
 * DECISÃO DE ARQUITETURA: o carrinho vive inteiramente no localStorage do
 * navegador (client-side), não em uma tabela do banco. Só quando o cliente
 * finaliza a compra (checkout) é que os dados são enviados para o servidor
 * — nesse momento, a Netlify Function checkout-create-order.js valida tudo
 * de novo no banco (estoque, disponibilidade, preço) antes de criar o
 * pedido de verdade. Isso significa:
 *   - Navegar e montar o carrinho funciona mesmo sem login.
 *   - Preço mostrado no carrinho é só uma prévia — o valor que realmente
 *     conta é sempre recalculado no servidor no momento do checkout, então
 *     ninguém consegue "editar" o preço no navegador para pagar menos.
 *   - Não existe condição de corrida de estoque enquanto a pessoa só está
 *     navegando — a verificação de estoque de verdade acontece uma vez,
 *     de forma atômica, dentro de sm_create_order() no banco.
 *
 * Formato salvo em localStorage (chave "sm_cart"):
 *   [{ "productId": "alho-desidratado", "quantity": 2 }, ...]
 * ============================================================================
 */

const SM_CART_KEY = "sm_cart";

function smCartRead() {
  try {
    const raw = window.localStorage.getItem(SM_CART_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list : [];
  } catch (err) {
    console.warn("SuperMisto: carrinho corrompido no localStorage, reiniciando.", err);
    return [];
  }
}

function smCartWrite(list) {
  try {
    window.localStorage.setItem(SM_CART_KEY, JSON.stringify(list));
    smCartNotify();
    return true;
  } catch (err) {
    console.error("SuperMisto: não foi possível salvar o carrinho.", err);
    return false;
  }
}

// Permite que o header (contador do carrinho) e a página do carrinho se
// atualizem automaticamente quando o conteúdo muda, sem precisar recarregar.
function smCartNotify() {
  document.dispatchEvent(new CustomEvent("sm-cart-changed"));
}

function smCartAdd(productId, quantity) {
  const qty = Math.max(1, parseInt(quantity, 10) || 1);
  const list = smCartRead();
  const existing = list.find((i) => i.productId === productId);
  if (existing) {
    existing.quantity += qty;
  } else {
    list.push({ productId, quantity: qty });
  }
  return smCartWrite(list);
}

function smCartSetQuantity(productId, quantity) {
  const qty = parseInt(quantity, 10);
  let list = smCartRead();
  if (!qty || qty <= 0) {
    list = list.filter((i) => i.productId !== productId);
  } else {
    const existing = list.find((i) => i.productId === productId);
    if (existing) existing.quantity = qty;
  }
  return smCartWrite(list);
}

function smCartRemove(productId) {
  const list = smCartRead().filter((i) => i.productId !== productId);
  return smCartWrite(list);
}

function smCartClear() {
  return smCartWrite([]);
}

function smCartCount() {
  return smCartRead().reduce((sum, i) => sum + i.quantity, 0);
}

// Junta o carrinho salvo com os dados reais dos produtos (vindos de
// window.SUPERMISTO_PRODUCTS, já carregado por store.js) para exibição.
// Remove automaticamente do carrinho qualquer item cujo produto não existe
// mais ou ficou indisponível, e avisa o chamador sobre isso (para mostrar
// um aviso na tela, ex.: "Removemos X do seu carrinho: não está mais disponível").
function smCartResolve() {
  const cartList = smCartRead();
  const products = window.SUPERMISTO_PRODUCTS || [];
  const resolved = [];
  const removed = [];

  cartList.forEach((item) => {
    const product = products.find((p) => p.id === item.productId);
    if (!product || product.available === false) {
      removed.push(item.productId);
      return;
    }
    const unitPrice = typeof product.salePrice === "number" && product.salePrice > 0 ? product.salePrice : product.price;
    resolved.push({
      productId: product.id,
      name: product.name,
      image: product.image,
      emoji: product.emoji,
      weight: product.weight,
      unitPrice,
      quantity: item.quantity,
      lineTotal: Math.round(unitPrice * item.quantity * 100) / 100,
    });
  });

  if (removed.length) {
    const cleaned = cartList.filter((i) => !removed.includes(i.productId));
    smCartWrite(cleaned);
  }

  const subtotal = resolved.reduce((sum, i) => sum + i.lineTotal, 0);
  return { items: resolved, removed, subtotal: Math.round(subtotal * 100) / 100 };
}

// ---------------------------------------------------------------------------
// Delegação de clique global para qualquer botão [data-add-to-cart="ID"]
// renderizado em qualquer página (cartões de produto, página de produto).
// Funciona mesmo com conteúdo desenhado dinamicamente depois do carregamento
// da página, porque o listener fica no document, não no botão em si.
// ---------------------------------------------------------------------------
document.addEventListener("click", (e) => {
  const minus = e.target.closest("[data-qty-minus]");
  const plus = e.target.closest("[data-qty-plus]");
  if (!minus && !plus) return;
  const input = (minus || plus).closest(".qty-stepper")?.querySelector("[data-cart-qty]");
  if (!input) return;
  const max = input.max ? parseInt(input.max, 10) : Infinity;
  let val = parseInt(input.value, 10) || 1;
  val = minus ? Math.max(1, val - 1) : Math.min(max, val + 1);
  input.value = val;
});

document.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-add-to-cart]");
  if (!btn) return;
  e.preventDefault();
  const productId = btn.getAttribute("data-add-to-cart");
  const qtyInput = btn.closest("form, .pd-actions, .product-actions")?.querySelector("[data-cart-qty]");
  const qty = qtyInput ? qtyInput.value : 1;
  smCartAdd(productId, qty);

  const originalText = btn.textContent;
  btn.textContent = "Adicionado ✓";
  btn.disabled = true;
  setTimeout(() => {
    btn.textContent = originalText;
    btn.disabled = false;
  }, 1200);
});
