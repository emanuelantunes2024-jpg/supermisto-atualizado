/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/fiscal-check-status.js  (MÓDULO 6)
 * ============================================================================
 * A emissão na Focus NFe (fiscal-emit-nfe.js) é assíncrona: a resposta
 * inicial só confirma que o pedido de emissão foi aceito para
 * processamento, não que a nota já foi autorizada pela SEFAZ. Esta função
 * consulta o status atual de verdade na API da Focus NFe (nunca inventa
 * um resultado) e atualiza fiscal_documents de acordo.
 *
 * Mesmo padrão de "nunca confiar sem reconsultar" já usado em
 * payment-webhook-mercadopago.js — a diferença é que aqui a consulta é
 * feita sob demanda (o administrador clica em "Verificar status" no
 * painel), já que a Focus NFe usada em conta gratuita/homologação não
 * garante webhook configurado.
 * ============================================================================
 */

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Método não permitido" }, cors);

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const FOCUS_TOKEN = process.env.FOCUS_NFE_API_TOKEN;
  const FOCUS_ENV = process.env.FOCUS_NFE_ENVIRONMENT === "producao" ? "producao" : "homologacao";
  const FOCUS_BASE_URL = FOCUS_ENV === "producao" ? "https://api.focusnfe.com.br" : "https://homologacao.focusnfe.com.br";

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !FOCUS_TOKEN) {
    return json(501, { error: "Emissão fiscal não configurada (falta FOCUS_NFE_API_TOKEN)." }, cors);
  }

  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const callerToken = authHeader.replace(/^Bearer\s+/i, "");
  if (!callerToken) return json(401, { error: "Não autenticado." }, cors);

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };

  const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${callerToken}` },
  });
  if (!userRes.ok) return json(401, { error: "Sessão inválida ou expirada." }, cors);
  const user = await userRes.json();

  const adminCheck = await fetch(`${SUPABASE_URL}/rest/v1/admin_profiles?id=eq.${user.id}&select=id`, { headers: restHeaders });
  const adminRows = await adminCheck.json();
  if (!Array.isArray(adminRows) || !adminRows.length) {
    return json(403, { error: "Apenas administradores podem consultar o status fiscal." }, cors);
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Corpo do pedido inválido." }, cors);
  }
  const { orderId } = payload;
  if (!orderId) return json(400, { error: "orderId é obrigatório." }, cors);

  const orderRes = await fetch(`${SUPABASE_URL}/rest/v1/orders?id=eq.${orderId}&select=order_number`, { headers: restHeaders });
  const orders = await orderRes.json();
  const order = Array.isArray(orders) ? orders[0] : null;
  if (!order) return json(404, { error: "Pedido não encontrado." }, cors);

  const nfceRef = `pedido-${order.order_number}`;

  const focusRes = await fetch(`${FOCUS_BASE_URL}/v2/nfce/${encodeURIComponent(nfceRef)}`, {
    headers: { Authorization: "Basic " + Buffer.from(FOCUS_TOKEN + ":").toString("base64") },
  });
  const focusBody = await focusRes.json();
  if (!focusRes.ok) {
    return json(422, { error: "Falha ao consultar status na Focus NFe: " + (focusBody.mensagem || JSON.stringify(focusBody)) }, cors);
  }

  const statusMap = {
    autorizado: "emitida",
    processando_autorizacao: "pendente",
    erro_autorizacao: "erro",
    cancelado: "cancelada",
  };
  const status = statusMap[focusBody.status] || "pendente";

  await fetch(`${SUPABASE_URL}/rest/v1/fiscal_documents?order_id=eq.${orderId}`, {
    method: "PATCH",
    headers: restHeaders,
    body: JSON.stringify({
      status,
      numero: focusBody.numero || null,
      serie: focusBody.serie || null,
      chave_acesso: focusBody.chave_nfe || null,
      emitted_at: status === "emitida" ? new Date().toISOString() : null,
      raw_response: focusBody,
    }),
  });

  return json(200, { ok: true, status, focusResponse: focusBody }, cors);
};

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
