/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/seller-mercadopago-callback.js  (MÓDULO 7)
 * ============================================================================
 * Segundo passo do fluxo OAuth (ver seller-connect-mercadopago.js). O
 * Mercado Pago redireciona o navegador do vendedor para cá, com um
 * "code" de autorização e o "state" que geramos no passo anterior.
 *
 * Esta função troca o code por um access_token/refresh_token de verdade
 * (chamada servidor-a-servidor, usando MERCADOPAGO_CLIENT_SECRET — nunca
 * exposto ao navegador), salva na linha do vendedor em seller_profiles, e
 * redireciona o navegador de volta para o portal do vendedor com um
 * indicador de sucesso/erro na URL (o próprio front-end lê isso e mostra
 * uma mensagem — nenhum token passa pela URL de retorno).
 *
 * Variáveis de ambiente necessárias:
 *   MERCADOPAGO_CLIENT_ID, MERCADOPAGO_CLIENT_SECRET → credenciais da
 *     aplicação SuperMisto cadastrada no Mercado Pago
 *   SITE_URL → usada para montar o mesmo redirect_uri do passo anterior
 *     (o Mercado Pago exige que bata exatamente) e a URL de volta ao portal
 * ============================================================================
 */

exports.handler = async (event) => {
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const CLIENT_ID = process.env.MERCADOPAGO_CLIENT_ID;
  const CLIENT_SECRET = process.env.MERCADOPAGO_CLIENT_SECRET;
  const SITE_URL = process.env.SITE_URL;

  const backToPortal = (status, message) =>
    ({ statusCode: 302, headers: { Location: `${SITE_URL || ""}/vendedor/dashboard.html?mp=${status}&msg=${encodeURIComponent(message || "")}` }, body: "" });

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !CLIENT_ID || !CLIENT_SECRET || !SITE_URL) {
    return backToPortal("erro", "Split de pagamento não está configurado neste servidor.");
  }

  const params = event.queryStringParameters || {};
  const { code, state, error: mpError } = params;

  if (mpError) {
    return backToPortal("erro", "Autorização recusada no Mercado Pago.");
  }
  if (!code || !state) {
    return backToPortal("erro", "Retorno inválido do Mercado Pago.");
  }

  let stateData;
  try {
    stateData = JSON.parse(Buffer.from(state, "base64url").toString("utf8"));
  } catch {
    return backToPortal("erro", "Estado inválido — tente conectar novamente.");
  }
  // "state" expira em 10 minutos — evita reaproveitar um link antigo.
  if (!stateData.sellerId || Date.now() - stateData.ts > 10 * 60 * 1000) {
    return backToPortal("erro", "Link expirado — tente conectar novamente.");
  }

  const redirectUri = `${SITE_URL}/.netlify/functions/seller-mercadopago-callback`;

  const tokenRes = await fetch("https://api.mercadopago.com/oauth/token", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri,
    }),
  });
  const tokenBody = await tokenRes.json();

  if (!tokenRes.ok || !tokenBody.access_token) {
    return backToPortal("erro", tokenBody.message || "Falha ao obter autorização do Mercado Pago.");
  }

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };
  await fetch(`${SUPABASE_URL}/rest/v1/seller_profiles?id=eq.${stateData.sellerId}`, {
    method: "PATCH",
    headers: restHeaders,
    body: JSON.stringify({
      mp_user_id: String(tokenBody.user_id || ""),
      mp_access_token: tokenBody.access_token,
      mp_refresh_token: tokenBody.refresh_token || null,
      mp_connected_at: new Date().toISOString(),
    }),
  });

  return backToPortal("sucesso", "Conta Mercado Pago conectada! Suas vendas agora usam split automático de pagamento.");
};
