/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/payment-webhook-mercadopago.js  (MÓDULO 5)
 * ============================================================================
 * Recebe a notificação ("webhook"/IPN) do Mercado Pago quando o status de
 * um pagamento muda, e atualiza "payments"/"orders" de acordo.
 *
 * REGRA DE SEGURANÇA MAIS IMPORTANTE DESTE ARQUIVO: nunca confiamos no
 * status que vem dentro do corpo da notificação em si (qualquer pessoa
 * poderia forjar uma requisição parecida). A notificação só nos diz "o
 * pagamento X mudou" — em seguida, SEMPRE buscamos o pagamento de verdade
 * direto na API do Mercado Pago (autenticada com o nosso token), e é só
 * esse resultado que atualiza o pedido. O mesmo padrão de "nunca confiar
 * no cliente" já usado em checkout-create-order.js.
 *
 * Configure a URL desta função (".../.netlify/functions/payment-webhook-
 * mercadopago") como "notification_url" no Mercado Pago — isso já
 * acontece automaticamente a cada preferência criada por
 * payment-create-preference.js.
 *
 * Sem MERCADOPAGO_ACCESS_TOKEN configurado, esta função não tem como
 * validar nada com segurança e recusa a notificação.
 * ============================================================================
 */

exports.handler = async (event) => {
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const MP_TOKEN = process.env.MERCADOPAGO_ACCESS_TOKEN;

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !MP_TOKEN) {
    return { statusCode: 200, body: "ignored: gateway not configured" };
  }

  // O Mercado Pago manda o ID do pagamento tanto via query string
  // (?topic=payment&id=XXX ou ?type=payment&data.id=XXX) quanto no corpo,
  // dependendo do tipo de integração. Aceitamos ambos os formatos.
  const params = event.queryStringParameters || {};
  let paymentId = params.id || params["data.id"];

  if (!paymentId && event.body) {
    try {
      const body = JSON.parse(event.body);
      paymentId = (body.data && body.data.id) || body.id;
    } catch {
      // corpo não era JSON — segue sem paymentId, tratado abaixo
    }
  }

  if (!paymentId) {
    return { statusCode: 200, body: "ignored: no payment id" };
  }

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };

  // Busca o pagamento DE VERDADE na API do Mercado Pago (nunca confia no
  // corpo da notificação recebida).
  const mpRes = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
    headers: { Authorization: `Bearer ${MP_TOKEN}` },
  });
  if (!mpRes.ok) {
    return { statusCode: 200, body: "ignored: could not verify payment with Mercado Pago" };
  }
  const mpPayment = await mpRes.json();

  const orderId = mpPayment.external_reference;
  if (!orderId) {
    return { statusCode: 200, body: "ignored: no external_reference" };
  }

  const statusMap = {
    approved: "approved",
    pending: "pending",
    in_process: "pending",
    rejected: "refused",
    cancelled: "cancelled",
    refunded: "refunded",
    charged_back: "refunded",
  };
  const internalStatus = statusMap[mpPayment.status] || "pending";

  const orderStatusMap = {
    approved: "pagamento_aprovado",
    refused: "cancelado",
    cancelled: "cancelado",
    refunded: "reembolsado",
  };

  await fetch(`${SUPABASE_URL}/rest/v1/payments?order_id=eq.${orderId}`, {
    method: "PATCH",
    headers: restHeaders,
    body: JSON.stringify({
      status: internalStatus,
      provider: "mercadopago",
      provider_transaction_id: String(mpPayment.id),
      raw_response: mpPayment,
    }),
  });

  const updates = { payment_status: internalStatus };
  if (orderStatusMap[internalStatus]) {
    updates.status = orderStatusMap[internalStatus];
  }
  await fetch(`${SUPABASE_URL}/rest/v1/orders?id=eq.${orderId}`, {
    method: "PATCH",
    headers: restHeaders,
    body: JSON.stringify(updates),
  });

  if (updates.status) {
    await fetch(`${SUPABASE_URL}/rest/v1/order_status_history`, {
      method: "POST",
      headers: Object.assign({}, restHeaders, { Prefer: "return=minimal" }),
      body: JSON.stringify([{
        order_id: orderId,
        status: updates.status,
        note: `Atualizado automaticamente pelo webhook do Mercado Pago (pagamento ${mpPayment.status}).`,
      }]),
    });
  }

  await smNotifyCustomer(SUPABASE_URL, SERVICE_ROLE_KEY, restHeaders, orderId, internalStatus);

  return { statusCode: 200, body: "ok" };
};

// (Módulo 7) Avisa o cliente por push, melhor esforço, que o status do
// pagamento mudou. Nunca falha o processamento do webhook por causa disso
// — o Mercado Pago espera 200 rápido, e um erro aqui não deve causar
// reenvio desnecessário da notificação por parte deles.
async function smNotifyCustomer(SUPABASE_URL, SERVICE_ROLE_KEY, restHeaders, orderId, internalStatus) {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/orders?id=eq.${orderId}&select=customer_id,order_number`, { headers: restHeaders });
    const rows = await res.json();
    const order = Array.isArray(rows) ? rows[0] : null;
    if (!order || !order.customer_id) return;

    const title = internalStatus === "approved" ? "Pagamento aprovado! ✅" : "Atualização do pagamento";
    const base = process.env.URL || process.env.DEPLOY_URL || "";
    await fetch(`${base}/.netlify/functions/push-send-notification`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE_ROLE_KEY}` },
      body: JSON.stringify({ userId: order.customer_id, title, body: `Pedido ${order.order_number}.`, url: "/minha-conta.html" }),
    });
  } catch {
    // silencioso — push é sempre "melhor esforço"
  }
}
