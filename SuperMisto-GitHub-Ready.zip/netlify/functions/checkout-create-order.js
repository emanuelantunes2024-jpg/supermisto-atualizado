/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/checkout-create-order.js  (MÓDULO 4)
 * ============================================================================
 * Cria um pedido real a partir do carrinho do cliente. Esta é a ÚNICA porta
 * de entrada para criar pedidos — o banco não aceita INSERT direto em
 * "orders"/"order_items" por um cliente comum (ver RLS em
 * supabase/migrations/002_modulo4_vendas.sql), justamente para impedir que
 * alguém manipule preços ou quantidades direto pela API.
 *
 * Fluxo:
 *   1. Exige "Authorization: Bearer <token>" com a sessão do CLIENTE (não
 *      de administrador) — validado contra o Supabase.
 *   2. Garante que existe uma linha em "customers" para esse usuário
 *      (cria se for a primeira compra e o cadastro não tiver passado por
 *      customer-auth.js por algum motivo).
 *   3. Chama a função sm_create_order() no banco (RPC), usando a
 *      service_role key, passando só product_id + quantity de cada item —
 *      NUNCA o preço que o navegador enviou. O banco recalcula tudo com
 *      os preços reais e valida estoque/disponibilidade dentro de uma
 *      transação atômica.
 *   4. Devolve o número do pedido criado.
 *
 * Variáveis de ambiente necessárias (Netlify → Site configuration →
 * Environment variables): SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY (as
 * mesmas já usadas por admin-create-user.js).
 * ============================================================================
 */

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Método não permitido" }, cors);

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return json(500, { error: "Backend não configurado: faltam variáveis de ambiente SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY no Netlify." }, cors);
  }

  // 1) Valida o token do cliente
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const callerToken = authHeader.replace(/^Bearer\s+/i, "");
  if (!callerToken) return json(401, { error: "Não autenticado. Faça login para finalizar a compra." }, cors);

  const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${callerToken}` },
  });
  if (!userRes.ok) return json(401, { error: "Sessão inválida ou expirada. Faça login novamente." }, cors);
  const user = await userRes.json();

  // 2) Corpo do pedido
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Corpo do pedido inválido." }, cors);
  }
  const { items, shippingAddress, shipping, discount, paymentMethod } = payload;

  if (!Array.isArray(items) || !items.length) {
    return json(400, { error: "O carrinho está vazio." }, cors);
  }
  for (const it of items) {
    if (!it || typeof it.productId !== "string" || !it.productId) {
      return json(400, { error: "Item do carrinho inválido (produto não identificado)." }, cors);
    }
    if (!Number.isFinite(Number(it.quantity)) || Number(it.quantity) <= 0) {
      return json(400, { error: `Quantidade inválida para o produto "${it.productId}".` }, cors);
    }
  }
  if (!shippingAddress || typeof shippingAddress !== "object") {
    return json(400, { error: "Endereço de entrega é obrigatório." }, cors);
  }

  const restHeaders = {
    apikey: SERVICE_ROLE_KEY,
    Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
    "Content-Type": "application/json",
  };

  // 3) Garante que existe uma linha em "customers" para este usuário
  const customerCheck = await fetch(`${SUPABASE_URL}/rest/v1/customers?id=eq.${user.id}&select=id`, { headers: restHeaders });
  const customerRows = await customerCheck.json();
  if (!Array.isArray(customerRows) || !customerRows.length) {
    await fetch(`${SUPABASE_URL}/rest/v1/customers`, {
      method: "POST",
      headers: Object.assign({}, restHeaders, { Prefer: "return=minimal" }),
      body: JSON.stringify([{ id: user.id, email: user.email, name: shippingAddress.recipientName || "", phone: shippingAddress.phone || "" }]),
    });
  }

  // 4) Chama a função sm_create_order() (RPC) — validação e criação atômica
  const rpcRes = await fetch(`${SUPABASE_URL}/rest/v1/rpc/sm_create_order`, {
    method: "POST",
    headers: restHeaders,
    body: JSON.stringify({
      p_customer_id: user.id,
      p_items: items.map((it) => ({ product_id: it.productId, quantity: Number(it.quantity) })),
      p_shipping_address: shippingAddress,
      p_customer_snapshot: { name: shippingAddress.recipientName || "", email: user.email, phone: shippingAddress.phone || "" },
      p_shipping: Number(shipping) || 0,
      p_discount: Number(discount) || 0,
      p_payment_method: paymentMethod || "pix",
    }),
  });

  if (!rpcRes.ok) {
    const errBody = await rpcRes.text();
    // Mensagens de "raise exception" do Postgres (estoque insuficiente,
    // produto indisponível etc.) chegam aqui de forma legível.
    let friendly = errBody;
    try { friendly = JSON.parse(errBody).message || errBody; } catch {}
    return json(422, { error: friendly }, cors);
  }

  const result = await rpcRes.json();
  const order = Array.isArray(result) ? result[0] : result;

  // (Módulo 7) Avisa por push, melhor esforço, cada vendedor que teve
  // produto vendido neste pedido. Nunca deixa o checkout falhar por causa
  // disso — erros aqui são só registrados no log da função.
  try {
    const createdItemsRes = await fetch(`${SUPABASE_URL}/rest/v1/order_items?order_id=eq.${order.order_id}&select=seller_id`, { headers: restHeaders });
    const createdItems = await createdItemsRes.json();
    const sellerIds = [...new Set((Array.isArray(createdItems) ? createdItems : []).map((it) => it.seller_id).filter(Boolean))];
    for (const sellerId of sellerIds) {
      await smSendPush(SUPABASE_URL, SERVICE_ROLE_KEY, sellerId, "Nova venda! 🎉", `Pedido ${order.order_number} tem produto seu.`, "/vendedor/dashboard.html");
    }
  } catch (pushErr) {
    console.warn("SuperMisto: falha ao enviar notificação push (não afeta o pedido).", pushErr);
  }

  return json(200, { ok: true, orderId: order.order_id, orderNumber: order.order_number }, cors);
};

// (Módulo 7) Envia uma notificação push best-effort chamando
// push-send-notification.js internamente (server-to-server, autenticado
// com a própria service_role key). Nunca lança erro para quem chamou.
async function smSendPush(SUPABASE_URL, SERVICE_ROLE_KEY, userId, title, body, url) {
  try {
    const base = process.env.URL || process.env.DEPLOY_URL || "";
    await fetch(`${base}/.netlify/functions/push-send-notification`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE_ROLE_KEY}` },
      body: JSON.stringify({ userId, title, body, url }),
    });
  } catch {
    // silencioso — push é sempre "melhor esforço"
  }
}

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
