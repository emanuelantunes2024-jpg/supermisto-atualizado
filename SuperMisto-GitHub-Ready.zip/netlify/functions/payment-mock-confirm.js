/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/payment-mock-confirm.js  (MÓDULO 4)
 * ============================================================================
 * ⚠️  MODO DE TESTE — NÃO É UM PAGAMENTO REAL. ⚠️
 *
 * Esta função simula o "webhook" que um gateway de pagamento de verdade
 * (Mercado Pago, Stripe, PagSeguro, etc.) chamaria para avisar que um
 * pagamento foi aprovado ou recusado. Como este projeto não tem, nesta
 * etapa, credenciais de nenhum gateway real configuradas, criamos este
 * "confirmador manual" só para permitir testar o fluxo completo do pedido
 * (aguardando pagamento → pagamento aprovado → em preparação → ...) sem
 * inventar uma integração que não existe.
 *
 * Em produção, esta função (ou uma nova, específica do gateway escolhido)
 * seria substituída por um endpoint que:
 *   1. Recebe a notificação assinada pelo gateway real (não um botão do
 *      próprio site).
 *   2. Verifica a assinatura/segredo do gateway (nunca confia cegamente).
 *   3. Atualiza o pagamento e o pedido do mesmo jeito que esta função faz.
 *
 * Ver PROJETO.md, seção "Pagamentos — arquitetura preparada para gateway
 * real", para a lista exata de variáveis de ambiente que uma integração
 * real precisaria (ex.: MERCADOPAGO_ACCESS_TOKEN).
 *
 * Uso nesta etapa: só o painel administrativo chama esta função (com o
 * token do administrador logado), como um botão "Simular pagamento
 * aprovado" — nunca é chamada automaticamente, e o painel deixa isso
 * visualmente claro.
 * ============================================================================
 */

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Método não permitido" }, cors);

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return json(500, { error: "Backend não configurado: faltam variáveis de ambiente SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY no Netlify." }, cors);
  }

  // Só administradores podem simular uma confirmação de pagamento.
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const callerToken = authHeader.replace(/^Bearer\s+/i, "");
  if (!callerToken) return json(401, { error: "Não autenticado." }, cors);

  const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${callerToken}` },
  });
  if (!userRes.ok) return json(401, { error: "Sessão inválida ou expirada." }, cors);
  const user = await userRes.json();

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };

  const adminCheck = await fetch(`${SUPABASE_URL}/rest/v1/admin_profiles?id=eq.${user.id}&select=id`, { headers: restHeaders });
  const adminRows = await adminCheck.json();
  if (!Array.isArray(adminRows) || !adminRows.length) {
    return json(403, { error: "Apenas administradores podem simular confirmação de pagamento." }, cors);
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Corpo do pedido inválido." }, cors);
  }
  const { orderId, outcome } = payload; // outcome: "approved" | "refused"
  if (!orderId || !["approved", "refused"].includes(outcome)) {
    return json(400, { error: 'Parâmetros inválidos. Esperado: { orderId, outcome: "approved" | "refused" }.' }, cors);
  }

  // Atualiza o pagamento
  const payRes = await fetch(`${SUPABASE_URL}/rest/v1/payments?order_id=eq.${orderId}`, {
    method: "PATCH",
    headers: Object.assign({}, restHeaders, { Prefer: "return=representation" }),
    body: JSON.stringify({
      status: outcome,
      provider_transaction_id: "MOCK-" + Date.now(),
      raw_response: { mode: "test", simulated_by: user.email, outcome },
    }),
  });
  if (!payRes.ok) return json(500, { error: "Falha ao atualizar pagamento: " + (await payRes.text()) }, cors);

  // Atualiza o pedido (status + payment_status)
  const newOrderStatus = outcome === "approved" ? "pagamento_aprovado" : "cancelado";
  const orderRes = await fetch(`${SUPABASE_URL}/rest/v1/orders?id=eq.${orderId}`, {
    method: "PATCH",
    headers: restHeaders,
    body: JSON.stringify({ payment_status: outcome, status: newOrderStatus }),
  });
  if (!orderRes.ok) return json(500, { error: "Falha ao atualizar pedido: " + (await orderRes.text()) }, cors);

  // Registra no histórico
  await fetch(`${SUPABASE_URL}/rest/v1/order_status_history`, {
    method: "POST",
    headers: Object.assign({}, restHeaders, { Prefer: "return=minimal" }),
    body: JSON.stringify([{
      order_id: orderId,
      status: newOrderStatus,
      changed_by: user.id,
      note: `[MODO DE TESTE] Pagamento simulado como "${outcome}" por ${user.email}.`,
    }]),
  });

  await smNotifyCustomer(SUPABASE_URL, SERVICE_ROLE_KEY, orderId, outcome);

  return json(200, { ok: true, status: newOrderStatus }, cors);
};

// (Módulo 7) Avisa o cliente por push, melhor esforço, que o pagamento foi// confirmado/recusado. Nunca falha a confirmação do pagamento por causa disso.
async function smNotifyCustomer(SUPABASE_URL, SERVICE_ROLE_KEY, orderId, outcome) {
  try {
    const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };
    const res = await fetch(`${SUPABASE_URL}/rest/v1/orders?id=eq.${orderId}&select=customer_id,order_number`, { headers: restHeaders });
    const rows = await res.json();
    const order = Array.isArray(rows) ? rows[0] : null;
    if (!order || !order.customer_id) return;

    const title = outcome === "approved" ? "Pagamento aprovado! ✅" : "Pagamento não aprovado";
    const body = `Pedido ${order.order_number}.`;
    const base = process.env.URL || process.env.DEPLOY_URL || "";
    await fetch(`${base}/.netlify/functions/push-send-notification`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE_ROLE_KEY}` },
      body: JSON.stringify({ userId: order.customer_id, title, body, url: "/minha-conta.html" }),
    });
  } catch {
    // silencioso — push é sempre "melhor esforço"
  }
}

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
