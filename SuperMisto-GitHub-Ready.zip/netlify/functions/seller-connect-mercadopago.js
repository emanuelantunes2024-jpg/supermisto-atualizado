/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/seller-connect-mercadopago.js  (MÓDULO 7)
 * ============================================================================
 * Primeiro passo do fluxo OAuth que permite um vendedor conectar a PRÓPRIA
 * conta do Mercado Pago à loja — necessário para o split automático de
 * pagamento (ver payment-create-preference.js e PROJETO.md, seção 19.2).
 *
 * Esta função não troca nenhum código por token — só monta a URL de
 * autorização do Mercado Pago e devolve para o navegador do vendedor
 * redirecionar. A troca de verdade (código → token) acontece em
 * seller-mercadopago-callback.js, quando o Mercado Pago redireciona de
 * volta.
 *
 * Sem MERCADOPAGO_CLIENT_ID configurado (as credenciais da APLICAÇÃO
 * SuperMisto cadastrada no Mercado Pago — diferentes do token pessoal do
 * vendedor), esta função recusa com uma mensagem clara: o split de
 * pagamento fica indisponível, mas todo o resto do marketplace continua
 * funcionando normalmente (pagamento cai na conta principal da loja).
 *
 * Variáveis de ambiente necessárias:
 *   MERCADOPAGO_CLIENT_ID → obtido em Mercado Pago Developers → Suas aplicações
 *   SITE_URL               → URL pública do site, para montar o redirect_uri
 * ============================================================================
 */

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Método não permitido" }, cors);

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const CLIENT_ID = process.env.MERCADOPAGO_CLIENT_ID;
  const SITE_URL = process.env.SITE_URL;

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return json(500, { error: "Backend não configurado: faltam SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY." }, cors);
  }
  if (!CLIENT_ID || !SITE_URL) {
    return json(501, {
      error: "Split de pagamento ainda não configurado nesta loja. Falta MERCADOPAGO_CLIENT_ID/SITE_URL no Netlify. Seus produtos continuam vendendo normalmente — só sem divisão automática do pagamento.",
      configured: false,
    }, cors);
  }

  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const callerToken = authHeader.replace(/^Bearer\s+/i, "");
  if (!callerToken) return json(401, { error: "Não autenticado." }, cors);

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };

  const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${callerToken}` },
  });
  if (!userRes.ok) return json(401, { error: "Sessão inválida ou expirada." }, cors);
  const user = await userRes.json();

  // Confere que quem está pedindo é mesmo um vendedor cadastrado.
  const sellerRes = await fetch(`${SUPABASE_URL}/rest/v1/seller_profiles?id=eq.${user.id}&select=id`, { headers: restHeaders });
  const sellerRows = await sellerRes.json();
  if (!Array.isArray(sellerRows) || !sellerRows.length) {
    return json(403, { error: "Apenas vendedores cadastrados podem conectar uma conta Mercado Pago." }, cors);
  }

  // "state" carrega o próprio token do vendedor (validado de novo no
  // callback) para conseguirmos identificar quem completou o fluxo sem
  // precisar de sessão de navegador compartilhada entre as duas chamadas.
  const state = Buffer.from(JSON.stringify({ sellerId: user.id, ts: Date.now() })).toString("base64url");
  const redirectUri = `${SITE_URL}/.netlify/functions/seller-mercadopago-callback`;

  const authUrl =
    `https://auth.mercadopago.com.br/authorization` +
    `?client_id=${encodeURIComponent(CLIENT_ID)}` +
    `&response_type=code` +
    `&platform_id=mp` +
    `&redirect_uri=${encodeURIComponent(redirectUri)}` +
    `&state=${encodeURIComponent(state)}`;

  return json(200, { ok: true, authUrl }, cors);
};

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
