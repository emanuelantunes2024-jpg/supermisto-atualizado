/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/payment-create-preference.js  (MÓDULO 5)
 * ============================================================================
 * Integração REAL com o Mercado Pago (não é modo de teste) — mas só
 * funciona de verdade depois que você configurar MERCADOPAGO_ACCESS_TOKEN
 * como variável de ambiente no Netlify. Sem essa variável, a função
 * responde 501 com uma mensagem clara — nunca finge que criou uma cobrança
 * real.
 *
 * Por que Mercado Pago: é o gateway mais usado no Brasil, aceita Pix,
 * cartão e boleto na mesma preferência de pagamento, e tem uma API REST
 * simples de chamar sem precisar de SDK.
 *
 * Fluxo:
 *   1. Cliente já finalizou o checkout (checkout-create-order.js criou o
 *      pedido com status "aguardando_pagamento").
 *   2. O site chama esta função com o ID desse pedido.
 *   3. A função confere que o pedido pertence a quem está chamando e que
 *      ainda está pendente de pagamento.
 *   4. Monta os itens a partir de order_items (nunca confia em valores
 *      vindos do navegador) e chama a API "Checkout Pro" do Mercado Pago
 *      para criar uma "preference".
 *   5. Devolve a URL de pagamento (init_point) para o navegador redirecionar
 *      o cliente para lá.
 *
 * A confirmação do pagamento NÃO acontece aqui — acontece em
 * payment-webhook-mercadopago.js, chamada pelo próprio Mercado Pago quando
 * o status muda (nunca confiamos no navegador para isso).
 *
 * Variáveis de ambiente necessárias:
 *   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY → já usadas pelas outras funções
 *   MERCADOPAGO_ACCESS_TOKEN                 → token de produção/teste da sua conta Mercado Pago
 *   SITE_URL                                  → URL pública do site (para montar as back_urls e o webhook)
 * ============================================================================
 */

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Método não permitido" }, cors);

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const MP_TOKEN = process.env.MERCADOPAGO_ACCESS_TOKEN;
  const SITE_URL = process.env.SITE_URL || "";

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return json(500, { error: "Backend não configurado: faltam SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY." }, cors);
  }
  if (!MP_TOKEN) {
    return json(501, {
      error: "Gateway de pagamento (Mercado Pago) ainda não configurado. Falta a variável de ambiente MERCADOPAGO_ACCESS_TOKEN no Netlify. O pedido continua válido — um administrador pode confirmar o pagamento manualmente pelo painel enquanto isso.",
      gatewayConfigured: false,
    }, cors);
  }

  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const callerToken = authHeader.replace(/^Bearer\s+/i, "");
  if (!callerToken) return json(401, { error: "Não autenticado." }, cors);

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };

  const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${callerToken}` },
  });
  if (!userRes.ok) return json(401, { error: "Sessão inválida ou expirada." }, cors);
  const user = await userRes.json();

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Corpo do pedido inválido." }, cors);
  }
  const { orderId } = payload;
  if (!orderId) return json(400, { error: "orderId é obrigatório." }, cors);

  // Confere que o pedido existe, pertence a este cliente, e ainda está
  // pendente de pagamento.
  const orderRes = await fetch(`${SUPABASE_URL}/rest/v1/orders?id=eq.${orderId}&select=*`, { headers: restHeaders });
  const orders = await orderRes.json();
  const order = Array.isArray(orders) ? orders[0] : null;
  if (!order) return json(404, { error: "Pedido não encontrado." }, cors);
  if (order.customer_id !== user.id) return json(403, { error: "Este pedido não pertence a este cliente." }, cors);
  if (order.payment_status !== "pending") {
    return json(409, { error: `Este pedido já está com pagamento "${order.payment_status}".` }, cors);
  }

  const itemsRes = await fetch(`${SUPABASE_URL}/rest/v1/order_items?order_id=eq.${orderId}&select=*`, { headers: restHeaders });
  const orderItems = await itemsRes.json();

  const mpItems = (orderItems || []).map((it) => ({
    title: it.product_name,
    quantity: it.quantity,
    unit_price: Number(it.unit_price),
    currency_id: "BRL",
  }));
  if (order.shipping && Number(order.shipping) > 0) {
    mpItems.push({ title: "Frete", quantity: 1, unit_price: Number(order.shipping), currency_id: "BRL" });
  }

  const preferenceBody = {
    items: mpItems,
    external_reference: order.id,
    back_urls: {
      success: `${SITE_URL}/minha-conta.html?pagamento=sucesso`,
      pending: `${SITE_URL}/minha-conta.html?pagamento=pendente`,
      failure: `${SITE_URL}/checkout.html?pagamento=falhou`,
    },
    auto_return: "approved",
    notification_url: `${SITE_URL}/.netlify/functions/payment-webhook-mercadopago`,
    payer: { email: user.email },
  };

  // ------------------------------------------------------------------------
  // Split de pagamento (Módulo 7) — só quando TODOS os itens do pedido são
  // do MESMO vendedor, e esse vendedor já conectou a própria conta
  // Mercado Pago (ver seller-connect-mercadopago.js). Nesses casos, a
  // preferência é criada usando o token do PRÓPRIO VENDEDOR como
  // "collector" (o dinheiro cai direto na conta dele), com
  // "marketplace_fee" retendo automaticamente a comissão da loja.
  //
  // Pedidos com produtos da própria loja, de múltiplos vendedores ao
  // mesmo tempo, ou de um vendedor que não conectou conta própria,
  // continuam usando o token da PLATAFORMA (MP_TOKEN) — comportamento
  // idêntico ao Módulo 5/6, sem split. Isso é uma limitação real e
  // documentada da API do Mercado Pago para Checkout Pro: um único
  // pagamento só pode ser dividido com UM vendedor por vez.
  const sellerIds = [...new Set((orderItems || []).map((it) => it.seller_id).filter(Boolean))];
  let mpAuthToken = MP_TOKEN;
  let splitApplied = false;

  if (sellerIds.length === 1) {
    const sellerRes = await fetch(`${SUPABASE_URL}/rest/v1/seller_profiles?id=eq.${sellerIds[0]}&select=mp_access_token,commission_rate`, { headers: restHeaders });
    const sellerRows = await sellerRes.json();
    const seller = Array.isArray(sellerRows) ? sellerRows[0] : null;

    if (seller && seller.mp_access_token) {
      const itemsTotal = mpItems.reduce((sum, it) => sum + it.unit_price * it.quantity, 0);
      const fee = Math.round(itemsTotal * (Number(seller.commission_rate) / 100) * 100) / 100;
      preferenceBody.marketplace_fee = fee;
      mpAuthToken = seller.mp_access_token;
      splitApplied = true;
    }
  }

  const mpRes = await fetch("https://api.mercadopago.com/checkout/preferences", {
    method: "POST",
    headers: { Authorization: `Bearer ${mpAuthToken}`, "Content-Type": "application/json" },
    body: JSON.stringify(preferenceBody),
  });
  const mpBody = await mpRes.json();

  if (!mpRes.ok) {
    return json(502, { error: "Falha ao criar preferência no Mercado Pago: " + (mpBody.message || JSON.stringify(mpBody)) }, cors);
  }

  // Guarda o ID da preferência no pagamento (para conseguir cruzar com o webhook depois)
  await fetch(`${SUPABASE_URL}/rest/v1/payments?order_id=eq.${orderId}`, {
    method: "PATCH",
    headers: restHeaders,
    body: JSON.stringify({ provider: splitApplied ? "mercadopago_split" : "mercadopago", provider_transaction_id: mpBody.id }),
  });

  return json(200, { ok: true, initPoint: mpBody.init_point, preferenceId: mpBody.id, gatewayConfigured: true, splitApplied }, cors);
};

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
