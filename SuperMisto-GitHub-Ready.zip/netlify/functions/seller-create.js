/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/seller-create.js  (MÓDULO 6)
 * ============================================================================
 * Cria uma conta de vendedor do marketplace (Supabase Auth + linha em
 * seller_profiles). Segue exatamente o mesmo padrão de segurança de
 * admin-create-user.js: só quem já é administrador "owner" pode criar um
 * vendedor — não existe cadastro público de vendedor nesta etapa (o
 * onboarding é feito manualmente pelo lojista, que decide quem pode
 * vender na plataforma).
 *
 * Fluxo:
 *   1. Exige "Authorization: Bearer <token>" do administrador chamador.
 *   2. Confere que esse administrador tem papel "owner" em admin_profiles.
 *   3. Cria o usuário no Supabase Auth (service_role key) + a linha
 *      correspondente em seller_profiles, com status "pending" por padrão
 *      (o owner ativa depois, em admin/vendedores.html, quando quiser
 *      liberar o vendedor para cadastrar produtos).
 * ============================================================================
 */

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Método não permitido" }, cors);

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return json(500, { error: "Backend não configurado: faltam variáveis de ambiente SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY no Netlify." }, cors);
  }

  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const callerToken = authHeader.replace(/^Bearer\s+/i, "");
  if (!callerToken) return json(401, { error: "Não autenticado." }, cors);

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };

  const callerRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${callerToken}` },
  });
  if (!callerRes.ok) return json(401, { error: "Sessão inválida ou expirada. Faça login novamente." }, cors);
  const caller = await callerRes.json();

  const adminCheck = await fetch(`${SUPABASE_URL}/rest/v1/admin_profiles?id=eq.${caller.id}&select=role`, { headers: restHeaders });
  const adminRows = await adminCheck.json();
  if (!Array.isArray(adminRows) || !adminRows.length || adminRows[0].role !== "owner") {
    return json(403, { error: 'Apenas administradores com papel "owner" podem criar vendedores.' }, cors);
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Corpo do pedido inválido." }, cors);
  }
  const { email, password, storeName, phone, commissionRate } = payload;
  if (!email || !password || password.length < 6) {
    return json(400, { error: "E-mail e senha (mínimo 6 caracteres) são obrigatórios." }, cors);
  }

  const createRes = await fetch(`${SUPABASE_URL}/auth/v1/admin/users`, {
    method: "POST",
    headers: restHeaders,
    body: JSON.stringify({ email, password, email_confirm: true }),
  });
  const created = await createRes.json();
  if (!createRes.ok) {
    return json(createRes.status, { error: created.msg || created.error_description || "Falha ao criar usuário." }, cors);
  }

  const profileRes = await fetch(`${SUPABASE_URL}/rest/v1/seller_profiles`, {
    method: "POST",
    headers: Object.assign({}, restHeaders, { Prefer: "return=minimal" }),
    body: JSON.stringify([{
      id: created.id,
      email,
      store_name: storeName || "",
      phone: phone || "",
      commission_rate: typeof commissionRate === "number" ? commissionRate : 15,
      status: "pending",
    }]),
  });

  if (!profileRes.ok) {
    const profileErr = await profileRes.text();
    return json(500, { error: "Usuário criado, mas houve falha ao salvar o perfil de vendedor: " + profileErr }, cors);
  }

  return json(200, { ok: true, id: created.id }, cors);
};

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
