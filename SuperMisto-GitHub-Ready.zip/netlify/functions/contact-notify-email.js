/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/contact-notify-email.js  (MÓDULO 5)
 * ============================================================================
 * Notificação por e-mail "melhor esforço" para o formulário de contato.
 * A mensagem em si já foi salva de verdade pelo navegador direto na tabela
 * "contact_messages" (RLS permite inserção pública) — esta função NÃO é
 * responsável por guardar a mensagem, só por avisar a loja por e-mail.
 *
 * Se a variável de ambiente RESEND_API_KEY não estiver configurada, a
 * função retorna 200 sem fazer nada (não é um erro — só significa que
 * ninguém configurou notificação por e-mail ainda; a mensagem continua
 * visível em /admin/mensagens.html normalmente).
 *
 * Por que Resend: é uma API de e-mail transacional simples de usar via
 * uma única chamada REST (sem SDK, sem servidor SMTP para configurar).
 * Trocar por outro provedor (SendGrid, Postmark, etc.) exigiria só trocar
 * a URL/formato do corpo desta função — a arquitetura (Netlify Function
 * com a chave em variável de ambiente) continua a mesma.
 *
 * Variáveis de ambiente necessárias para o e-mail funcionar de verdade:
 *   RESEND_API_KEY      → chave de API da sua conta Resend (resend.com)
 *   CONTACT_NOTIFY_EMAIL → e-mail da loja que deve receber o aviso
 *                           (ex.: contato@supermisto.com.br)
 * ============================================================================
 */

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Método não permitido" }, cors);

  const RESEND_API_KEY = process.env.RESEND_API_KEY;
  const NOTIFY_EMAIL = process.env.CONTACT_NOTIFY_EMAIL;

  if (!RESEND_API_KEY || !NOTIFY_EMAIL) {
    // Não é um erro: e-mail é opcional nesta etapa. A mensagem já foi
    // salva de verdade pelo navegador antes de chamar esta função.
    return json(200, { ok: true, emailSent: false, reason: "E-mail de notificação não configurado (RESEND_API_KEY/CONTACT_NOTIFY_EMAIL)." }, cors);
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Corpo do pedido inválido." }, cors);
  }
  const { name, email, phone, message } = payload;
  if (!email || !message) {
    return json(400, { error: "Dados insuficientes para notificar." }, cors);
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: "SuperMisto <onboarding@resend.dev>",
        to: [NOTIFY_EMAIL],
        reply_to: email,
        subject: `Nova mensagem de contato — ${name || "site"}`,
        text: `Nome: ${name || "-"}\nE-mail: ${email}\nTelefone: ${phone || "-"}\n\nMensagem:\n${message}`,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      return json(200, { ok: true, emailSent: false, reason: "Falha ao enviar e-mail: " + errText }, cors);
    }

    return json(200, { ok: true, emailSent: true }, cors);
  } catch (err) {
    // Mesmo se o e-mail falhar por qualquer motivo, não é um erro fatal —
    // a mensagem já está salva no banco e visível no painel.
    return json(200, { ok: true, emailSent: false, reason: err.message }, cors);
  }
};

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
