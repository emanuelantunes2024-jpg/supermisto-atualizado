/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/push-send-notification.js  (MÓDULO 7)
 * ============================================================================
 * Envia uma notificação push de verdade (Web Push API, protocolo VAPID)
 * para todos os dispositivos/navegadores em que um usuário ativou
 * notificações na PWA. Usada para avisar:
 *   - o vendedor, quando um produto dele é vendido (chamada por
 *     checkout-create-order.js);
 *   - o cliente, quando o pagamento do pedido é aprovado/recusado
 *     (chamada por payment-mock-confirm.js e payment-webhook-mercadopago.js).
 *
 * ÚNICA função deste projeto com uma dependência de pacote (`web-push`,
 * ver netlify/functions/package.json) — assinar notificações push
 * corretamente exige criptografia ECDH (VAPID) que não vale a pena
 * reimplementar à mão sem uma biblioteca revisada.
 *
 * Sem as chaves VAPID configuradas, esta função não envia nada (não é um
 * erro) — a PWA simplesmente não oferece a opção de ativar notificações
 * até isso ser configurado.
 *
 * Variáveis de ambiente necessárias:
 *   VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY → gere com `npx web-push generate-vapid-keys`
 *   VAPID_CONTACT_EMAIL                  → um e-mail de contato (exigido pelo protocolo)
 * ============================================================================
 */

let webpush;
try {
  webpush = require("web-push");
} catch {
  webpush = null; // dependência não instalada — a função vira no-op mais abaixo
}

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Método não permitido" }, cors);

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
  const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
  const VAPID_CONTACT_EMAIL = process.env.VAPID_CONTACT_EMAIL;

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return json(500, { error: "Backend não configurado." }, cors);
  }
  if (!webpush || !VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY || !VAPID_CONTACT_EMAIL) {
    // Silenciosamente não faz nada — notificações push são um recurso
    // opcional. Quem chamou esta função (checkout, webhook de pagamento)
    // não deve travar nem falhar por causa disso.
    return json(200, { ok: true, sent: 0, reason: "Notificações push não configuradas (VAPID)." }, cors);
  }

  // Esta função é chamada internamente por outras Netlify Functions
  // (server-to-server, usando a service_role key como autenticação —
  // não é um endpoint público para qualquer um mandar notificação para
  // qualquer usuário).
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const callerToken = authHeader.replace(/^Bearer\s+/i, "");
  if (callerToken !== SERVICE_ROLE_KEY) {
    return json(401, { error: "Não autorizado." }, cors);
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Corpo do pedido inválido." }, cors);
  }
  const { userId, title, body, url } = payload;
  if (!userId || !title) {
    return json(400, { error: "userId e title são obrigatórios." }, cors);
  }

  webpush.setVapidDetails(`mailto:${VAPID_CONTACT_EMAIL}`, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };
  const subsRes = await fetch(`${SUPABASE_URL}/rest/v1/push_subscriptions?user_id=eq.${userId}&select=*`, { headers: restHeaders });
  const subscriptions = await subsRes.json();

  if (!Array.isArray(subscriptions) || !subscriptions.length) {
    return json(200, { ok: true, sent: 0, reason: "Usuário sem inscrições de notificação." }, cors);
  }

  const notificationPayload = JSON.stringify({ title, body: body || "", url: url || "/" });
  let sent = 0;
  const staleEndpoints = [];

  for (const sub of subscriptions) {
    try {
      await webpush.sendNotification({ endpoint: sub.endpoint, keys: sub.keys }, notificationPayload);
      sent++;
    } catch (err) {
      // Inscrição expirada/revogada (410 Gone é o caso mais comum) — marca
      // para limpar do banco, sem travar o envio para os outros dispositivos.
      if (err && (err.statusCode === 404 || err.statusCode === 410)) {
        staleEndpoints.push(sub.endpoint);
      }
    }
  }

  if (staleEndpoints.length) {
    await fetch(`${SUPABASE_URL}/rest/v1/push_subscriptions?endpoint=in.(${staleEndpoints.map((e) => `"${e}"`).join(",")})`, {
      method: "DELETE",
      headers: restHeaders,
    });
  }

  return json(200, { ok: true, sent, removed: staleEndpoints.length }, cors);
};

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
