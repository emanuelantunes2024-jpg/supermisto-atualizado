/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/admin-create-user.js  (ETAPA 3, papéis adicionados no Módulo 5)
 * ============================================================================
 * Única operação deste projeto que precisa mesmo de um "poder especial" do
 * lado do servidor: criar um novo usuário administrador no Supabase Auth.
 * Isso não pode ser feito com a chave pública (anon key) do navegador — por
 * isso roda aqui, como uma Netlify Function (Node, do lado do servidor),
 * usando a SUPABASE_SERVICE_ROLE_KEY guardada como variável de ambiente no
 * painel do Netlify (Site settings → Environment variables), NUNCA no
 * código do site.
 *
 * Fluxo de segurança:
 *   1. Exige um header "Authorization: Bearer <token>" com o token de
 *      sessão de quem está chamando (pego do supabase-js no navegador).
 *   2. Valida esse token contra a API do Supabase — se não for um token
 *      válido de um usuário autenticado, recusa com 401.
 *   2b. (Módulo 5) Só aceita se quem está chamando tiver papel "owner"
 *      em admin_profiles — um administrador "editor" não pode criar
 *      outros administradores.
 *   3. Só então usa a service_role key para criar o novo usuário + o
 *      perfil correspondente em admin_profiles, com o papel ("owner" ou
 *      "editor", padrão "editor") vindo do corpo do pedido.
 *
 * Não usa nenhuma biblioteca externa (sem @supabase/supabase-js aqui) —
 * só `fetch`, que já vem pronto no runtime Node do Netlify. Isso evita
 * precisar de um passo de build/instalação de dependências só para esta
 * função, mantendo o projeto simples de manter.
 * ============================================================================
 */

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: cors, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return json(405, { error: "Método não permitido" }, cors);
  }

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return json(500, { error: "Backend não configurado: faltam variáveis de ambiente SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY no Netlify." }, cors);
  }

  // 1) Extrai e valida o token de quem está chamando
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const callerToken = authHeader.replace(/^Bearer\s+/i, "");
  if (!callerToken) {
    return json(401, { error: "Não autenticado." }, cors);
  }

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };

  const callerRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${callerToken}` },
  });
  if (!callerRes.ok) {
    return json(401, { error: "Sessão inválida ou expirada. Faça login novamente." }, cors);
  }
  const caller = await callerRes.json();

  // 1b) Só administradores com papel "owner" podem criar outros administradores
  // (Módulo 5 — papéis diferenciados; ver supabase/migrations/003_modulo5.sql).
  const adminCheck = await fetch(`${SUPABASE_URL}/rest/v1/admin_profiles?id=eq.${caller.id}&select=role`, { headers: restHeaders });
  const adminRows = await adminCheck.json();
  if (!Array.isArray(adminRows) || !adminRows.length) {
    return json(403, { error: "Apenas administradores podem criar outros administradores." }, cors);
  }
  if (adminRows[0].role !== "owner") {
    return json(403, { error: 'Apenas administradores com papel "owner" podem criar outros administradores.' }, cors);
  }

  // 2) Valida o corpo do pedido
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Corpo do pedido inválido." }, cors);
  }
  const { email, password, fullName } = payload;
  const role = payload.role === "owner" ? "owner" : "editor";
  if (!email || !password || password.length < 6) {
    return json(400, { error: "E-mail e senha (mínimo 6 caracteres) são obrigatórios." }, cors);
  }

  // 3) Cria o usuário no Supabase Auth (poder de admin, via service_role key)
  const createRes = await fetch(`${SUPABASE_URL}/auth/v1/admin/users`, {
    method: "POST",
    headers: restHeaders,
    body: JSON.stringify({ email, password, email_confirm: true }),
  });
  const created = await createRes.json();

  if (!createRes.ok) {
    return json(createRes.status, { error: created.msg || created.error_description || "Falha ao criar usuário." }, cors);
  }

  // 4) Cria o perfil correspondente em admin_profiles (bypassa RLS via service_role)
  const profileRes = await fetch(`${SUPABASE_URL}/rest/v1/admin_profiles`, {
    method: "POST",
    headers: Object.assign({}, restHeaders, { Prefer: "return=minimal" }),
    body: JSON.stringify([{ id: created.id, email, full_name: fullName || "", role }]),
  });

  if (!profileRes.ok) {
    const profileErr = await profileRes.text();
    return json(500, { error: "Usuário criado, mas houve falha ao salvar o perfil: " + profileErr }, cors);
  }

  return json(200, { ok: true, id: created.id }, cors);
};

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
