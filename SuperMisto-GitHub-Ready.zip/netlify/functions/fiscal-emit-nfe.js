/**
 * ============================================================================
 * SUPERMISTO — netlify/functions/fiscal-emit-nfe.js  (MÓDULO 6)
 * ============================================================================
 * Integração REAL com a Focus NFe (não é modo de teste) para emitir NFC-e
 * a partir de um pedido pago — mas só funciona de verdade depois que você
 * configurar FOCUS_NFE_API_TOKEN. Sem essa variável, a função responde 501
 * com uma mensagem clara — nunca finge que emitiu uma nota fiscal real.
 *
 * Por que Focus NFe: é um dos serviços mais usados no Brasil para emissão
 * de NFe/NFC-e via API REST simples (sem precisar lidar com certificado
 * digital, XML ou SEFAZ diretamente no seu próprio código — o serviço cuida
 * disso). Tem ambiente de homologação (sandbox) gratuito para testes.
 *
 * Fluxo:
 *   1. Só administradores podem acionar a emissão (verificado contra
 *      admin_profiles) — não é uma ação do cliente.
 *   2. Confere que o pedido existe e que o pagamento está aprovado (não
 *      faz sentido emitir nota de um pedido não pago).
 *   3. Monta o payload fiscal a partir de dados REAIS do banco:
 *      company_fiscal_info (emitente), customer_snapshot/shipping_address
 *      (destinatário) e order_items com o NCM/CFOP de cada produto —
 *      nunca inventa nenhum dado fiscal.
 *   4. Chama a API da Focus NFe (ambiente de homologação ou produção,
 *      conforme FOCUS_NFE_ENVIRONMENT) e grava a resposta em
 *      fiscal_documents.
 *   5. Emissão na Focus NFe é assíncrona — o status inicial fica
 *      "processando_autorizacao"; use fiscal-check-status.js para
 *      consultar o resultado final.
 *
 * Variáveis de ambiente necessárias:
 *   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY → já usadas pelas outras funções
 *   FOCUS_NFE_API_TOKEN                      → token da sua conta Focus NFe
 *   FOCUS_NFE_ENVIRONMENT                     → "homologacao" (padrão/testes) ou "producao"
 * ============================================================================
 */

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Método não permitido" }, cors);

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const FOCUS_TOKEN = process.env.FOCUS_NFE_API_TOKEN;
  const FOCUS_ENV = process.env.FOCUS_NFE_ENVIRONMENT === "producao" ? "producao" : "homologacao";
  const FOCUS_BASE_URL = FOCUS_ENV === "producao" ? "https://api.focusnfe.com.br" : "https://homologacao.focusnfe.com.br";

  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return json(500, { error: "Backend não configurado: faltam SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY." }, cors);
  }
  if (!FOCUS_TOKEN) {
    return json(501, {
      error: "Emissão fiscal ainda não configurada. Falta a variável de ambiente FOCUS_NFE_API_TOKEN no Netlify. Nenhuma nota fiscal foi emitida.",
      gatewayConfigured: false,
    }, cors);
  }

  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const callerToken = authHeader.replace(/^Bearer\s+/i, "");
  if (!callerToken) return json(401, { error: "Não autenticado." }, cors);

  const restHeaders = { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}`, "Content-Type": "application/json" };

  const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${callerToken}` },
  });
  if (!userRes.ok) return json(401, { error: "Sessão inválida ou expirada." }, cors);
  const user = await userRes.json();

  const adminCheck = await fetch(`${SUPABASE_URL}/rest/v1/admin_profiles?id=eq.${user.id}&select=id`, { headers: restHeaders });
  const adminRows = await adminCheck.json();
  if (!Array.isArray(adminRows) || !adminRows.length) {
    return json(403, { error: "Apenas administradores podem emitir nota fiscal." }, cors);
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Corpo do pedido inválido." }, cors);
  }
  const { orderId } = payload;
  if (!orderId) return json(400, { error: "orderId é obrigatório." }, cors);

  const orderRes = await fetch(`${SUPABASE_URL}/rest/v1/orders?id=eq.${orderId}&select=*`, { headers: restHeaders });
  const orders = await orderRes.json();
  const order = Array.isArray(orders) ? orders[0] : null;
  if (!order) return json(404, { error: "Pedido não encontrado." }, cors);
  if (order.payment_status !== "approved") {
    return json(409, { error: 'Só é possível emitir nota fiscal de pedidos com pagamento "approved".' }, cors);
  }

  const itemsRes = await fetch(`${SUPABASE_URL}/rest/v1/order_items?order_id=eq.${orderId}&select=*`, { headers: restHeaders });
  const orderItems = await itemsRes.json();
  if (!Array.isArray(orderItems) || !orderItems.length) {
    return json(422, { error: "Pedido sem itens — não é possível emitir nota fiscal." }, cors);
  }

  // Busca NCM/CFOP reais de cada produto (nunca inventa dado fiscal)
  const productIds = orderItems.map((it) => it.product_id).filter(Boolean);
  const productsRes = await fetch(`${SUPABASE_URL}/rest/v1/products?id=in.(${productIds.map(encodeURIComponent).join(",")})&select=id,ncm,cfop,unit`, { headers: restHeaders });
  const products = await productsRes.json();
  const productMap = {};
  (Array.isArray(products) ? products : []).forEach((p) => { productMap[p.id] = p; });

  const missingFiscalData = orderItems.filter((it) => !productMap[it.product_id] || !productMap[it.product_id].ncm);
  if (missingFiscalData.length) {
    return json(422, {
      error: `Os seguintes produtos não têm NCM cadastrado, obrigatório para emitir nota fiscal: ${missingFiscalData.map((it) => it.product_name).join(", ")}. Preencha o NCM no formulário do produto (aba fiscal) e tente de novo.`,
    }, cors);
  }

  const companyRes = await fetch(`${SUPABASE_URL}/rest/v1/company_fiscal_info?id=eq.1&select=*`, { headers: restHeaders });
  const companyRows = await companyRes.json();
  const company = Array.isArray(companyRows) ? companyRows[0] : null;
  if (!company || !company.cnpj) {
    return json(422, { error: "Dados fiscais da empresa (CNPJ) não preenchidos em Configurações → Dados fiscais. Preencha antes de emitir notas." }, cors);
  }

  const addr = order.shipping_address || {};
  const customerSnap = order.customer_snapshot || {};
  const nfceRef = `pedido-${order.order_number}`;

  // Payload no formato esperado pela Focus NFe para NFC-e (venda ao
  // consumidor final). Ver documentação oficial para o schema completo —
  // aqui usamos os campos essenciais construídos a partir de dados reais.
  const focusPayload = {
    natureza_operacao: "Venda",
    data_emissao: new Date().toISOString(),
    presenca_comprador: 9, // "Operação não presencial, outros" (venda pela internet)
    modalidade_frete: "9",
    cnpj_emitente: (company.cnpj || "").replace(/\D/g, ""),
    nome_destinatario: customerSnap.name || addr.recipientName || "Consumidor",
    cpf_destinatario: (customerSnap.cpf || "").replace(/\D/g, "") || undefined,
    logradouro_destinatario: addr.street,
    numero_destinatario: addr.number,
    bairro_destinatario: addr.neighborhood,
    municipio_destinatario: addr.city,
    uf_destinatario: addr.state,
    cep_destinatario: (addr.cep || "").replace(/\D/g, ""),
    items: orderItems.map((it, i) => ({
      numero_item: i + 1,
      codigo_produto: it.product_id,
      descricao: it.product_name,
      ncm: productMap[it.product_id].ncm,
      cfop: productMap[it.product_id].cfop || "5102",
      unidade_comercial: productMap[it.product_id].unit || "UN",
      quantidade_comercial: it.quantity,
      valor_unitario_comercial: it.unit_price,
      valor_bruto: it.subtotal,
      unidade_tributavel: productMap[it.product_id].unit || "UN",
      quantidade_tributavel: it.quantity,
      valor_unitario_tributavel: it.unit_price,
      icms_origem: "0",
      icms_situacao_tributaria: "102", // Simples Nacional, sem permissão de crédito — ajustar conforme regime real da empresa
    })),
  };

  const focusRes = await fetch(`${FOCUS_BASE_URL}/v2/nfce?ref=${encodeURIComponent(nfceRef)}`, {
    method: "POST",
    headers: {
      Authorization: "Basic " + Buffer.from(FOCUS_TOKEN + ":").toString("base64"),
      "Content-Type": "application/json",
    },
    body: JSON.stringify(focusPayload),
  });
  const focusBody = await focusRes.json();

  // Focus NFe responde 200/202 com status "processando_autorizacao"
  // enquanto processa de forma assíncrona, ou já com erro de validação.
  const status = focusRes.ok ? (focusBody.status === "erro_autorizacao" ? "erro" : "pendente") : "erro";

  const fiscalRow = {
    order_id: orderId,
    status,
    numero: focusBody.numero || null,
    serie: focusBody.serie || null,
    chave_acesso: focusBody.chave_nfe || null,
    provider: "focusnfe",
    raw_response: focusBody,
  };

  // upsert por order_id: se já existe um fiscal_documents para este
  // pedido, atualiza; senão, cria.
  const existingRes = await fetch(`${SUPABASE_URL}/rest/v1/fiscal_documents?order_id=eq.${orderId}&select=id`, { headers: restHeaders });
  const existingRows = await existingRes.json();

  if (Array.isArray(existingRows) && existingRows.length) {
    await fetch(`${SUPABASE_URL}/rest/v1/fiscal_documents?order_id=eq.${orderId}`, {
      method: "PATCH",
      headers: restHeaders,
      body: JSON.stringify(fiscalRow),
    });
  } else {
    await fetch(`${SUPABASE_URL}/rest/v1/fiscal_documents`, {
      method: "POST",
      headers: Object.assign({}, restHeaders, { Prefer: "return=minimal" }),
      body: JSON.stringify([fiscalRow]),
    });
  }

  if (!focusRes.ok) {
    return json(422, { error: "Focus NFe recusou a emissão: " + (focusBody.mensagem || JSON.stringify(focusBody)), focusResponse: focusBody }, cors);
  }

  return json(200, { ok: true, status, ref: nfceRef, focusResponse: focusBody }, cors);
};

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
    body: JSON.stringify(body),
  };
}
