/**
 * ============================================================================
 * SUPERMISTO ADMIN — admin-ui.js  (ETAPA 2, ajustado na ETAPA 3)
 * ============================================================================
 * Monta o "esqueleto" comum a todas as páginas internas do painel:
 * sidebar de navegação + barra superior + área de conteúdo.
 * Cada página só precisa ter:
 *   <div id="admin-shell"></div>
 * e chamar renderAdminShell('arquivo.html', 'Título da página') no load.
 * O conteúdo específico da página é então inserido dentro de
 * #adminContent pelo script daquela página (ex.: admin-produtos.js).
 * ============================================================================
 */

const SM_ADMIN_NAV = [
  { href: "dashboard.html", label: "Dashboard", icon: "📊" },
  { href: "pedidos.html", label: "Pedidos", icon: "🧾" },
  { href: "clientes.html", label: "Clientes", icon: "👥" },
  { href: "vendedores.html", label: "Vendedores", icon: "🏪", ownerOnly: true },
  { href: "produtos.html", label: "Produtos", icon: "🧂" },
  { href: "categorias.html", label: "Categorias", icon: "🗂️" },
  { href: "banners.html", label: "Banners", icon: "🖼️" },
  { href: "destaques.html", label: "Destaques", icon: "⭐" },
  { href: "mensagens.html", label: "Mensagens", icon: "✉️" },
  { href: "historico.html", label: "Histórico", icon: "🕒", ownerOnly: true },
  { href: "configuracoes.html", label: "Configurações", icon: "⚙️", ownerOnly: true },
];

function renderAdminShell(activeHref, pageTitle) {
  const shell = document.getElementById("admin-shell");
  if (!shell) return;

  shell.innerHTML = `
    <div class="admin-sidebar-backdrop" id="adminSidebarBackdrop"></div>
    <div class="admin-layout">
      <aside class="admin-sidebar" id="adminSidebar">
        <div class="admin-sidebar-brand">
          <img src="../assets/img/logo-white.png" alt="SuperMisto">
          <span>Admin</span>
        </div>
        <nav class="admin-sidebar-nav">
          ${SM_ADMIN_NAV.map(
            (item) => `
            <a href="${item.href}" class="${item.href === activeHref ? "active" : ""}" ${item.ownerOnly ? 'data-owner-only="1" style="display:none"' : ""}>
              <span class="ic">${item.icon}</span> ${item.label}
            </a>`
          ).join("")}
        </nav>
        <div class="admin-sidebar-foot">
          Etapa 3 — dados salvos no banco (Supabase).<br>
          <a href="../index.html" target="_blank" rel="noopener">Ver site público ↗</a>
        </div>
      </aside>

      <div class="admin-main">
        <header class="admin-topbar">
          <button class="admin-menu-btn" id="adminMenuBtn" aria-label="Abrir menu">☰</button>
          <h1>${pageTitle}</h1>
          <span class="admin-demo-badge admin-live-badge" title="Conectado ao banco de dados real (Supabase)">Conectado ao banco</span>
          <button class="btn btn-outline btn-sm" id="adminLogoutBtn">Sair</button>
        </header>
        <main class="admin-content" id="adminContent"></main>
      </div>
    </div>
  `;

  const menuBtn = document.getElementById("adminMenuBtn");
  const backdrop = document.getElementById("adminSidebarBackdrop");
  menuBtn?.addEventListener("click", () => document.body.classList.add("admin-sidebar-open"));
  backdrop?.addEventListener("click", () => document.body.classList.remove("admin-sidebar-open"));

  document.getElementById("adminLogoutBtn")?.addEventListener("click", () => {
    if (confirm("Sair do painel administrativo?")) smAdminLogout();
  });

  // (Módulo 5) Revela itens de menu restritos a "owner" (ex.: Configurações)
  // só depois de confirmar o papel do administrador logado. Não bloqueia o
  // resto do shell enquanto isso — a garantia de segurança de verdade está
  // nas políticas RLS, isto é só para não poluir o menu de quem não usa.
  (async () => {
    if (typeof smAdminGetRole !== "function") return;
    const role = await smAdminGetRole();
    if (role === "owner") {
      document.querySelectorAll("[data-owner-only]").forEach((el) => { el.style.display = ""; });
    } else if (activeHref === "configuracoes.html" || activeHref === "historico.html" || activeHref === "vendedores.html") {
      // Um "editor" que tentar acessar uma tela restrita direto pela URL é
      // redirecionado — a tela nem chega a ser desenhada para ele.
      window.location.href = "dashboard.html";
    }
  })();
}

// ---------------------------------------------------------------------------
// Modal de confirmação genérico (usado para excluir produto/categoria/banner)
// ---------------------------------------------------------------------------
function smConfirm(title, message, onConfirm, confirmLabel) {
  const existing = document.getElementById("smConfirmModal");
  if (existing) existing.remove();

  const backdrop = document.createElement("div");
  backdrop.className = "admin-modal-backdrop";
  backdrop.id = "smConfirmModal";
  backdrop.innerHTML = `
    <div class="admin-modal" role="dialog" aria-modal="true">
      <h3>${title}</h3>
      <p>${message}</p>
      <div class="admin-modal-actions">
        <button class="btn btn-outline btn-sm" id="smConfirmCancel">Cancelar</button>
        <button class="btn btn-danger btn-sm" id="smConfirmOk">${confirmLabel || "Confirmar"}</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);

  const close = () => backdrop.remove();
  backdrop.addEventListener("click", (e) => {
    if (e.target === backdrop) close();
  });
  document.getElementById("smConfirmCancel").addEventListener("click", close);
  document.getElementById("smConfirmOk").addEventListener("click", () => {
    close();
    onConfirm();
  });
}

function smEscapeHTML(str) {
  return (str ?? "").toString()
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ---------------------------------------------------------------------------
// Paginação genérica (Módulo 5) — usada em Produtos e Pedidos.
// Desenha "‹ Anterior  Página X de Y (N itens)  Próxima ›" e chama
// onPageChange(novaPagina) quando o usuário clica.
// ---------------------------------------------------------------------------
function smRenderPagination(host, page, totalPages, totalItems, onPageChange) {
  if (!host) return;
  if (totalPages <= 1) { host.innerHTML = ""; return; }

  host.innerHTML = `
    <button class="btn btn-outline btn-sm" id="smPagePrev" ${page <= 1 ? "disabled" : ""}>‹ Anterior</button>
    <span>Página ${page} de ${totalPages} (${totalItems} ${totalItems === 1 ? "item" : "itens"})</span>
    <button class="btn btn-outline btn-sm" id="smPageNext" ${page >= totalPages ? "disabled" : ""}>Próxima ›</button>
  `;
  document.getElementById("smPagePrev")?.addEventListener("click", () => { if (page > 1) onPageChange(page - 1); });
  document.getElementById("smPageNext")?.addEventListener("click", () => { if (page < totalPages) onPageChange(page + 1); });
}
