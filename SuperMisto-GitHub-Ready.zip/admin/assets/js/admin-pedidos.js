const SM_ORDER_STATUSES = [
  "aguardando_pagamento", "pagamento_aprovado", "em_preparacao",
  "pronto_envio", "enviado", "entregue", "cancelado", "reembolsado",
];
const SM_ORDER_STATUS_LABELS = {
  aguardando_pagamento: "Aguardando pagamento",
  pagamento_aprovado: "Pagamento aprovado",
  em_preparacao: "Em preparação",
  pronto_envio: "Pronto para envio",
  enviado: "Enviado",
  entregue: "Entregue",
  cancelado: "Cancelado",
  reembolsado: "Reembolsado",
};

let smOrdersCache = [];
let smOrdersFilter = "all";
let smOrdersPage = 1;

document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("pedidos.html", "Pedidos");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando pedidos...</div>`;

  smOrdersCache = await smGetOrders();

  content.innerHTML = `
    <p class="admin-page-intro">${smOrdersCache.length} pedido(s) no total.</p>
    <div class="admin-toolbar">
      <div class="left">
        <select id="orderStatusFilter">
          <option value="all">Todos os status</option>
          ${SM_ORDER_STATUSES.map((s) => `<option value="${s}">${SM_ORDER_STATUS_LABELS[s]}</option>`).join("")}
        </select>
      </div>
    </div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Pedido</th><th>Cliente</th><th>Data</th><th>Total</th><th>Status</th><th>Pagamento</th><th></th></tr></thead>
        <tbody id="ordersTableBody"></tbody>
      </table>
    </div>
    <div id="ordersPagination" class="admin-pagination"></div>
    <div id="orderDetailModal"></div>
  `;

  document.getElementById("orderStatusFilter").addEventListener("change", (e) => {
    smOrdersFilter = e.target.value;
    smOrdersPage = 1;
    smRenderOrdersTable();
  });

  smRenderOrdersTable();
});

function smRenderOrdersTable() {
  const tbody = document.getElementById("ordersTableBody");
  let orders = smOrdersCache;
  if (smOrdersFilter !== "all") orders = orders.filter((o) => o.status === smOrdersFilter);

  const paginationHost = document.getElementById("ordersPagination");
  if (!orders.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="admin-empty">Nenhum pedido encontrado.</div></td></tr>`;
    paginationHost.innerHTML = "";
    return;
  }

  const pageSize = 15;
  const totalPages = Math.max(1, Math.ceil(orders.length / pageSize));
  if (smOrdersPage > totalPages) smOrdersPage = totalPages;
  const start = (smOrdersPage - 1) * pageSize;
  const pageOrders = orders.slice(start, start + pageSize);
  smRenderPagination(paginationHost, smOrdersPage, totalPages, orders.length, (page) => {
    smOrdersPage = page;
    smRenderOrdersTable();
  });
  orders = pageOrders;

  tbody.innerHTML = orders
    .map((o) => {
      const custName = (o.customer_snapshot && o.customer_snapshot.name) || "—";
      const date = new Date(o.created_at).toLocaleDateString("pt-BR");
      const payPill = o.payment_status === "approved" ? "pill-on" : o.payment_status === "refused" ? "pill-off" : "pill-muted";
      return `
        <tr>
          <td><strong>${o.order_number}</strong></td>
          <td>${smEscapeHTML(custName)}</td>
          <td>${date}</td>
          <td>${formatPrice(o.total)}</td>
          <td><span class="pill pill-on">${SM_ORDER_STATUS_LABELS[o.status] || o.status}</span></td>
          <td><span class="pill ${payPill}">${o.payment_status}</span></td>
          <td><button class="btn btn-outline btn-sm" data-view="${o.id}">Ver</button></td>
        </tr>
      `;
    })
    .join("");

  tbody.querySelectorAll("[data-view]").forEach((btn) =>
    btn.addEventListener("click", () => smOpenOrderDetail(btn.getAttribute("data-view")))
  );
}

async function smOpenOrderDetail(orderId) {
  const modalHost = document.getElementById("orderDetailModal");
  modalHost.innerHTML = `<div class="admin-modal-backdrop"><div class="admin-modal" style="max-width:560px">Carregando...</div></div>`;

  const order = await smGetOrder(orderId);
  if (!order) { modalHost.innerHTML = ""; return; }

  const items = order.order_items || [];
  const history = (order.order_status_history || []).sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  const payment = (order.payments || [])[0];
  const addr = order.shipping_address || {};

  modalHost.innerHTML = `
    <div class="admin-modal-backdrop" id="orderModalBackdrop">
      <div class="admin-modal" style="max-width:600px;max-height:85vh;overflow-y:auto">
        <h3>Pedido ${order.order_number}</h3>

        <div style="margin-bottom:16px">
          <strong>Cliente:</strong> ${smEscapeHTML((order.customer_snapshot || {}).name || "—")}<br>
          <strong>E-mail:</strong> ${smEscapeHTML((order.customer_snapshot || {}).email || "—")}<br>
          <strong>Endereço:</strong> ${smEscapeHTML(addr.street || "")}, ${smEscapeHTML(addr.number || "")} — ${smEscapeHTML(addr.city || "")}/${smEscapeHTML(addr.state || "")} — CEP ${smEscapeHTML(addr.cep || "")}
        </div>

        <table class="admin-table" style="margin-bottom:16px">
          <thead><tr><th>Produto</th><th>Qtd</th><th>Preço</th><th>Subtotal</th></tr></thead>
          <tbody>
            ${items.map((it) => `<tr><td>${smEscapeHTML(it.product_name)}</td><td>${it.quantity}</td><td>${formatPrice(it.unit_price)}</td><td>${formatPrice(it.subtotal)}</td></tr>`).join("")}
          </tbody>
        </table>

        <p><strong>Subtotal:</strong> ${formatPrice(order.subtotal)} · <strong>Frete:</strong> ${formatPrice(order.shipping)} · <strong>Desconto:</strong> ${formatPrice(order.discount)} · <strong>Total:</strong> ${formatPrice(order.total)}</p>

        <div class="admin-field">
          <label>Status do pedido</label>
          <select id="orderStatusSelect">
            ${SM_ORDER_STATUSES.map((s) => `<option value="${s}" ${s === order.status ? "selected" : ""}>${SM_ORDER_STATUS_LABELS[s]}</option>`).join("")}
          </select>
        </div>
        <button class="btn btn-primary btn-sm" id="saveStatusBtn" style="margin-bottom:16px">Salvar status</button>

        <div class="admin-panel" style="background:var(--purple-50);border-color:var(--purple-200)">
          <strong>Pagamento (modo de teste)</strong>
          <p style="font-size:.85rem;color:var(--ink-soft);margin:6px 0 12px">
            Status atual: <span class="pill ${payment && payment.status === "approved" ? "pill-on" : "pill-muted"}">${payment ? payment.status : "—"}</span>
            — ⚠️ simulação, não é um pagamento real (ver netlify/functions/payment-mock-confirm.js).
          </p>
          <button class="btn btn-outline btn-sm" id="simApproveBtn">Simular pagamento aprovado</button>
          <button class="btn btn-outline btn-sm" id="simRefuseBtn">Simular pagamento recusado</button>
        </div>

        <div class="admin-panel" id="fiscalPanel" data-owner-only="1" style="display:none;background:var(--purple-50);border-color:var(--purple-200)">
          <strong>Nota fiscal (Módulo 6)</strong>
          <div id="fiscalStatusArea" style="font-size:.85rem;color:var(--ink-soft);margin:6px 0 12px">Carregando...</div>
          <button class="btn btn-outline btn-sm" id="emitFiscalBtn">Emitir nota fiscal</button>
          <button class="btn btn-outline btn-sm" id="checkFiscalBtn">Verificar status</button>
        </div>

        <h4>Histórico</h4>
        <ul style="font-size:.85rem;color:var(--ink-soft)">
          ${history.map((h) => `<li>${new Date(h.created_at).toLocaleString("pt-BR")} — ${SM_ORDER_STATUS_LABELS[h.status] || h.status}${h.note ? " — " + smEscapeHTML(h.note) : ""}</li>`).join("")}
        </ul>

        <div class="admin-modal-actions">
          <button class="btn btn-outline btn-sm" id="closeOrderModalBtn">Fechar</button>
        </div>
      </div>
    </div>
  `;

  const close = () => { modalHost.innerHTML = ""; };
  document.getElementById("orderModalBackdrop").addEventListener("click", (e) => {
    if (e.target.id === "orderModalBackdrop") close();
  });
  document.getElementById("closeOrderModalBtn").addEventListener("click", close);

  document.getElementById("saveStatusBtn").addEventListener("click", async () => {
    const newStatus = document.getElementById("orderStatusSelect").value;
    const ok = await smUpdateOrderStatus(order.id, newStatus, "Alterado manualmente pelo administrador.");
    if (ok) {
      smToast("Status atualizado.", "success");
      smOrdersCache = await smGetOrders();
      smRenderOrdersTable();
      close();
    }
  });

  document.getElementById("simApproveBtn").addEventListener("click", async () => {
    const ok = await smSimulatePayment(order.id, "approved");
    if (ok) { smToast("Pagamento simulado como aprovado.", "success"); smOrdersCache = await smGetOrders(); smRenderOrdersTable(); close(); }
  });
  document.getElementById("simRefuseBtn").addEventListener("click", async () => {
    const ok = await smSimulatePayment(order.id, "refused");
    if (ok) { smToast("Pagamento simulado como recusado.", "success"); smOrdersCache = await smGetOrders(); smRenderOrdersTable(); close(); }
  });

  // Painel de nota fiscal (Módulo 6) — só aparece para administradores "owner"
  smAdminGetRole().then(async (role) => {
    if (role !== "owner") return;
    const panel = document.getElementById("fiscalPanel");
    panel.style.display = "";
    const statusArea = document.getElementById("fiscalStatusArea");

    const statusLabels = { nao_emitida: "Não emitida", pendente: "Processando na SEFAZ", emitida: "Emitida", erro: "Erro na emissão", cancelada: "Cancelada" };
    async function refreshFiscalStatus() {
      const doc = await smGetFiscalDocument(order.id);
      const status = doc ? doc.status : "nao_emitida";
      statusArea.innerHTML = `Status: <span class="pill ${status === "emitida" ? "pill-on" : status === "erro" ? "pill-off" : "pill-muted"}">${statusLabels[status] || status}</span>` +
        (doc && doc.numero ? ` · Número: ${smEscapeHTML(doc.numero)}` : "") +
        (order.payment_status !== "approved" ? `<br><span style="color:var(--admin-danger)">Só é possível emitir nota de pedidos com pagamento aprovado.</span>` : "");
    }
    await refreshFiscalStatus();

    document.getElementById("emitFiscalBtn").addEventListener("click", async () => {
      const result = await smEmitFiscalInvoice(order.id);
      if (result) { smToast("Emissão solicitada — verifique o status em alguns instantes.", "success"); await refreshFiscalStatus(); }
    });
    document.getElementById("checkFiscalBtn").addEventListener("click", async () => {
      const result = await smCheckFiscalStatus(order.id);
      if (result) { smToast("Status atualizado.", "success"); await refreshFiscalStatus(); }
    });
  });
}
