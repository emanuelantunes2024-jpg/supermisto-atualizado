let smProdutosState = { search: "", category: "all", status: "all", page: 1 };
let smProdutosCache = { products: [], categories: [] };
const SM_PAGE_SIZE = 15;

document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("produtos.html", "Produtos");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando produtos do banco...</div>`;

  const [products, categories] = await Promise.all([smGetProducts(), smGetCategories()]);
  smProdutosCache = { products, categories };

  content.innerHTML = `
    <p class="admin-page-intro">
      ${products.length} produtos cadastrados no banco de dados.
      Adicionar, editar, duplicar ou excluir aqui reflete automaticamente no site público,
      em qualquer dispositivo.
    </p>

    <div class="admin-toolbar">
      <div class="left">
        <input type="search" id="prodSearch" placeholder="Buscar por nome...">
        <select id="prodCategoryFilter"></select>
        <select id="prodStatusFilter">
          <option value="all">Todos os status</option>
          <option value="featured">Em destaque</option>
          <option value="new">Novidade</option>
          <option value="kit">Kit</option>
          <option value="unavailable">Indisponível</option>
        </select>
      </div>
      <a href="produto-form.html" class="btn btn-primary btn-sm">+ Adicionar produto</a>
    </div>

    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Produto</th>
            <th>Categoria</th>
            <th>Preço</th>
            <th>Estoque</th>
            <th>Status</th>
            <th>Disponível</th>
            <th style="text-align:right">Ações</th>
          </tr>
        </thead>
        <tbody id="prodTableBody"></tbody>
      </table>
    </div>
    <div id="prodPagination" class="admin-pagination"></div>
  `;

  const catFilter = document.getElementById("prodCategoryFilter");
  catFilter.innerHTML =
    `<option value="all">Todas as categorias</option>` +
    categories.map((c) => `<option value="${c.slug}">${smEscapeHTML(c.name)}</option>`).join("");

  document.getElementById("prodSearch").addEventListener("input", (e) => {
    smProdutosState.search = e.target.value.toLowerCase();
    smProdutosState.page = 1;
    smRenderProductTable();
  });
  catFilter.addEventListener("change", (e) => {
    smProdutosState.category = e.target.value;
    smProdutosState.page = 1;
    smRenderProductTable();
  });
  document.getElementById("prodStatusFilter").addEventListener("change", (e) => {
    smProdutosState.status = e.target.value;
    smProdutosState.page = 1;
    smRenderProductTable();
  });

  smRenderProductTable();
});

function smRenderProductTable() {
  const tbody = document.getElementById("prodTableBody");
  const categories = smProdutosCache.categories;
  let products = smProdutosCache.products;

  if (smProdutosState.search) {
    products = products.filter((p) => p.name.toLowerCase().includes(smProdutosState.search));
  }
  if (smProdutosState.category !== "all") {
    products = products.filter((p) => p.category === smProdutosState.category);
  }
  if (smProdutosState.status !== "all") {
    products = products.filter((p) => {
      if (smProdutosState.status === "featured") return !!p.featured;
      if (smProdutosState.status === "new") return !!p.isNew;
      if (smProdutosState.status === "kit") return !!p.isKit;
      if (smProdutosState.status === "unavailable") return p.available === false;
      return true;
    });
  }

  const paginationHost = document.getElementById("prodPagination");
  if (!products.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="admin-empty">Nenhum produto encontrado com esses filtros.</div></td></tr>`;
    paginationHost.innerHTML = "";
    return;
  }

  const totalPages = Math.max(1, Math.ceil(products.length / SM_PAGE_SIZE));
  if (smProdutosState.page > totalPages) smProdutosState.page = totalPages;
  const start = (smProdutosState.page - 1) * SM_PAGE_SIZE;
  const pageProducts = products.slice(start, start + SM_PAGE_SIZE);
  smRenderPagination(paginationHost, smProdutosState.page, totalPages, products.length, (page) => {
    smProdutosState.page = page;
    smRenderProductTable();
  });
  products = pageProducts;

  tbody.innerHTML = products
    .map((p) => {
      const cat = categories.find((c) => c.slug === p.category);
      const media = p.image
        ? `<img src="${p.image.startsWith('http') ? p.image : '../' + p.image}" alt="" onerror="this.parentElement.textContent='${p.emoji || '🌶️'}'">`
        : (p.emoji || "🌶️");
      const badges = [
        p.featured ? `<span class="pill pill-featured">Destaque</span>` : "",
        p.isNew ? `<span class="pill pill-new">Novidade</span>` : "",
        p.isKit ? `<span class="pill pill-kit">Kit</span>` : "",
      ].filter(Boolean).join(" ") || `<span class="pill pill-muted">—</span>`;
      const available = p.available === false
        ? `<span class="pill pill-off">Indisponível</span>`
        : `<span class="pill pill-on">Disponível</span>`;

      return `
        <tr>
          <td>
            <div class="admin-cell-product">
              <span class="admin-cell-emoji">${media}</span>
              <div>
                <strong>${smEscapeHTML(p.name)}</strong><br>
                <span style="font-size:.78rem;color:var(--ink-soft)">${smEscapeHTML(p.id)}</span>
              </div>
            </div>
          </td>
          <td>${smEscapeHTML(cat ? cat.name : (p.category || 'Sem categoria'))}</td>
          <td>${formatPrice(p.price)}</td>
          <td>${p.trackStock ? `<span class="pill ${p.stockQuantity > 0 ? 'pill-on' : 'pill-off'}">${p.stockQuantity} un.</span>` : `<span class="pill pill-muted">Não controla</span>`}</td>
          <td>${badges}</td>
          <td>${available}</td>
          <td>
            <div class="admin-table-actions" style="justify-content:flex-end">
              <a class="btn-icon" title="Editar" href="produto-form.html?id=${encodeURIComponent(p.id)}">✏️</a>
              <button class="btn-icon" title="Duplicar" data-dup="${p.id}">⧉</button>
              <button class="btn-icon danger" title="Excluir" data-del="${p.id}">🗑️</button>
            </div>
          </td>
        </tr>
      `;
    })
    .join("");

  tbody.querySelectorAll("[data-dup]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      const copy = await smDuplicateProduct(btn.getAttribute("data-dup"));
      if (copy) {
        smToast(`Produto duplicado: "${copy.name}"`, "success");
        smProdutosCache.products = await smGetProducts();
        smRenderProductTable();
      } else {
        btn.disabled = false;
      }
    });
  });

  tbody.querySelectorAll("[data-del]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-del");
      const product = smProdutosCache.products.find((p) => p.id === id);
      smConfirm(
        "Excluir produto",
        `Tem certeza que deseja excluir "${smEscapeHTML(product?.name || id)}"? Essa ação não pode ser desfeita.`,
        async () => {
          const ok = await smDeleteProduct(id);
          if (ok) {
            smToast("Produto excluído.", "success");
            smProdutosCache.products = await smGetProducts();
            smRenderProductTable();
          }
        },
        "Excluir"
      );
    });
  });
}
