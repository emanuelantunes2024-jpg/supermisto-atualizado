let smSellersCache = [];
let smSellerSalesCache = [];

document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("vendedores.html", "Vendedores");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando vendedores...</div>`;

  const [sellers, sales] = await Promise.all([smGetSellers(), smGetAllOrderItemsWithSeller()]);
  smSellersCache = sellers;
  smSellerSalesCache = sales;

  content.innerHTML = `
    <p class="admin-page-intro">
      Vendedores do marketplace SuperMisto. Cada vendedor gerencia os próprios produtos
      pelo portal em <code>/vendedor</code>, com login separado do painel administrativo.
      Produtos sem vendedor continuam sendo da própria loja (como os 48 originais).
    </p>
    <div class="admin-toolbar">
      <div class="left"></div>
      <button class="btn btn-primary btn-sm" id="newSellerBtn">+ Adicionar vendedor</button>
    </div>
    <div class="admin-grid-cards" id="sellerGrid"></div>
  `;

  document.getElementById("newSellerBtn").addEventListener("click", smOpenNewSellerModal);
  smRenderSellerGrid();
});

function smRenderSellerGrid() {
  const grid = document.getElementById("sellerGrid");
  if (!smSellersCache.length) {
    grid.innerHTML = `<div class="admin-empty">Nenhum vendedor cadastrado ainda.</div>`;
    return;
  }

  const statusPill = { pending: "pill-muted", active: "pill-on", suspended: "pill-off" };
  const statusLabel = { pending: "Pendente", active: "Ativo", suspended: "Suspenso" };

  grid.innerHTML = smSellersCache
    .map((s) => {
      const approvedSales = smSellerSalesCache.filter((it) => it.seller_id === s.id && it.orders && it.orders.payment_status === "approved");
      const totalSold = approvedSales.reduce((sum, it) => sum + Number(it.subtotal || 0), 0);
      const commission = totalSold * (Number(s.commission_rate) / 100);
      const payout = totalSold - commission;

      return `
        <div class="admin-mini-card">
          <h3>${smEscapeHTML(s.store_name || "(sem nome)")}</h3>
          <p>${smEscapeHTML(s.email)}${s.phone ? " · " + smEscapeHTML(s.phone) : ""}</p>
          <div class="meta">
            <span class="pill ${statusPill[s.status]}">${statusLabel[s.status]}</span>
            · Comissão: ${s.commission_rate}%
          </div>
          <div class="meta" style="margin-top:6px">
            ${approvedSales.length} vendas pagas · Total vendido: ${formatPrice(totalSold)}<br>
            A repassar ao vendedor: <strong>${formatPrice(payout)}</strong>
          </div>
          <div class="row-actions" style="margin-top:10px">
            ${s.status !== "active" ? `<button class="btn btn-outline btn-sm" data-status="${s.id}|active">Ativar</button>` : ""}
            ${s.status !== "suspended" ? `<button class="btn btn-outline btn-sm" data-status="${s.id}|suspended">Suspender</button>` : ""}
            <button class="btn-icon" title="Ajustar comissão" data-commission="${s.id}">%</button>
          </div>
        </div>
      `;
    })
    .join("");

  grid.querySelectorAll("[data-status]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const [id, status] = btn.getAttribute("data-status").split("|");
      const ok = await smUpdateSellerStatus(id, status);
      if (ok) {
        smToast("Status atualizado.", "success");
        const s = smSellersCache.find((x) => x.id === id);
        if (s) s.status = status;
        smRenderSellerGrid();
      }
    })
  );

  grid.querySelectorAll("[data-commission]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-commission");
      const seller = smSellersCache.find((s) => s.id === id);
      const novo = prompt("Nova taxa de comissão (%) para " + seller.store_name + ":", seller.commission_rate);
      if (novo === null) return;
      const rate = parseFloat(novo);
      if (isNaN(rate) || rate < 0 || rate > 100) { smToast("Valor inválido (use 0 a 100).", "error"); return; }
      const ok = await smUpdateSellerCommission(id, rate);
      if (ok) { smToast("Comissão atualizada.", "success"); seller.commission_rate = rate; smRenderSellerGrid(); }
    })
  );
}

function smOpenNewSellerModal() {
  const backdrop = document.createElement("div");
  backdrop.className = "admin-modal-backdrop";
  backdrop.innerHTML = `
    <div class="admin-modal" style="max-width:420px" role="dialog" aria-modal="true">
      <h3>Novo vendedor</h3>
      <p style="font-size:.85rem">A conta é criada como "pendente" — ative depois de conferir os dados.</p>
      <form id="newSellerForm">
        <div class="admin-field"><label>Nome da loja/vendedor</label><input type="text" id="ns_name" required></div>
        <div class="admin-field"><label>E-mail</label><input type="email" id="ns_email" required></div>
        <div class="admin-field"><label>Telefone</label><input type="text" id="ns_phone"></div>
        <div class="admin-field"><label>Senha provisória</label><input type="password" id="ns_pass" required minlength="6"></div>
        <div class="admin-field"><label>Comissão da loja (%)</label><input type="number" id="ns_commission" min="0" max="100" step="0.5" value="15"></div>
        <div class="admin-modal-actions">
          <button type="button" class="btn btn-outline btn-sm" id="nsCancelBtn">Cancelar</button>
          <button type="submit" class="btn btn-primary btn-sm" id="nsSubmitBtn">Criar vendedor</button>
        </div>
      </form>
    </div>
  `;
  document.body.appendChild(backdrop);
  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
  document.getElementById("nsCancelBtn").addEventListener("click", () => backdrop.remove());

  document.getElementById("newSellerForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("nsSubmitBtn");
    btn.disabled = true;
    btn.textContent = "Criando...";

    const ok = await smCreateSeller(
      document.getElementById("ns_email").value.trim(),
      document.getElementById("ns_pass").value,
      document.getElementById("ns_name").value.trim(),
      document.getElementById("ns_phone").value.trim(),
      parseFloat(document.getElementById("ns_commission").value) || 15
    );

    if (ok) {
      smToast("Vendedor criado.", "success");
      backdrop.remove();
      setTimeout(() => window.location.reload(), 600);
    } else {
      btn.disabled = false;
      btn.textContent = "Criar vendedor";
    }
  });
}
