let smCatCache = [];

document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("categorias.html", "Categorias");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando categorias...</div>`;

  content.innerHTML = `
    <p class="admin-page-intro">
      Categorias existentes do catálogo. Desativar uma categoria a esconde da navegação
      do site público, mas os produtos dela continuam existindo (não são apagados).
    </p>
    <div class="admin-toolbar">
      <div class="left"></div>
      <button class="btn btn-primary btn-sm" id="newCatBtn">+ Adicionar categoria</button>
    </div>
    <div class="admin-grid-cards" id="catGrid"><div class="admin-empty">Carregando...</div></div>
  `;

  document.getElementById("newCatBtn").addEventListener("click", () => smOpenCategoryModal(null));
  await smRenderCategoryGrid();
});

async function smRenderCategoryGrid() {
  const grid = document.getElementById("catGrid");
  smCatCache = await smGetCategories();
  const counts = await Promise.all(smCatCache.map((c) => smCategoryProductCount(c.slug)));

  if (!smCatCache.length) {
    grid.innerHTML = `<div class="admin-empty">Nenhuma categoria cadastrada ainda.</div>`;
    return;
  }

  grid.innerHTML = smCatCache
    .map((c, i) => {
      const count = counts[i];
      const active = c.active !== false;
      return `
        <div class="admin-mini-card">
          <div class="icon" style="background:${c.bg || "#F0E4F7"};color:${c.fg || "#3A1150"}">${c.icon || "⭐"}</div>
          <h3>${smEscapeHTML(c.name)}</h3>
          <p>${smEscapeHTML(c.desc || "")}</p>
          <div class="meta">
            ${count} produto${count === 1 ? "" : "s"} ·
            <span class="pill ${active ? "pill-on" : "pill-off"}">${active ? "Ativa" : "Inativa"}</span>
          </div>
          <div class="row-actions">
            <button class="btn btn-outline btn-sm" data-edit="${c.slug}">Editar</button>
            <button class="btn-icon" title="${active ? "Desativar" : "Ativar"}" data-toggle="${c.slug}">${active ? "🙈" : "👁️"}</button>
            <button class="btn-icon danger" title="Excluir" data-del="${c.slug}">🗑️</button>
          </div>
        </div>
      `;
    })
    .join("");

  grid.querySelectorAll("[data-edit]").forEach((btn) =>
    btn.addEventListener("click", () => smOpenCategoryModal(smCatCache.find((c) => c.slug === btn.getAttribute("data-edit"))))
  );

  grid.querySelectorAll("[data-toggle]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const slug = btn.getAttribute("data-toggle");
      const cat = smCatCache.find((c) => c.slug === slug);
      btn.disabled = true;
      const ok = await smUpdateCategory(slug, Object.assign({}, cat, { active: cat.active === false }));
      if (ok) {
        smToast(cat.active === false ? "Categoria ativada." : "Categoria desativada.", "success");
        await smRenderCategoryGrid();
      } else {
        btn.disabled = false;
      }
    })
  );

  grid.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const slug = btn.getAttribute("data-del");
      const count = counts[smCatCache.findIndex((c) => c.slug === slug)];
      const msg = count
        ? `Esta categoria tem ${count} produto(s). Eles NÃO serão apagados, mas ficarão sem uma categoria válida até você editá-los. Deseja continuar?`
        : "Tem certeza que deseja excluir esta categoria?";
      smConfirm("Excluir categoria", msg, async () => {
        const ok = await smDeleteCategory(slug);
        if (ok) {
          smToast("Categoria excluída.", "success");
          await smRenderCategoryGrid();
        }
      }, "Excluir");
    })
  );
}

function smOpenCategoryModal(existing) {
  const isEdit = !!existing;
  const c = existing || {};

  const backdrop = document.createElement("div");
  backdrop.className = "admin-modal-backdrop";
  backdrop.innerHTML = `
    <div class="admin-modal" style="max-width:480px" role="dialog" aria-modal="true">
      <h3>${isEdit ? "Editar categoria" : "Nova categoria"}</h3>
      <form id="catForm">
        <div class="admin-field">
          <label>Nome *</label>
          <input type="text" id="cf_name" required value="${smEscapeHTML(c.name || "")}">
        </div>
        ${isEdit ? "" : `
        <div class="admin-field">
          <label>Identificador (slug) *</label>
          <input type="text" id="cf_slug" required placeholder="ex: temperos" value="${smEscapeHTML(c.slug || "")}">
          <div class="admin-form-hint">Usado nas URLs (produtos.html?categoria=slug). Só letras minúsculas, números e hífen.</div>
        </div>`}
        <div class="admin-field">
          <label>Descrição curta</label>
          <input type="text" id="cf_desc" value="${smEscapeHTML(c.desc || "")}">
        </div>
        <div class="admin-field">
          <label>Ícone (emoji)</label>
          <input type="text" id="cf_icon" maxlength="4" value="${smEscapeHTML(c.icon || "⭐")}">
        </div>
        <div class="admin-field">
          <label>Imagem da categoria</label>
          <input type="file" id="cf_imageFile" accept="image/*">
          <div class="admin-form-hint" id="cf_imageStatus">${c.image ? "Imagem atual definida." : "Nenhuma imagem enviada ainda."}</div>
        </div>
        <div class="admin-field">
          <label>Cor de fundo</label>
          <input type="text" id="cf_bg" value="${smEscapeHTML(c.bg || "#F0E4F7")}">
        </div>
        <div class="admin-field">
          <label>Cor do ícone/texto</label>
          <input type="text" id="cf_fg" value="${smEscapeHTML(c.fg || "#3A1150")}">
        </div>
        <div class="admin-checkbox-row">
          <input type="checkbox" id="cf_active" ${c.active === false ? "" : "checked"}>
          <label for="cf_active">Categoria ativa (visível no site público)</label>
        </div>
        <div class="admin-modal-actions">
          <button type="button" class="btn btn-outline btn-sm" id="catCancelBtn">Cancelar</button>
          <button type="submit" class="btn btn-primary btn-sm" id="catSubmitBtn">${isEdit ? "Salvar" : "Adicionar"}</button>
        </div>
      </form>
    </div>
  `;
  document.body.appendChild(backdrop);

  let uploadedImage = c.image || "";
  document.getElementById("cf_imageFile").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById("cf_imageStatus");
    statusEl.textContent = "Enviando imagem...";
    const url = await smUploadImage(file, "products");
    if (url) {
      uploadedImage = url;
      statusEl.textContent = "Imagem enviada ✓";
    } else {
      statusEl.textContent = "Falha ao enviar. Tente novamente.";
    }
  });

  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
  document.getElementById("catCancelBtn").addEventListener("click", () => backdrop.remove());

  document.getElementById("catForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const submitBtn = document.getElementById("catSubmitBtn");
    submitBtn.disabled = true;

    const data = {
      name: document.getElementById("cf_name").value.trim(),
      desc: document.getElementById("cf_desc").value.trim(),
      icon: document.getElementById("cf_icon").value.trim() || "⭐",
      image: uploadedImage || undefined,
      bg: document.getElementById("cf_bg").value.trim() || "#F0E4F7",
      fg: document.getElementById("cf_fg").value.trim() || "#3A1150",
      active: document.getElementById("cf_active").checked,
    };

    let ok;
    if (isEdit) {
      ok = await smUpdateCategory(existing.slug, data);
      if (ok) smToast("Categoria atualizada.", "success");
    } else {
      const slug = smSlugify(document.getElementById("cf_slug").value);
      if (!slug) { submitBtn.disabled = false; return; }
      const dupe = smCatCache.find((cc) => cc.slug === slug);
      if (dupe) {
        smToast("Já existe uma categoria com esse identificador.", "error");
        submitBtn.disabled = false;
        return;
      }
      data.slug = slug;
      ok = await smAddCategory(data);
      if (ok) smToast("Categoria adicionada.", "success");
    }

    if (ok) {
      backdrop.remove();
      await smRenderCategoryGrid();
    } else {
      submitBtn.disabled = false;
    }
  });
}
