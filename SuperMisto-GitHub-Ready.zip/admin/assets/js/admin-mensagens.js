let smMessagesCache = [];
let smMessagesFilter = "all";

document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("mensagens.html", "Mensagens");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando mensagens...</div>`;

  smMessagesCache = await smGetContactMessages();

  content.innerHTML = `
    <p class="admin-page-intro">
      Mensagens enviadas pelo formulário de contato do site (${smMessagesCache.length} no total).
      A notificação por e-mail só funciona se estiver configurada — ver PROJETO.md.
    </p>
    <div class="admin-toolbar">
      <div class="left">
        <select id="msgFilter">
          <option value="all">Todas</option>
          <option value="novo">Novas</option>
          <option value="lido">Lidas</option>
          <option value="respondido">Respondidas</option>
        </select>
      </div>
    </div>
    <div id="msgList"></div>
  `;

  document.getElementById("msgFilter").addEventListener("change", (e) => {
    smMessagesFilter = e.target.value;
    smRenderMessages();
  });

  smRenderMessages();
});

function smRenderMessages() {
  const host = document.getElementById("msgList");
  let messages = smMessagesCache;
  if (smMessagesFilter !== "all") messages = messages.filter((m) => m.status === smMessagesFilter);

  if (!messages.length) {
    host.innerHTML = `<div class="admin-empty">Nenhuma mensagem encontrada.</div>`;
    return;
  }

  const statusPill = { novo: "pill-featured", lido: "pill-muted", respondido: "pill-on" };

  host.innerHTML = messages
    .map(
      (m) => `
    <div class="admin-panel" style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:8px">
        <div>
          <strong>${smEscapeHTML(m.name || "Sem nome")}</strong>
          <span style="color:var(--ink-soft);font-size:.85rem"> · ${smEscapeHTML(m.email)}${m.phone ? " · " + smEscapeHTML(m.phone) : ""}</span>
        </div>
        <span class="pill ${statusPill[m.status] || "pill-muted"}">${m.status}</span>
      </div>
      <p style="white-space:pre-wrap;margin:0 0 12px;color:var(--ink)">${smEscapeHTML(m.message)}</p>
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <span style="font-size:.78rem;color:var(--ink-soft)">${new Date(m.created_at).toLocaleString("pt-BR")}</span>
        <div class="admin-table-actions">
          <a href="mailto:${encodeURIComponent(m.email)}" class="btn btn-outline btn-sm">Responder por e-mail</a>
          ${m.status !== "lido" ? `<button class="btn btn-outline btn-sm" data-mark="${m.id}|lido">Marcar como lida</button>` : ""}
          ${m.status !== "respondido" ? `<button class="btn btn-outline btn-sm" data-mark="${m.id}|respondido">Marcar como respondida</button>` : ""}
        </div>
      </div>
    </div>
  `
    )
    .join("");

  host.querySelectorAll("[data-mark]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const [id, status] = btn.getAttribute("data-mark").split("|");
      const ok = await smUpdateContactMessageStatus(id, status);
      if (ok) {
        const msg = smMessagesCache.find((m) => m.id === id);
        if (msg) msg.status = status;
        smToast("Status atualizado.", "success");
        smRenderMessages();
      }
    })
  );
}
