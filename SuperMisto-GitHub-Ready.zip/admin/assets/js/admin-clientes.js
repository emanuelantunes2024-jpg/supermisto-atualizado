document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("clientes.html", "Clientes");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando clientes...</div>`;

  const [customers, orders] = await Promise.all([smGetCustomers(), smGetOrders()]);

  content.innerHTML = `
    <p class="admin-page-intro">${customers.length} cliente(s) cadastrado(s).</p>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Nome</th><th>E-mail</th><th>Telefone</th><th>Pedidos</th><th>Cadastro</th></tr></thead>
        <tbody>
          ${customers.length
            ? customers.map((c) => {
                const orderCount = orders.filter((o) => o.customer_id === c.id).length;
                return `
                  <tr>
                    <td>${smEscapeHTML(c.name || "—")}</td>
                    <td>${smEscapeHTML(c.email)}</td>
                    <td>${smEscapeHTML(c.phone || "—")}</td>
                    <td>${orderCount}</td>
                    <td>${new Date(c.created_at).toLocaleDateString("pt-BR")}</td>
                  </tr>
                `;
              }).join("")
            : `<tr><td colspan="5"><div class="admin-empty">Nenhum cliente cadastrado ainda.</div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
});
