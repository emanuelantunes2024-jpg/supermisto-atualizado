document.addEventListener("DOMContentLoaded", async () => {
  const params = new URLSearchParams(window.location.search);
  const editId = params.get("id");

  renderAdminShell("produtos.html", editId ? "Editar produto" : "Novo produto");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando...</div>`;

  const [categories, existing] = await Promise.all([
    smGetCategories(),
    editId ? smGetProduct(editId) : Promise.resolve(null),
  ]);

  if (editId && !existing) {
    content.innerHTML = `<div class="admin-empty">Produto não encontrado. <a href="produtos.html">Voltar para produtos</a>.</div>`;
    return;
  }

  const isEdit = !!existing;
  const p = existing || {};
  const catOptions =
    (p.category && !categories.some((c) => c.slug === p.category)
      ? `<option value="${smEscapeHTML(p.category)}" selected>(categoria removida: ${smEscapeHTML(p.category)})</option>`
      : "") +
    categories
      .map((c) => `<option value="${c.slug}" ${existing && existing.category === c.slug ? "selected" : ""}>${smEscapeHTML(c.name)}</option>`)
      .join("");

  let uploadedImage = p.image || "";
  let uploadedImages = (p.images || []).slice();

  content.innerHTML = `
    <a href="produtos.html" class="admin-back-link">← Voltar para produtos</a>

    ${isEdit ? "" : `<div class="admin-warning-banner">O identificador (ID) do produto é gerado automaticamente a partir do nome e não pode ser alterado depois de criado.</div>`}

    <form id="productForm" class="admin-panel">
      <h2>${isEdit ? "Editar produto" : "Novo produto"}</h2>

      <div class="admin-form-grid cols-2">
        <div class="admin-field span-2">
          <label for="f_name">Nome *</label>
          <input type="text" id="f_name" required value="${smEscapeHTML(p.name || "")}">
        </div>

        <div class="admin-field">
          <label for="f_category">Categoria *</label>
          <select id="f_category" required>${catOptions}</select>
        </div>

        <div class="admin-field">
          <label for="f_weight">Peso / volume</label>
          <input type="text" id="f_weight" placeholder="ex: 100g, 250ml, Kit com 3" value="${smEscapeHTML(p.weight || "")}">
        </div>

        <div class="admin-field">
          <label for="f_price">Preço (R$) *</label>
          <input type="number" id="f_price" step="0.01" min="0" required value="${p.price ?? ""}">
        </div>

        <div class="admin-field">
          <label for="f_salePrice">Preço promocional (R$)</label>
          <input type="number" id="f_salePrice" step="0.01" min="0" value="${p.salePrice ?? ""}">
          <div class="admin-form-hint">Deixe em branco se o produto não estiver em promoção.</div>
        </div>

        <div class="admin-field">
          <label for="f_costPrice">Custo (R$) — uso interno</label>
          <input type="number" id="f_costPrice" step="0.01" min="0" value="${p.costPrice ?? ""}">
          <div class="admin-form-hint">Não aparece no site público. Fica só no painel para você calcular margem.</div>
        </div>

        <div class="admin-field">
          <label for="f_stockQuantity">Estoque (unidades)</label>
          <input type="number" id="f_stockQuantity" step="1" min="0" value="${p.stockQuantity ?? 0}">
          <div class="admin-form-hint">Só é validado no carrinho/checkout se "Controlar estoque" estiver marcado abaixo.</div>
        </div>

        <div class="admin-field">
          <label for="f_ncm">NCM (fiscal, opcional)</label>
          <input type="text" id="f_ncm" placeholder="0000.00.00" value="${smEscapeHTML(p.ncm || "")}">
        </div>

        <div class="admin-field">
          <label for="f_cfop">CFOP (fiscal, opcional)</label>
          <input type="text" id="f_cfop" placeholder="5102" value="${smEscapeHTML(p.cfop || "")}">
        </div>

        <div class="admin-field span-2">
          <label for="f_shortDesc">Descrição curta (aparece nos cartões)</label>
          <textarea id="f_shortDesc" rows="2">${smEscapeHTML(p.shortDesc || "")}</textarea>
        </div>

        <div class="admin-field span-2">
          <label for="f_description">Descrição completa (aparece na página do produto)</label>
          <textarea id="f_description" rows="4">${smEscapeHTML(p.description || "")}</textarea>
        </div>

        <div class="admin-field">
          <label for="f_emoji">Emoji ilustrativo</label>
          <input type="text" id="f_emoji" maxlength="4" placeholder="🌶️" value="${smEscapeHTML(p.emoji || "")}">
          <div class="admin-form-hint">Usado como ilustração enquanto não há foto real.</div>
        </div>

        <div class="admin-field">
          <label for="f_buyLink">Link de compra (Shopee, etc.)</label>
          <input type="text" id="f_buyLink" placeholder="https://..." value="${smEscapeHTML(p.buyLink || "")}">
        </div>

        <div class="admin-field span-2">
          <label>Imagem principal</label>
          <input type="file" id="f_imageFile" accept="image/*">
          <div class="admin-form-hint" id="f_imageStatus">${uploadedImage ? "Imagem atual: " + smEscapeHTML(uploadedImage) : "Nenhuma imagem enviada ainda — o produto usa o emoji acima."}</div>
        </div>

        <div class="admin-field span-2">
          <label>Galeria — fotos adicionais (Módulo 5)</label>
          <input type="file" id="f_galleryFile" accept="image/*">
          <div class="admin-form-hint">Cada imagem enviada aqui é adicionada à galeria da página do produto (além da imagem principal).</div>
          <div id="f_galleryList" class="admin-gallery-list"></div>
        </div>

        <div class="admin-field">
          <label for="f_whatsappLink">Mensagem de WhatsApp específica (opcional)</label>
          <input type="text" id="f_whatsappLink" placeholder="Ex: Olá! Quero saber mais sobre..." value="${smEscapeHTML(p.whatsappMessage || "")}">
          <div class="admin-form-hint">Se vazio, usa a mensagem padrão do WhatsApp definida em Configurações.</div>
        </div>
      </div>

      <div class="admin-checkbox-row">
        <input type="checkbox" id="f_available" ${p.available === false ? "" : "checked"}>
        <label for="f_available">Disponível para venda</label>
      </div>
      <div class="admin-checkbox-row">
        <input type="checkbox" id="f_trackStock" ${p.trackStock ? "checked" : ""}>
        <label for="f_trackStock">Controlar estoque (valida quantidade no carrinho/checkout)</label>
      </div>
      <div class="admin-checkbox-row">
        <input type="checkbox" id="f_featured" ${p.featured ? "checked" : ""}>
        <label for="f_featured">Produto em destaque (aparece na Home)</label>
      </div>
      <div class="admin-checkbox-row">
        <input type="checkbox" id="f_isNew" ${p.isNew ? "checked" : ""}>
        <label for="f_isNew">Novidade</label>
      </div>
      <div class="admin-checkbox-row">
        <input type="checkbox" id="f_isKit" ${p.isKit ? "checked" : ""}>
        <label for="f_isKit">Kit</label>
      </div>

      <div class="admin-form-actions">
        <a href="produtos.html" class="btn btn-outline">Cancelar</a>
        <button type="submit" class="btn btn-primary" id="productSubmitBtn">${isEdit ? "Salvar alterações" : "Adicionar produto"}</button>
      </div>
    </form>

    ${isEdit ? `
    <div class="admin-panel">
      <h2>Histórico de alterações (Módulo 5)</h2>
      <div id="auditHistoryList" class="admin-empty">Carregando histórico...</div>
    </div>` : ""}
  `;

  if (isEdit) {
    smGetAuditLog("products", existing.id).then((entries) => {
      const host = document.getElementById("auditHistoryList");
      if (!entries.length) {
        host.innerHTML = `<div class="admin-empty">Nenhuma alteração registrada ainda para este produto.</div>`;
        return;
      }
      const actionLabels = { insert: "Criado", update: "Editado", delete: "Excluído" };
      host.outerHTML = `
        <ul id="auditHistoryList" style="font-size:.85rem;color:var(--ink-soft);list-style:none;padding:0;margin:0">
          ${entries.map((e) => `<li style="padding:8px 0;border-top:1px solid var(--admin-border)">
            <strong>${actionLabels[e.action] || e.action}</strong> em ${new Date(e.created_at).toLocaleString("pt-BR")}
            ${e.changed_by_email ? "por " + smEscapeHTML(e.changed_by_email) : ""}
          </li>`).join("")}
        </ul>
      `;
    });
  }

  // Upload de imagem: assim que o arquivo é escolhido, já envia para o
  // Supabase Storage (bucket "products") e guarda a URL pública retornada.
  document.getElementById("f_imageFile").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById("f_imageStatus");
    statusEl.textContent = "Enviando imagem...";
    const url = await smUploadImage(file, "products");
    if (url) {
      uploadedImage = url;
      statusEl.textContent = "Imagem enviada ✓";
      smToast("Imagem enviada.", "success");
    } else {
      statusEl.textContent = "Falha ao enviar imagem. Tente novamente.";
    }
  });

  // Galeria (Módulo 5): cada arquivo escolhido é enviado e somado à lista
  // de imagens adicionais do produto.
  function smRenderGalleryList() {
    const list = document.getElementById("f_galleryList");
    if (!uploadedImages.length) {
      list.innerHTML = `<p class="admin-form-hint" style="margin-top:8px">Nenhuma foto adicional ainda.</p>`;
      return;
    }
    list.innerHTML = uploadedImages
      .map((url, i) => `
        <div class="admin-gallery-item">
          <img src="${url.startsWith("http") ? url : "../" + url}" alt="">
          <button type="button" class="btn-icon danger" data-gallery-remove="${i}" title="Remover">🗑️</button>
        </div>
      `)
      .join("");
    list.querySelectorAll("[data-gallery-remove]").forEach((btn) =>
      btn.addEventListener("click", () => {
        uploadedImages.splice(parseInt(btn.getAttribute("data-gallery-remove"), 10), 1);
        smRenderGalleryList();
      })
    );
  }
  smRenderGalleryList();

  document.getElementById("f_galleryFile").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const url = await smUploadImage(file, "products");
    if (url) {
      uploadedImages.push(url);
      smRenderGalleryList();
      smToast("Foto adicionada à galeria.", "success");
    }
    e.target.value = "";
  });

  document.getElementById("productForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("f_name").value.trim();
    if (!name) return;

    const submitBtn = document.getElementById("productSubmitBtn");
    submitBtn.disabled = true;
    submitBtn.textContent = "Salvando...";

    const data = {
      name,
      category: document.getElementById("f_category").value,
      weight: document.getElementById("f_weight").value.trim(),
      price: parseFloat(document.getElementById("f_price").value) || 0,
      salePrice: document.getElementById("f_salePrice").value
        ? parseFloat(document.getElementById("f_salePrice").value)
        : undefined,
      costPrice: document.getElementById("f_costPrice").value
        ? parseFloat(document.getElementById("f_costPrice").value)
        : undefined,
      stockQuantity: document.getElementById("f_stockQuantity").value
        ? parseInt(document.getElementById("f_stockQuantity").value, 10)
        : 0,
      trackStock: document.getElementById("f_trackStock").checked,
      ncm: document.getElementById("f_ncm").value.trim(),
      cfop: document.getElementById("f_cfop").value.trim(),
      shortDesc: document.getElementById("f_shortDesc").value.trim(),
      description: document.getElementById("f_description").value.trim(),
      emoji: document.getElementById("f_emoji").value.trim(),
      image: uploadedImage || undefined,
      images: uploadedImages,
      buyLink: document.getElementById("f_buyLink").value.trim() || "#",
      whatsappMessage: document.getElementById("f_whatsappLink").value.trim() || undefined,
      available: document.getElementById("f_available").checked,
      featured: document.getElementById("f_featured").checked,
      isNew: document.getElementById("f_isNew").checked,
      isKit: document.getElementById("f_isKit").checked,
    };

    let ok;
    if (isEdit) {
      ok = await smUpdateProduct(existing.id, data);
      if (ok) smToast("Produto atualizado.", "success");
    } else {
      data.id = await smUniqueProductId(name);
      ok = await smAddProduct(data);
      if (ok) smToast("Produto adicionado.", "success");
    }

    if (ok) {
      window.location.href = "produtos.html";
    } else {
      submitBtn.disabled = false;
      submitBtn.textContent = isEdit ? "Salvar alterações" : "Adicionar produto";
    }
  });
});
