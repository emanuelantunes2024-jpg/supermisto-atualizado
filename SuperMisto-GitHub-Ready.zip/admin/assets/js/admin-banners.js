let smBannerCache = [];

document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("banners.html", "Banners");
  const content = document.getElementById("adminContent");

  content.innerHTML = `
    <p class="admin-page-intro">
      Banners promocionais exibidos na Home, logo abaixo do topo. Só aparecem no
      site público quando estiverem marcados como "ativo". Sem imagem definida,
      o banner usa um fundo roxo de fábrica para nunca ficar "quebrado".
    </p>
    <div class="admin-toolbar">
      <div class="left"></div>
      <button class="btn btn-primary btn-sm" id="newBannerBtn">+ Adicionar banner</button>
    </div>
    <div class="admin-grid-cards" id="bannerGrid"><div class="admin-empty">Carregando...</div></div>
  `;

  document.getElementById("newBannerBtn").addEventListener("click", () => smOpenBannerModal(null));
  await smRenderBannerGrid();
});

async function smRenderBannerGrid() {
  const grid = document.getElementById("bannerGrid");
  smBannerCache = (await smGetBanners()).sort((a, b) => (a.order || 0) - (b.order || 0));

  if (!smBannerCache.length) {
    grid.innerHTML = `<div class="admin-empty">Nenhum banner cadastrado ainda. Clique em "Adicionar banner" para criar o primeiro.</div>`;
    return;
  }

  grid.innerHTML = smBannerCache
    .map((b) => {
      const active = !!b.active;
      const preview = b.image ? `style="background-image:url('${b.image}')"` : "";
      return `
        <div class="admin-banner-card">
          <div class="preview" ${preview}>${b.image ? "" : "Sem imagem"}</div>
          <div class="body">
            <h3>${smEscapeHTML(b.title || "(sem título)")}</h3>
            <p>${smEscapeHTML(b.subtitle || "")}</p>
            <div class="meta" style="font-size:.78rem;color:var(--ink-soft);margin-bottom:10px">
              Ordem: ${b.order ?? 0} ·
              <span class="pill ${active ? "pill-on" : "pill-off"}">${active ? "Ativo" : "Inativo"}</span>
            </div>
            <div class="row-actions">
              <div class="admin-table-actions">
                <button class="btn-icon" title="Editar" data-edit="${b.id}">✏️</button>
                <button class="btn-icon" title="${active ? "Desativar" : "Ativar"}" data-toggle="${b.id}">${active ? "🙈" : "👁️"}</button>
                <button class="btn-icon danger" title="Excluir" data-del="${b.id}">🗑️</button>
              </div>
            </div>
          </div>
        </div>
      `;
    })
    .join("");

  grid.querySelectorAll("[data-edit]").forEach((btn) =>
    btn.addEventListener("click", () => smOpenBannerModal(smBannerCache.find((b) => b.id === btn.getAttribute("data-edit"))))
  );

  grid.querySelectorAll("[data-toggle]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-toggle");
      const banner = smBannerCache.find((b) => b.id === id);
      btn.disabled = true;
      const ok = await smUpdateBanner(id, Object.assign({}, banner, { active: !banner.active }));
      if (ok) {
        smToast(banner.active ? "Banner desativado." : "Banner ativado.", "success");
        await smRenderBannerGrid();
      } else {
        btn.disabled = false;
      }
    })
  );

  grid.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-del");
      smConfirm("Excluir banner", "Tem certeza que deseja excluir este banner?", async () => {
        const ok = await smDeleteBanner(id);
        if (ok) {
          smToast("Banner excluído.", "success");
          await smRenderBannerGrid();
        }
      }, "Excluir");
    })
  );
}

function smOpenBannerModal(existing) {
  const isEdit = !!existing;
  const b = existing || {};

  const backdrop = document.createElement("div");
  backdrop.className = "admin-modal-backdrop";
  backdrop.innerHTML = `
    <div class="admin-modal" style="max-width:480px" role="dialog" aria-modal="true">
      <h3>${isEdit ? "Editar banner" : "Novo banner"}</h3>
      <form id="bannerForm">
        <div class="admin-field">
          <label>Título</label>
          <input type="text" id="bf_title" value="${smEscapeHTML(b.title || "")}">
        </div>
        <div class="admin-field">
          <label>Subtítulo</label>
          <input type="text" id="bf_subtitle" value="${smEscapeHTML(b.subtitle || "")}">
        </div>
        <div class="admin-field">
          <label>Texto do botão</label>
          <input type="text" id="bf_button" placeholder="Ex: Ver ofertas" value="${smEscapeHTML(b.button || "")}">
        </div>
        <div class="admin-field">
          <label>Link do banner</label>
          <input type="text" id="bf_link" placeholder="produtos.html?categoria=kits" value="${smEscapeHTML(b.link || "")}">
        </div>
        <div class="admin-field">
          <label>Imagem</label>
          <input type="file" id="bf_imageFile" accept="image/*">
          <div class="admin-form-hint" id="bf_imageStatus">${b.image ? "Imagem atual definida." : "Sem imagem, o banner usa um fundo roxo de fábrica."}</div>
        </div>
        <div class="admin-field">
          <label>Ordem de exibição</label>
          <input type="number" id="bf_order" value="${b.order ?? 0}">
        </div>
        <div class="admin-checkbox-row">
          <input type="checkbox" id="bf_active" ${b.active ? "checked" : ""}>
          <label for="bf_active">Banner ativo (visível no site público)</label>
        </div>
        <div class="admin-modal-actions">
          <button type="button" class="btn btn-outline btn-sm" id="bannerCancelBtn">Cancelar</button>
          <button type="submit" class="btn btn-primary btn-sm" id="bannerSubmitBtn">${isEdit ? "Salvar" : "Adicionar"}</button>
        </div>
      </form>
    </div>
  `;
  document.body.appendChild(backdrop);

  let uploadedImage = b.image || "";
  document.getElementById("bf_imageFile").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById("bf_imageStatus");
    statusEl.textContent = "Enviando imagem...";
    const url = await smUploadImage(file, "banners");
    if (url) {
      uploadedImage = url;
      statusEl.textContent = "Imagem enviada ✓";
    } else {
      statusEl.textContent = "Falha ao enviar. Tente novamente.";
    }
  });

  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
  document.getElementById("bannerCancelBtn").addEventListener("click", () => backdrop.remove());

  document.getElementById("bannerForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const submitBtn = document.getElementById("bannerSubmitBtn");
    submitBtn.disabled = true;

    const data = {
      title: document.getElementById("bf_title").value.trim(),
      subtitle: document.getElementById("bf_subtitle").value.trim(),
      button: document.getElementById("bf_button").value.trim(),
      link: document.getElementById("bf_link").value.trim() || "#",
      image: uploadedImage || undefined,
      order: parseInt(document.getElementById("bf_order").value, 10) || 0,
      active: document.getElementById("bf_active").checked,
    };

    let ok;
    if (isEdit) {
      ok = await smUpdateBanner(existing.id, data);
      if (ok) smToast("Banner atualizado.", "success");
    } else {
      ok = await smAddBanner(data);
      if (ok) smToast("Banner adicionado.", "success");
    }

    if (ok) {
      backdrop.remove();
      await smRenderBannerGrid();
    } else {
      submitBtn.disabled = false;
    }
  });
}
