let smDestaquesTab = "featured";
let smDestaquesCache = { products: [], categories: [] };

const SM_DESTAQUE_TABS = [
  { key: "featured", label: "Em destaque", field: "featured", dbField: "featured", hint: "Aparecem na seção \"Produtos em destaque\" da Home." },
  { key: "isNew", label: "Novidades", field: "isNew", dbField: "isNew", hint: "Recebem o selo \"Novidade\" e aparecem na seção Novidades da Home." },
  { key: "isKit", label: "Kits", field: "isKit", dbField: "isKit", hint: "Recebem o selo \"Kit\" e aparecem na seção Kits da Home." },
  { key: "recommended", label: "Recomendados", field: "recommended", dbField: "recommended", hint: "Aparecem na seção \"Recomendados pela SuperMisto\" da Home (só aparece quando há pelo menos 1 produto marcado)." },
];

document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("destaques.html", "Destaques");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando produtos...</div>`;

  const [products, categories] = await Promise.all([smGetProducts(), smGetCategories()]);
  smDestaquesCache = { products, categories };

  content.innerHTML = `
    <p class="admin-page-intro">
      Escolha quais produtos aparecem em cada vitrine da Home. As alterações aqui
      são as mesmas do campo correspondente no formulário de produto — é só um
      jeito mais rápido de marcar vários produtos de uma vez.
    </p>
    <div class="admin-toolbar">
      <div class="left" id="destaquesTabs"></div>
      <input type="search" id="destaqueSearch" placeholder="Buscar produto...">
    </div>
    <div id="destaqueHint" class="admin-form-hint" style="margin-bottom:14px"></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead>
          <tr><th style="width:60px"></th><th>Produto</th><th>Categoria</th><th>Status atual</th></tr>
        </thead>
        <tbody id="destaqueTableBody"></tbody>
      </table>
    </div>
  `;

  const tabsEl = document.getElementById("destaquesTabs");
  tabsEl.innerHTML = SM_DESTAQUE_TABS
    .map((t) => `<button class="btn btn-sm ${t.key === smDestaquesTab ? "btn-primary" : "btn-outline"}" data-tab="${t.key}">${t.label}</button>`)
    .join("");
  tabsEl.querySelectorAll("[data-tab]").forEach((btn) =>
    btn.addEventListener("click", () => {
      smDestaquesTab = btn.getAttribute("data-tab");
      tabsEl.querySelectorAll("[data-tab]").forEach((b) => b.classList.toggle("btn-primary", b === btn));
      tabsEl.querySelectorAll("[data-tab]").forEach((b) => b.classList.toggle("btn-outline", b !== btn));
      smRenderDestaqueTable();
    })
  );

  document.getElementById("destaqueSearch").addEventListener("input", smRenderDestaqueTable);

  smRenderDestaqueTable();
});

function smRenderDestaqueTable() {
  const tabDef = SM_DESTAQUE_TABS.find((t) => t.key === smDestaquesTab);
  document.getElementById("destaqueHint").textContent = tabDef.hint;

  const search = document.getElementById("destaqueSearch").value.toLowerCase();
  const categories = smDestaquesCache.categories;
  let products = smDestaquesCache.products;
  if (search) products = products.filter((p) => p.name.toLowerCase().includes(search));

  const tbody = document.getElementById("destaqueTableBody");
  if (!products.length) {
    tbody.innerHTML = `<tr><td colspan="4"><div class="admin-empty">Nenhum produto encontrado.</div></td></tr>`;
    return;
  }

  tbody.innerHTML = products
    .map((p) => {
      const cat = categories.find((c) => c.slug === p.category);
      const checked = !!p[tabDef.field];
      return `
        <tr>
          <td><input type="checkbox" data-toggle="${p.id}" ${checked ? "checked" : ""} style="width:18px;height:18px"></td>
          <td><strong>${smEscapeHTML(p.name)}</strong></td>
          <td>${smEscapeHTML(cat ? cat.name : (p.category || 'Sem categoria'))}</td>
          <td>${checked ? `<span class="pill pill-on">Ativo</span>` : `<span class="pill pill-muted">—</span>`}</td>
        </tr>
      `;
    })
    .join("");

  tbody.querySelectorAll("[data-toggle]").forEach((cb) =>
    cb.addEventListener("change", async () => {
      const id = cb.getAttribute("data-toggle");
      const product = smDestaquesCache.products.find((p) => p.id === id);
      cb.disabled = true;
      const updated = Object.assign({}, product, { [tabDef.field]: cb.checked });
      const ok = await smUpdateProduct(id, updated);
      if (ok) {
        product[tabDef.field] = cb.checked;
        smToast("Atualizado.", "success");
      }
      cb.disabled = false;
      smRenderDestaqueTable();
    })
  );
}
