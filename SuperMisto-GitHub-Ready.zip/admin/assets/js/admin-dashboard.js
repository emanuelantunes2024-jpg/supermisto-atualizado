document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("dashboard.html", "Dashboard");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando dados do banco...</div>`;

  const [products, categories, banners, orders] = await Promise.all([
    smGetProducts(),
    smGetCategories(),
    smGetBanners(),
    smGetOrders(),
  ]);

  const pendingOrders = orders.filter((o) => o.status === "aguardando_pagamento").length;
  const revenueApproved = orders
    .filter((o) => o.payment_status === "approved")
    .reduce((sum, o) => sum + Number(o.total || 0), 0);

  const featuredCount = products.filter((p) => p.featured).length;
  const newCount = products.filter((p) => p.isNew).length;
  const kitCount = products.filter((p) => p.isKit).length;
  const outOfStock = products.filter((p) => p.available === false).length;
  const activeBanners = banners.filter((b) => b.active).length;

  content.innerHTML = `
    <p class="admin-page-intro">Visão geral do catálogo, direto do banco de dados (Supabase).</p>

    <div class="admin-cards">
      <div class="admin-stat-card"><div class="num">${orders.length}</div><div class="label">Pedidos</div></div>
      <div class="admin-stat-card"><div class="num">${pendingOrders}</div><div class="label">Aguardando pagamento</div></div>
      <div class="admin-stat-card"><div class="num">${formatPrice(revenueApproved)}</div><div class="label">Faturamento (pago)</div></div>
      <div class="admin-stat-card"><div class="num">${products.length}</div><div class="label">Produtos cadastrados</div></div>
      <div class="admin-stat-card"><div class="num">${categories.length}</div><div class="label">Categorias</div></div>
      <div class="admin-stat-card"><div class="num">${featuredCount}</div><div class="label">Em destaque</div></div>
      <div class="admin-stat-card"><div class="num">${newCount}</div><div class="label">Novidades</div></div>
      <div class="admin-stat-card"><div class="num">${kitCount}</div><div class="label">Kits</div></div>
      <div class="admin-stat-card"><div class="num">${activeBanners}</div><div class="label">Banners ativos</div></div>
      ${outOfStock ? `<div class="admin-stat-card"><div class="num">${outOfStock}</div><div class="label">Indisponíveis</div></div>` : ""}
    </div>

    <div class="admin-panel">
      <h2>Ações rápidas</h2>
      <div class="admin-toolbar" style="margin:0">
        <div class="left">
          <a href="pedidos.html" class="btn btn-primary btn-sm">Ver pedidos</a>
          <a href="produto-form.html" class="btn btn-outline btn-sm">+ Novo produto</a>
          <a href="clientes.html" class="btn btn-outline btn-sm">Ver clientes</a>
          <a href="categorias.html" class="btn btn-outline btn-sm">Gerenciar categorias</a>
          <a href="banners.html" class="btn btn-outline btn-sm">Gerenciar banners</a>
        </div>
      </div>
    </div>

    <div class="admin-panel">
      <h2>Como os dados funcionam agora (Etapa 3)</h2>
      <p style="font-size:.9rem;color:var(--ink-soft);line-height:1.6;margin:0">
        Tudo o que você altera aqui é salvo direto no <strong>banco de dados real
        (Supabase)</strong> e aparece automaticamente para qualquer visitante do
        site público, em qualquer dispositivo — não depende mais do navegador
        que você está usando agora. Detalhes completos em <code>PROJETO.md</code>.
      </p>
    </div>
  `;
});
