/**
 * ============================================================================
 * SUPERMISTO ADMIN — admin-data.js  (ETAPA 3)
 * ============================================================================
 * Substitui a camada de localStorage da Etapa 2 por chamadas reais à API do
 * Supabase (banco de dados Postgres real, compartilhado entre todos os
 * dispositivos). As funções mantêm os MESMOS NOMES da Etapa 2
 * (smGetProducts, smAddProduct, smUpdateProduct, ...) para que as telas do
 * painel continuem reconhecíveis — a diferença é que agora todas retornam
 * Promises (são assíncronas, porque envolvem rede) e todas as páginas que
 * as chamam usam `await`.
 *
 * Toda escrita (insert/update/delete) exige uma sessão válida do Supabase
 * Auth — o próprio banco recusa a operação via RLS se não houver login
 * (ver supabase/schema.sql). Isso é reforçado aqui também, checando a sessão
 * antes de cada escrita, para mostrar uma mensagem amigável em vez de um
 * erro técnico caso a sessão tenha expirado no meio do uso do painel.
 * ============================================================================
 */

async function smClient() {
  return window.smSupabaseReady ? await window.smSupabaseReady : null;
}

async function smRequireClient() {
  const client = await smClient();
  if (!client) {
    smToast("Backend (Supabase) não configurado. Veja supabase/README.md.", "error");
    throw new Error("Supabase não configurado");
  }
  return client;
}

function smHandleError(context, error) {
  console.error("SuperMisto Admin: " + context, error);
  const msg = (error && error.message) || "Erro desconhecido";
  smToast("Erro ao " + context + ": " + msg, "error");
}

// ---------------------------------------------------------------------------
// Formatação (mesma usada no site público)
// ---------------------------------------------------------------------------
function formatPrice(value) {
  const n = Number(value);
  return isNaN(n) ? "—" : n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function smSlugify(text) {
  return (text || "")
    .toString()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

// ---------------------------------------------------------------------------
// Conversão camelCase (usado nas telas) <-> snake_case (colunas do banco)
// ---------------------------------------------------------------------------
function smProductToRow(p) {
  const row = {
    name: p.name,
    category: p.category,
    price: p.price,
    sale_price: p.salePrice === undefined || p.salePrice === "" ? null : p.salePrice,
    weight: p.weight || "",
    unit: p.unit || "",
    short_desc: p.shortDesc || "",
    description: p.description || "",
    emoji: p.emoji || "🌶️",
    image: p.image || null,
    images: p.images || [],
    available: p.available !== false,
    featured: !!p.featured,
    is_new: !!p.isNew,
    is_kit: !!p.isKit,
    recommended: !!p.recommended,
    buy_link: p.buyLink || "#",
    whatsapp_message: p.whatsappMessage || null,
  };
  if (p.costPrice !== undefined) row.cost_price = p.costPrice === "" ? null : p.costPrice;
  if (p.trackStock !== undefined) row.track_stock = !!p.trackStock;
  if (p.stockQuantity !== undefined) row.stock_quantity = p.stockQuantity === "" ? 0 : Number(p.stockQuantity);
  if (p.ncm !== undefined) row.ncm = p.ncm || null;
  if (p.cfop !== undefined) row.cfop = p.cfop || null;
  if (p.sellerId !== undefined) row.seller_id = p.sellerId || null;
  return row;
}
function smRowToProduct(row) {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    price: Number(row.price),
    salePrice: row.sale_price !== null && row.sale_price !== undefined ? Number(row.sale_price) : undefined,
    costPrice: row.cost_price !== null && row.cost_price !== undefined ? Number(row.cost_price) : undefined,
    weight: row.weight || "",
    unit: row.unit || "",
    shortDesc: row.short_desc || "",
    description: row.description || "",
    emoji: row.emoji || "🌶️",
    image: row.image || undefined,
    images: row.images || [],
    available: row.available !== false,
    featured: !!row.featured,
    isNew: !!row.is_new,
    isKit: !!row.is_kit,
    recommended: !!row.recommended,
    buyLink: row.buy_link || "#",
    whatsappMessage: row.whatsapp_message || undefined,
    trackStock: !!row.track_stock,
    stockQuantity: row.stock_quantity || 0,
    ncm: row.ncm || "",
    cfop: row.cfop || "",
    sellerId: row.seller_id || null,
  };
}
function smCategoryToRow(c) {
  return {
    name: c.name,
    icon: c.icon || "⭐",
    description: c.desc || "",
    image: c.image || null,
    bg: c.bg || "#F0E4F7",
    fg: c.fg || "#3A1150",
    active: c.active !== false,
  };
}
function smRowToCategory(row) {
  return {
    slug: row.slug,
    name: row.name,
    icon: row.icon || "⭐",
    desc: row.description || "",
    image: row.image || undefined,
    bg: row.bg || "#F0E4F7",
    fg: row.fg || "#3A1150",
    active: row.active !== false,
  };
}
function smBannerToRow(b) {
  return {
    title: b.title || "",
    subtitle: b.subtitle || "",
    button: b.button || "",
    link: b.link || "#",
    image: b.image || null,
    active: !!b.active,
    sort_order: b.order || 0,
  };
}
function smRowToBanner(row) {
  return {
    id: row.id,
    title: row.title || "",
    subtitle: row.subtitle || "",
    button: row.button || "",
    link: row.link || "#",
    image: row.image || undefined,
    active: !!row.active,
    order: row.sort_order || 0,
  };
}
function smRowToSettings(row) {
  return {
    whatsapp: row.whatsapp || "",
    whatsappMessage: row.whatsapp_message || "",
    email: row.email || "",
    instagram: row.instagram || "#",
    facebook: row.facebook || "#",
  };
}

// ---------------------------------------------------------------------------
// PRODUTOS
// ---------------------------------------------------------------------------
async function smGetProducts() {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("products").select("*").order("created_at", { ascending: true });
  if (error) { smHandleError("carregar produtos", error); return []; }
  return (data || []).map(smRowToProduct);
}

async function smGetProduct(id) {
  const client = await smClient();
  if (!client) return null;
  const { data, error } = await client.from("products").select("*").eq("id", id).maybeSingle();
  if (error) { smHandleError("carregar produto", error); return null; }
  return data ? smRowToProduct(data) : null;
}

async function smUniqueProductId(baseName, ignoreId) {
  const client = await smRequireClient();
  const base = smSlugify(baseName) || "produto";
  let id = base;
  let n = 2;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const { data } = await client.from("products").select("id").eq("id", id).maybeSingle();
    if (!data || data.id === ignoreId) break;
    id = `${base}-${n}`;
    n++;
  }
  return id;
}

async function smAddProduct(product) {
  try {
    const client = await smRequireClient();
    const row = smProductToRow(product);
    row.id = product.id;
    const { data, error } = await client.from("products").insert(row).select().maybeSingle();
    if (error) throw error;
    return smRowToProduct(data);
  } catch (error) {
    smHandleError("adicionar produto", error);
    return null;
  }
}

async function smUpdateProduct(id, data) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("products").update(smProductToRow(data)).eq("id", id);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("atualizar produto", error);
    return false;
  }
}

async function smDeleteProduct(id) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("products").delete().eq("id", id);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("excluir produto", error);
    return false;
  }
}

async function smDuplicateProduct(id) {
  try {
    const original = await smGetProduct(id);
    if (!original) return null;
    const newId = await smUniqueProductId(original.name + "-copia");
    const copy = Object.assign({}, original, { id: newId, name: original.name + " (cópia)" });
    const created = await smAddProduct(copy);
    return created;
  } catch (error) {
    smHandleError("duplicar produto", error);
    return null;
  }
}

// ---------------------------------------------------------------------------
// CATEGORIAS
// ---------------------------------------------------------------------------
async function smGetCategories() {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("categories").select("*").order("sort_order", { ascending: true });
  if (error) { smHandleError("carregar categorias", error); return []; }
  return (data || []).map(smRowToCategory);
}

async function smGetCategory(slug) {
  const client = await smClient();
  if (!client) return null;
  const { data, error } = await client.from("categories").select("*").eq("slug", slug).maybeSingle();
  if (error) { smHandleError("carregar categoria", error); return null; }
  return data ? smRowToCategory(data) : null;
}

async function smAddCategory(cat) {
  try {
    const client = await smRequireClient();
    const row = smCategoryToRow(cat);
    row.slug = cat.slug;
    const { data: existing } = await client.from("categories").select("sort_order").order("sort_order", { ascending: false }).limit(1).maybeSingle();
    row.sort_order = existing ? (existing.sort_order || 0) + 1 : 0;
    const { error } = await client.from("categories").insert(row);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("adicionar categoria", error);
    return false;
  }
}

async function smUpdateCategory(slug, data) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("categories").update(smCategoryToRow(data)).eq("slug", slug);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("atualizar categoria", error);
    return false;
  }
}

async function smDeleteCategory(slug) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("categories").delete().eq("slug", slug);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("excluir categoria", error);
    return false;
  }
}

async function smCategoryProductCount(slug) {
  const client = await smClient();
  if (!client) return 0;
  const { count, error } = await client.from("products").select("id", { count: "exact", head: true }).eq("category", slug);
  if (error) { smHandleError("contar produtos da categoria", error); return 0; }
  return count || 0;
}

// ---------------------------------------------------------------------------
// BANNERS
// ---------------------------------------------------------------------------
async function smGetBanners() {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("banners").select("*").order("sort_order", { ascending: true });
  if (error) { smHandleError("carregar banners", error); return []; }
  return (data || []).map(smRowToBanner);
}

async function smAddBanner(banner) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("banners").insert(smBannerToRow(banner));
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("adicionar banner", error);
    return false;
  }
}

async function smUpdateBanner(id, data) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("banners").update(smBannerToRow(data)).eq("id", id);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("atualizar banner", error);
    return false;
  }
}

async function smDeleteBanner(id) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("banners").delete().eq("id", id);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("excluir banner", error);
    return false;
  }
}

// ---------------------------------------------------------------------------
// CONFIGURAÇÕES
// ---------------------------------------------------------------------------
async function smGetSettings() {
  const client = await smClient();
  if (!client) return { whatsapp: "", whatsappMessage: "", email: "", instagram: "#", facebook: "#" };
  const { data, error } = await client.from("settings").select("*").eq("id", 1).maybeSingle();
  if (error) { smHandleError("carregar configurações", error); return {}; }
  return data ? smRowToSettings(data) : {};
}

async function smSaveSettings(data) {
  try {
    const client = await smRequireClient();
    const row = {
      id: 1,
      whatsapp: data.whatsapp || "",
      whatsapp_message: data.whatsappMessage || "",
      email: data.email || "",
      instagram: data.instagram || "#",
      facebook: data.facebook || "#",
    };
    const { error } = await client.from("settings").upsert(row);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("salvar configurações", error);
    return false;
  }
}

// ---------------------------------------------------------------------------
// UPLOAD DE IMAGENS (Supabase Storage)
// ---------------------------------------------------------------------------
// bucket: "products" ou "banners" (ver supabase/schema.sql)
async function smUploadImage(file, bucket) {
  try {
    const client = await smRequireClient();
    const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
    const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const { error } = await client.storage.from(bucket).upload(path, file, { cacheControl: "3600", upsert: false });
    if (error) throw error;
    const { data: pub } = client.storage.from(bucket).getPublicUrl(path);
    return pub.publicUrl;
  } catch (error) {
    smHandleError("enviar imagem", error);
    return null;
  }
}

// ---------------------------------------------------------------------------
// PEDIDOS (Módulo 4)
// ---------------------------------------------------------------------------
async function smGetOrders() {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("orders").select("*, order_items(*)").order("created_at", { ascending: false });
  if (error) { smHandleError("carregar pedidos", error); return []; }
  return data || [];
}

async function smGetOrder(id) {
  const client = await smClient();
  if (!client) return null;
  const { data, error } = await client.from("orders").select("*, order_items(*), order_status_history(*), payments(*)").eq("id", id).maybeSingle();
  if (error) { smHandleError("carregar pedido", error); return null; }
  return data;
}

async function smUpdateOrderStatus(id, status, note) {
  try {
    const client = await smRequireClient();
    const { error: err1 } = await client.from("orders").update({ status }).eq("id", id);
    if (err1) throw err1;
    const { data: sessionData } = await client.auth.getSession();
    const uid = sessionData && sessionData.session ? sessionData.session.user.id : null;
    const { error: err2 } = await client.from("order_status_history").insert({ order_id: id, status, changed_by: uid, note: note || "" });
    if (err2) throw err2;
    return true;
  } catch (error) {
    smHandleError("atualizar status do pedido", error);
    return false;
  }
}

// Chama a Netlify Function que simula a confirmação de pagamento (MODO DE
// TESTE — ver netlify/functions/payment-mock-confirm.js). Só disponível
// para administradores logados.
async function smSimulatePayment(orderId, outcome) {
  try {
    const client = await smRequireClient();
    const { data: sessionData } = await client.auth.getSession();
    const token = sessionData && sessionData.session ? sessionData.session.access_token : null;
    if (!token) throw new Error("Sessão inválida — faça login novamente.");

    const res = await fetch("/.netlify/functions/payment-mock-confirm", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: JSON.stringify({ orderId, outcome }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Falha ao simular pagamento");
    return true;
  } catch (error) {
    smHandleError("simular pagamento", error);
    return false;
  }
}

// ---------------------------------------------------------------------------
// CLIENTES (Módulo 4)
// ---------------------------------------------------------------------------
async function smGetCustomers() {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("customers").select("*").order("created_at", { ascending: false });
  if (error) { smHandleError("carregar clientes", error); return []; }
  return data || [];
}

async function smGetCustomerAddresses(customerId) {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("addresses").select("*").eq("customer_id", customerId);
  if (error) { smHandleError("carregar endereços do cliente", error); return []; }
  return data || [];
}

// ---------------------------------------------------------------------------
// DADOS FISCAIS DA EMPRESA (Módulo 4 — estrutura, sem integração real)
// ---------------------------------------------------------------------------
async function smGetCompanyFiscalInfo() {
  const client = await smClient();
  if (!client) return {};
  const { data, error } = await client.from("company_fiscal_info").select("*").eq("id", 1).maybeSingle();
  if (error) { smHandleError("carregar dados fiscais", error); return {}; }
  return data || {};
}

async function smSaveCompanyFiscalInfo(data) {
  try {
    const client = await smRequireClient();
    const row = Object.assign({ id: 1 }, data);
    const { error } = await client.from("company_fiscal_info").upsert(row);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("salvar dados fiscais", error);
    return false;
  }
}

// ---------------------------------------------------------------------------
// MENSAGENS DE CONTATO (Módulo 5)
// ---------------------------------------------------------------------------
async function smGetContactMessages() {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("contact_messages").select("*").order("created_at", { ascending: false });
  if (error) { smHandleError("carregar mensagens de contato", error); return []; }
  return data || [];
}

async function smUpdateContactMessageStatus(id, status) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("contact_messages").update({ status }).eq("id", id);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("atualizar status da mensagem", error);
    return false;
  }
}

// ---------------------------------------------------------------------------
// HISTÓRICO / AUDITORIA (Módulo 5)
// ---------------------------------------------------------------------------
async function smGetAuditLog(tableName, recordId) {
  const client = await smClient();
  if (!client) return [];
  let query = client.from("audit_log").select("*").order("created_at", { ascending: false }).limit(200);
  if (tableName) query = query.eq("table_name", tableName);
  if (recordId) query = query.eq("record_id", recordId);
  const { data, error } = await query;
  if (error) { smHandleError("carregar histórico", error); return []; }
  return data || [];
}

// ---------------------------------------------------------------------------
// VENDEDORES / MARKETPLACE (Módulo 6)
// ---------------------------------------------------------------------------
async function smGetSellers() {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("seller_profiles").select("*").order("created_at", { ascending: false });
  if (error) { smHandleError("carregar vendedores", error); return []; }
  return data || [];
}

async function smUpdateSellerStatus(id, status) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("seller_profiles").update({ status }).eq("id", id);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("atualizar status do vendedor", error);
    return false;
  }
}

async function smUpdateSellerCommission(id, commissionRate) {
  try {
    const client = await smRequireClient();
    const { error } = await client.from("seller_profiles").update({ commission_rate: commissionRate }).eq("id", id);
    if (error) throw error;
    return true;
  } catch (error) {
    smHandleError("atualizar comissão do vendedor", error);
    return false;
  }
}

// Chama a Netlify Function que cria a conta de vendedor (owner-only,
// mesmo padrão de smCreateAdmin).
async function smCreateSeller(email, password, storeName, phone, commissionRate) {
  try {
    const client = await smRequireClient();
    const { data: sessionData } = await client.auth.getSession();
    const token = sessionData && sessionData.session ? sessionData.session.access_token : null;
    if (!token) throw new Error("Sessão inválida — faça login novamente.");

    const res = await fetch("/.netlify/functions/seller-create", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: JSON.stringify({ email, password, storeName, phone, commissionRate }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Falha ao criar vendedor");
    return true;
  } catch (error) {
    smHandleError("criar vendedor", error);
    return false;
  }
}

async function smCountSellerSalesById(sellerId, orderItemsCache) {
  const items = orderItemsCache || (await smGetAllOrderItemsWithSeller());
  return items.filter((it) => it.seller_id === sellerId);
}

async function smGetAllOrderItemsWithSeller() {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("order_items").select("*, orders(payment_status, created_at)").not("seller_id", "is", null);
  if (error) { smHandleError("carregar vendas de vendedores", error); return []; }
  return data || [];
}

// ---------------------------------------------------------------------------
// NOTA FISCAL (Módulo 6 — integração real com Focus NFe, ver seção 18.2)
// ---------------------------------------------------------------------------
async function smGetFiscalDocument(orderId) {
  const client = await smClient();
  if (!client) return null;
  const { data, error } = await client.from("fiscal_documents").select("*").eq("order_id", orderId).maybeSingle();
  if (error) { smHandleError("carregar nota fiscal", error); return null; }
  return data;
}

async function smEmitFiscalInvoice(orderId) {
  try {
    const client = await smRequireClient();
    const { data: sessionData } = await client.auth.getSession();
    const token = sessionData && sessionData.session ? sessionData.session.access_token : null;
    if (!token) throw new Error("Sessão inválida — faça login novamente.");

    const res = await fetch("/.netlify/functions/fiscal-emit-nfe", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: JSON.stringify({ orderId }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Falha ao emitir nota fiscal");
    return body;
  } catch (error) {
    smHandleError("emitir nota fiscal", error);
    return null;
  }
}

async function smCheckFiscalStatus(orderId) {
  try {
    const client = await smRequireClient();
    const { data: sessionData } = await client.auth.getSession();
    const token = sessionData && sessionData.session ? sessionData.session.access_token : null;
    if (!token) throw new Error("Sessão inválida — faça login novamente.");

    const res = await fetch("/.netlify/functions/fiscal-check-status", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: JSON.stringify({ orderId }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Falha ao consultar status fiscal");
    return body;
  } catch (error) {
    smHandleError("consultar status fiscal", error);
    return null;
  }
}

// ---------------------------------------------------------------------------
// ADMINISTRADORES
// ---------------------------------------------------------------------------
async function smGetAdmins() {
  const client = await smClient();
  if (!client) return [];
  const { data, error } = await client.from("admin_profiles").select("*").order("created_at", { ascending: true });
  if (error) { smHandleError("carregar administradores", error); return []; }
  return data || [];
}

// Chama a Netlify Function que usa a service_role key (do lado do servidor)
// para criar um novo usuário no Supabase Auth + o perfil correspondente.
// Precisa de um token de sessão válido (o próprio backend confere se quem
// está pedindo já é um administrador autenticado).
async function smCreateAdmin(email, password, fullName, role) {
  try {
    const client = await smRequireClient();
    const { data: sessionData } = await client.auth.getSession();
    const token = sessionData && sessionData.session ? sessionData.session.access_token : null;
    if (!token) throw new Error("Sessão inválida — faça login novamente.");

    const res = await fetch("/.netlify/functions/admin-create-user", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: JSON.stringify({ email, password, fullName, role: role === "owner" ? "owner" : "editor" }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Falha ao criar administrador");
    return true;
  } catch (error) {
    smHandleError("criar administrador", error);
    return false;
  }
}

// ---------------------------------------------------------------------------
// TOAST simples reaproveitado por todas as páginas do admin
// ---------------------------------------------------------------------------
function smToast(message, type) {
  let el = document.getElementById("smToast");
  if (!el) {
    el = document.createElement("div");
    el.id = "smToast";
    el.className = "admin-toast";
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.className = "admin-toast is-visible" + (type ? " " + type : "");
  clearTimeout(el._timer);
  el._timer = setTimeout(() => {
    el.classList.remove("is-visible");
  }, 3200);
}
