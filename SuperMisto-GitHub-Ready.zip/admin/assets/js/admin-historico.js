document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("historico.html", "Histórico");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando histórico...</div>`;

  const entries = await smGetAuditLog();

  content.innerHTML = `
    <p class="admin-page-intro">
      Registro automático de alterações em produtos e categorias (gravado pelo próprio banco
      de dados — não pode ser apagado ou forjado pelo painel). Mostrando os ${entries.length}
      registros mais recentes.
    </p>
    <div class="admin-toolbar">
      <div class="left">
        <select id="auditTableFilter">
          <option value="all">Produtos e categorias</option>
          <option value="products">Só produtos</option>
          <option value="categories">Só categorias</option>
        </select>
      </div>
    </div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Quando</th><th>Tabela</th><th>Item</th><th>Ação</th><th>Por</th></tr></thead>
        <tbody id="auditTableBody"></tbody>
      </table>
    </div>
  `;

  const actionLabels = { insert: "Criado", update: "Editado", delete: "Excluído" };
  const tableLabels = { products: "Produto", categories: "Categoria" };

  function render() {
    const filter = document.getElementById("auditTableFilter").value;
    const rows = filter === "all" ? entries : entries.filter((e) => e.table_name === filter);
    const tbody = document.getElementById("auditTableBody");

    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="5"><div class="admin-empty">Nenhum registro encontrado.</div></td></tr>`;
      return;
    }

    tbody.innerHTML = rows
      .map((e) => {
        const name = (e.after_data && e.after_data.name) || (e.before_data && e.before_data.name) || e.record_id;
        return `
          <tr>
            <td>${new Date(e.created_at).toLocaleString("pt-BR")}</td>
            <td>${tableLabels[e.table_name] || e.table_name}</td>
            <td>${smEscapeHTML(name)}</td>
            <td><span class="pill pill-muted">${actionLabels[e.action] || e.action}</span></td>
            <td>${smEscapeHTML(e.changed_by_email || "—")}</td>
          </tr>
        `;
      })
      .join("");
  }

  document.getElementById("auditTableFilter").addEventListener("change", render);
  render();
});
