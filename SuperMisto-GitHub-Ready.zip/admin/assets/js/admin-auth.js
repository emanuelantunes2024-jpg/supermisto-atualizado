/**
 * ============================================================================
 * SUPERMISTO ADMIN — admin-auth.js  (ETAPA 3)
 * ============================================================================
 * Substitui o portão de demonstração da Etapa 2 (sessionStorage + senha em
 * texto puro no código) por autenticação real via Supabase Auth:
 *   - Senhas nunca ficam em texto puro em lugar nenhum do nosso código —
 *     o Supabase Auth guarda apenas o hash, em um banco que não temos
 *     acesso direto.
 *   - A sessão é validada por um token assinado pelo Supabase (JWT),
 *     renovado automaticamente pela biblioteca supabase-js — não é mais
 *     uma flag simples que qualquer um pode forjar no console.
 *   - Todo pedido de leitura/escrita feito à API do Supabase carrega esse
 *     token, e o banco (via RLS, ver supabase/schema.sql) confere se quem
 *     está pedindo realmente está autenticado antes de permitir qualquer
 *     alteração.
 *
 * SE O SUPABASE AINDA NÃO FOI CONFIGURADO (assets/js/supabase-config.js
 * com os valores de exemplo): o painel não finge que dá para logar. Ele
 * mostra uma mensagem clara pedindo para configurar o backend primeiro —
 * ver smAdminGuard() abaixo, chamada em toda página do painel.
 * ============================================================================
 */

async function smAdminGetClient() {
  return window.smSupabaseReady ? await window.smSupabaseReady : null;
}

async function smAdminIsLoggedIn() {
  const client = await smAdminGetClient();
  if (!client) return false;
  const { data } = await client.auth.getSession();
  return !!(data && data.session);
}

async function smAdminLogin(email, password) {
  const client = await smAdminGetClient();
  if (!client) {
    return { ok: false, error: "O backend (Supabase) ainda não foi configurado neste projeto. Veja supabase/README.md." };
  }
  const { data, error } = await client.auth.signInWithPassword({ email, password });
  if (error) {
    return { ok: false, error: smAdminFriendlyAuthError(error) };
  }
  return { ok: true, session: data.session };
}

// (Recuperação de senha) Manda o e-mail de redefinição de senha real, via
// Supabase Auth — o link do e-mail leva para /reset-password.html (na raiz
// do site, compartilhada entre admin/vendedor/cliente), que já sabe
// detectar automaticamente para qual área mandar a pessoa depois de
// trocar a senha.
async function smAdminRequestPasswordReset(email) {
  const client = await smAdminGetClient();
  if (!client) {
    return { ok: false, error: "O backend (Supabase) ainda não foi configurado neste projeto." };
  }
  const redirectTo = `${window.location.origin}/reset-password.html`;
  const { error } = await client.auth.resetPasswordForEmail(email, { redirectTo });
  if (error) {
    return { ok: false, error: error.message || "Não foi possível enviar o e-mail de redefinição." };
  }
  return { ok: true };
}

async function smAdminLogout() {
  const client = await smAdminGetClient();
  if (client) await client.auth.signOut();
  window.location.href = "index.html";
}

async function smAdminCurrentUser() {
  const client = await smAdminGetClient();
  if (!client) return null;
  const { data } = await client.auth.getUser();
  return data ? data.user : null;
}

// (Módulo 5) Papel do administrador logado: "owner" (acesso total) ou
// "editor" (catálogo/pedidos, sem Configurações/dados fiscais/gestão de
// administradores). Usado por admin-ui.js para esconder itens de menu e
// por admin-configuracoes.js para bloquear a tela inteira se necessário —
// mas a garantia de verdade está nas políticas RLS (ver
// supabase/migrations/003_modulo5.sql), não nesta checagem de interface.
async function smAdminGetRole() {
  const client = await smAdminGetClient();
  const user = await smAdminCurrentUser();
  if (!client || !user) return null;
  const { data } = await client.from("admin_profiles").select("role").eq("id", user.id).maybeSingle();
  return data ? data.role : null;
}

function smAdminFriendlyAuthError(error) {
  const msg = (error && error.message) || "";
  if (msg.includes("Invalid login credentials")) return "E-mail ou senha incorretos.";
  if (msg.includes("Email not confirmed")) return "Este e-mail ainda não foi confirmado. Verifique a caixa de entrada.";
  return "Não foi possível entrar: " + msg;
}

// ---------------------------------------------------------------------------
// Guarda de rota: chamada no <head> de toda página protegida do painel.
// Redireciona para a tela de login se não houver sessão válida.
// Como agora depende de uma checagem assíncrona (o token do Supabase), a
// própria página fica com um pequeno overlay "Verificando acesso..." até a
// checagem terminar, para não deixar o conteúdo administrativo "piscar" na
// tela de quem não tiver permissão.
// ---------------------------------------------------------------------------
function smAdminGuard() {
  const overlay = document.createElement("div");
  overlay.id = "smAuthOverlay";
  overlay.style.cssText =
    "position:fixed;inset:0;background:#F5F1F8;z-index:9999;display:flex;align-items:center;justify-content:center;font-family:sans-serif;color:#3A1150;font-size:.95rem";
  overlay.textContent = "Verificando acesso...";
  document.addEventListener("DOMContentLoaded", () => document.body.prepend(overlay));

  (async () => {
    const client = await smAdminGetClient();
    if (!client) {
      window.location.href = "index.html?erro=supabase-nao-configurado";
      return;
    }
    const loggedIn = await smAdminIsLoggedIn();
    if (!loggedIn) {
      window.location.href = "index.html";
      return;
    }
    overlay.remove();
  })();
}
