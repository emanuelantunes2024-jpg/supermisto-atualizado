document.addEventListener("DOMContentLoaded", async () => {
  renderAdminShell("configuracoes.html", "Configurações");
  const content = document.getElementById("adminContent");
  content.innerHTML = `<div class="admin-empty">Carregando...</div>`;

  const [s, admins, currentUser, fiscal] = await Promise.all([smGetSettings(), smGetAdmins(), smAdminCurrentUser(), smGetCompanyFiscalInfo()]);

  content.innerHTML = `
    <p class="admin-page-intro">
      Dados gerais usados em todo o site público (cabeçalho, rodapé, botões de WhatsApp).
    </p>

    <form id="settingsForm" class="admin-panel">
      <h2>Contato</h2>
      <div class="admin-form-grid cols-2">
        <div class="admin-field">
          <label for="s_whatsapp">Número do WhatsApp (só números, com DDI+DDD)</label>
          <input type="text" id="s_whatsapp" placeholder="5511999999999" value="${smEscapeHTML(s.whatsapp || "")}">
        </div>
        <div class="admin-field">
          <label for="s_email">E-mail de contato</label>
          <input type="email" id="s_email" value="${smEscapeHTML(s.email || "")}">
        </div>
        <div class="admin-field span-2">
          <label for="s_whatsappMessage">Mensagem padrão do WhatsApp</label>
          <textarea id="s_whatsappMessage" rows="2">${smEscapeHTML(s.whatsappMessage || "")}</textarea>
        </div>
        <div class="admin-field">
          <label for="s_instagram">Link do Instagram</label>
          <input type="text" id="s_instagram" placeholder="https://instagram.com/supermisto" value="${smEscapeHTML(s.instagram || "")}">
        </div>
        <div class="admin-field">
          <label for="s_facebook">Link do Facebook</label>
          <input type="text" id="s_facebook" placeholder="https://facebook.com/supermisto" value="${smEscapeHTML(s.facebook || "")}">
        </div>
      </div>
      <div class="admin-form-actions">
        <button type="submit" class="btn btn-primary" id="settingsSubmitBtn">Salvar configurações</button>
      </div>
    </form>

    <div class="admin-panel">
      <h2>Administradores</h2>
      <p style="font-size:.9rem;color:var(--ink-soft);margin-bottom:16px">
        Pessoas com acesso ao painel. Você está logado como <strong>${smEscapeHTML(currentUser?.email || "—")}</strong>.
      </p>
      <div class="admin-table-wrap" style="margin-bottom:18px">
        <table class="admin-table">
          <thead><tr><th>E-mail</th><th>Nome</th><th>Papel</th><th>Criado em</th></tr></thead>
          <tbody>
            ${admins.length
              ? admins.map((a) => `<tr><td>${smEscapeHTML(a.email)}</td><td>${smEscapeHTML(a.full_name || "—")}</td><td><span class="pill ${a.role === "owner" ? "pill-featured" : "pill-muted"}">${a.role === "owner" ? "Owner" : "Editor"}</span></td><td>${new Date(a.created_at).toLocaleDateString("pt-BR")}</td></tr>`).join("")
              : `<tr><td colspan="4"><div class="admin-empty">Nenhum administrador listado (verifique supabase/create-first-admin.sql).</div></td></tr>`}
          </tbody>
        </table>
      </div>

      <p style="font-size:.82rem;color:var(--ink-soft);margin-bottom:14px">
        <strong>Owner</strong> tem acesso total (inclusive esta tela e criar outros administradores).
        <strong>Editor</strong> gerencia catálogo, pedidos e clientes, mas não vê Configurações.
      </p>
      <button class="btn btn-outline btn-sm" id="newAdminBtn">+ Adicionar administrador</button>
    </div>

    <div class="admin-panel">
      <h2>Dados fiscais da empresa</h2>
      <p style="font-size:.85rem;color:var(--ink-soft);margin-bottom:14px">
        ⚠️ Estrutura preparada para uma futura emissão de nota fiscal — preencher
        estes campos NÃO emite nenhuma nota fiscal real, pois ainda não há
        integração com nenhum serviço fiscal (ver PROJETO.md).
      </p>
      <form id="fiscalForm" class="admin-form-grid cols-2">
        <div class="admin-field"><label>Razão social</label><input type="text" id="fi_razao" value="${smEscapeHTML(fiscal.razao_social || "")}"></div>
        <div class="admin-field"><label>Nome fantasia</label><input type="text" id="fi_fantasia" value="${smEscapeHTML(fiscal.nome_fantasia || "")}"></div>
        <div class="admin-field"><label>CNPJ</label><input type="text" id="fi_cnpj" value="${smEscapeHTML(fiscal.cnpj || "")}"></div>
        <div class="admin-field"><label>Inscrição estadual</label><input type="text" id="fi_ie" value="${smEscapeHTML(fiscal.inscricao_estadual || "")}"></div>
        <div class="admin-field span-2"><label>Regime tributário</label><input type="text" id="fi_regime" placeholder="Ex: Simples Nacional" value="${smEscapeHTML(fiscal.regime_tributario || "")}"></div>
      </form>
      <div class="admin-form-actions">
        <button type="submit" form="fiscalForm" class="btn btn-primary" id="fiscalSubmitBtn">Salvar dados fiscais</button>
      </div>
    </div>

    <div class="admin-panel">
      <h2>Sobre a persistência dos dados</h2>
      <p style="font-size:.9rem;color:var(--ink-soft);line-height:1.6">
        A partir da Etapa 3, todos os dados do painel (produtos, categorias, banners,
        estas configurações e os administradores) ficam salvos em um
        <strong>banco de dados real (Supabase)</strong>, compartilhado por todos os
        dispositivos — não dependem mais do navegador que você está usando agora.
        Consulte <code>PROJETO.md</code> para o detalhamento completo.
      </p>
    </div>
  `;

  document.getElementById("settingsForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("settingsSubmitBtn");
    btn.disabled = true;
    const ok = await smSaveSettings({
      whatsapp: document.getElementById("s_whatsapp").value.trim(),
      email: document.getElementById("s_email").value.trim(),
      whatsappMessage: document.getElementById("s_whatsappMessage").value.trim(),
      instagram: document.getElementById("s_instagram").value.trim() || "#",
      facebook: document.getElementById("s_facebook").value.trim() || "#",
    });
    if (ok) smToast("Configurações salvas.", "success");
    btn.disabled = false;
  });

  document.getElementById("newAdminBtn").addEventListener("click", smOpenNewAdminModal);

  document.getElementById("fiscalForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("fiscalSubmitBtn");
    btn.disabled = true;
    const ok = await smSaveCompanyFiscalInfo({
      razao_social: document.getElementById("fi_razao").value.trim(),
      nome_fantasia: document.getElementById("fi_fantasia").value.trim(),
      cnpj: document.getElementById("fi_cnpj").value.trim(),
      inscricao_estadual: document.getElementById("fi_ie").value.trim(),
      regime_tributario: document.getElementById("fi_regime").value.trim(),
    });
    if (ok) smToast("Dados fiscais salvos.", "success");
    btn.disabled = false;
  });
});

function smOpenNewAdminModal() {
  const backdrop = document.createElement("div");
  backdrop.className = "admin-modal-backdrop";
  backdrop.innerHTML = `
    <div class="admin-modal" style="max-width:420px" role="dialog" aria-modal="true">
      <h3>Novo administrador</h3>
      <p style="font-size:.85rem">A pessoa poderá entrar em /admin imediatamente com o e-mail e senha definidos aqui.</p>
      <form id="newAdminForm">
        <div class="admin-field">
          <label>Nome</label>
          <input type="text" id="na_name" required>
        </div>
        <div class="admin-field">
          <label>E-mail</label>
          <input type="email" id="na_email" required>
        </div>
        <div class="admin-field">
          <label>Senha provisória</label>
          <input type="password" id="na_pass" required minlength="6">
          <div class="admin-form-hint">Mínimo de 6 caracteres. Recomende que a pessoa troque no primeiro acesso.</div>
        </div>
        <div class="admin-field">
          <label>Papel</label>
          <select id="na_role">
            <option value="editor">Editor — catálogo, pedidos e clientes</option>
            <option value="owner">Owner — acesso total</option>
          </select>
        </div>
        <div class="admin-modal-actions">
          <button type="button" class="btn btn-outline btn-sm" id="naCancelBtn">Cancelar</button>
          <button type="submit" class="btn btn-primary btn-sm" id="naSubmitBtn">Criar administrador</button>
        </div>
      </form>
    </div>
  `;
  document.body.appendChild(backdrop);
  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
  document.getElementById("naCancelBtn").addEventListener("click", () => backdrop.remove());

  document.getElementById("newAdminForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("naSubmitBtn");
    btn.disabled = true;
    btn.textContent = "Criando...";

    const ok = await smCreateAdmin(
      document.getElementById("na_email").value.trim(),
      document.getElementById("na_pass").value,
      document.getElementById("na_name").value.trim(),
      document.getElementById("na_role").value
    );

    if (ok) {
      smToast("Administrador criado.", "success");
      backdrop.remove();
      setTimeout(() => window.location.reload(), 600);
    } else {
      btn.disabled = false;
      btn.textContent = "Criar administrador";
    }
  });
}
